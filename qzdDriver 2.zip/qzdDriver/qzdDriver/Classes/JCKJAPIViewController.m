//
//  JCKJAPIViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/11.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJAPIViewController.h"
#import "JCKJDriverRequestTool.h"

#import "JCKJDriverParam.h"
#import "LYQCancleBarButton.h"

#import "JCKJAPITwoViewController.h"

@interface JCKJAPIViewController ()

@property (nonatomic ,strong) JCKJDriverParam *param;


@end

@implementation JCKJAPIViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"接口测试1";
    
    self.navigationItem.rightBarButtonItem = [LYQCancleBarButton addItemButton:self action:@selector(jiekou) Title:@"接口测试2"];
    

    
    
}
-(void)jiekou{
    
    JCKJAPITwoViewController *two = [[JCKJAPITwoViewController alloc] init];
    
    [self.navigationController pushViewController:two animated:YES];
}


/**司机端获取乘客，并生成订单 - getpassenger*/
- (IBAction)four {
   
    [JCKJDriverRequestTool getpassengerParam:self.param Success:^(JCKJJZModel *order) {
        
    } failure:^(NSError *error) {
        
    }];
    
}
/**司机端司机发车接口 - fastdriverstart*/
- (IBAction)five {
    
    [JCKJDriverRequestTool fastdriverstartParam:nil success:^(JCKJDriverInfoModel *model) {
        
    } failure:^(NSError *error) {
        
    }];
    
}
/**司机端刷新车辆信息接口 - driverrefresh*/

- (IBAction)sex{
    
    [JCKJDriverRequestTool driverrefreshParam:nil success:^(JCKJDriverOrder *order) {
        
    } failure:^(NSError *error) {
        
    }];
    
}
/**司机端停止接单接口 - driverstop*/

- (IBAction)seven {
    
    [JCKJDriverRequestTool driverstopSuccess:^{
        
    } failure:^(NSError *error) {
        
    }];
    
}
/**司机改变自己的行程状态 - driverchangestatus*/
- (IBAction)engit {
 
    [JCKJDriverRequestTool driverchangestatusSuccess:^(JCKJJZModel *order) {
        
    } failure:^(NSError *error) {
        
    }];
    
}
/**司机端获取订单列表 - getfastorderlist*/

- (IBAction)ninght {
   
  
    
}

//身份证识别
- (IBAction)aa:(UIButton *)sender {
   
    [JCKJDriverRequestTool authman_Param:nil success:^(JCKJJZModel *order) {
        
    } failure:^(NSError *error) {
        
    }];
}
// 驾照识别
- (IBAction)bb:(id)sender {
    [JCKJDriverRequestTool authdriver_Param:nil success:^(JCKJJZModel *order) {
        
    } failure:^(NSError *error) {
        
    }];
}
// 行驶证识别
- (IBAction)cc:(id)sender {
    [JCKJDriverRequestTool authcarParam:nil success:^(JCKJJZModel *order) {
        
    } failure:^(NSError *error) {
        
    }];
}


@end
