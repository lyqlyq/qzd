//
//  JCKJMapBaseViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/20.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJMapBaseViewController.h"
#import <AMapNaviKit/AMapNaviKit.h>
#import "LYQAddressModel.h"
#import "LYQLocaModel.h"
#import "LYQSearchAddressView.h"

@interface JCKJMapBaseViewController ()<AMapNaviDriveManagerDelegate>


@property (nonatomic ,strong) NSMutableArray *models;


@property (nonatomic ,strong) AMapNaviPoint *startPoint;
@property (nonatomic ,strong) AMapNaviPoint *endPoint;

@property (nonatomic ,strong)  AMapNaviDriveManager *nav_mgr;



@end

@implementation JCKJMapBaseViewController

-(AMapNaviDriveManager *)nav_mgr{
    
    if (_nav_mgr == nil) {
        _nav_mgr = [AMapNaviDriveManager sharedInstance];
        _nav_mgr.delegate =self;
    }
    return _nav_mgr;
    
}



- (void)viewDidLoad {
    [super viewDidLoad];
   

}

-(MAMapView *)mapView{
    if (_mapView == nil) {
        
        _mapView = [[MAMapView alloc] init];
        _mapView.autoresizingMask = UIViewAutoresizingNone;
        _mapView.customizeUserLocationAccuracyCircleRepresentation = YES;
        _mapView.showsCompass = NO;
        _mapView.showsIndoorMap = NO;
        _mapView.rotateEnabled = NO;
        _mapView.showsScale = NO;
        _mapView.distanceFilter=500;
        _mapView.zoomLevel = 16;
        _mapView.showsUserLocation = NO;
        _mapView.delegate = self;
        _mapView.userTrackingMode = MAUserTrackingModeFollow;
        
        MAUserLocationRepresentation *r = [[MAUserLocationRepresentation alloc] init];
        r.showsAccuracyRing = NO;///精度圈是否显示，默认YES
        r.showsHeadingIndicator = NO;///是否显示方向指示(MAUserTrackingModeFollowWithHeading模式开启)。默认为YES
        r.fillColor = [UIColor clearColor];///精度圈 填充颜色, 默认 kAccuracyCircleDefaultColor
        r.strokeColor = [UIColor clearColor];///精度圈 边线颜色, 默认 kAccuracyCircleDefaultColor
        r.lineWidth = 0;///精度圈 边线宽度，默认0
        r.enablePulseAnnimation = NO;///内部蓝色圆点是否使用律动效果, 默认YES
        r.locationDotBgColor = [UIColor clearColor];///定位点背景色，不设置默认白色
        r.locationDotFillColor = [UIColor clearColor];///定位点蓝色圆点颜色，不设置默认蓝色
//        r.image = [UIImage imageNamed:@"people"]; ///定位图标, 与蓝色原点互斥
        [self.mapView updateUserLocationRepresentation:r];

    }
    return _mapView;
    
}

-(AMapReGeocodeSearchRequest *)regeo{
    if (_regeo == nil) {
        _regeo = [[AMapReGeocodeSearchRequest alloc] init];
        _regeo.requireExtension = YES;
    }
    return _regeo;
}

-(AMapSearchAPI *)search{
    if (_search == nil) {
        self.search = [[AMapSearchAPI alloc] init];
        self.search.delegate = self;
    }
    return _search;
}


@end
