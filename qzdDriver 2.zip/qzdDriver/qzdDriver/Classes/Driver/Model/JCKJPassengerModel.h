//
//  JCKJPassengerModel.h
//  qzdDriver
//
//  Created by pro on 2018/4/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJPassengerModel : NSObject

@property (nonatomic ,copy) NSString *name;
@property (nonatomic ,copy) NSString *nick;
@property (nonatomic ,copy) NSString *head;
@property (nonatomic ,copy) NSString *sex;
@property (nonatomic ,copy) NSString *phone;
@property (nonatomic ,copy) NSString *status;
@property (nonatomic ,copy) NSString *freeze_money;
@property (nonatomic ,copy) NSString *mount;


@property (nonatomic ,copy) NSString *phone_weihao;


@end
