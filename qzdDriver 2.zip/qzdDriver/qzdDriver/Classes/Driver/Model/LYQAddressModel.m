//
//  LYQAddressModel.m
//  quanzhouda
//
//  Created by pro on 2017/11/29.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQAddressModel.h"

#import "LYQLocaModel.h"

@implementation LYQAddressModel
MJCodingImplementation


//+(NSDictionary *)mj_objectClassInArray{
//    
//    return @{@"location":[LYQLocaModel class]};
//    
//}

@end
