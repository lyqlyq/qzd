//
//  JCKJDriverInfoModel.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJDriverInfoModel : NSObject

@property (nonatomic ,copy) NSString *email;
@property (nonatomic ,copy) NSString *freeze_money;
@property (nonatomic ,copy) NSString *head;
@property (nonatomic ,copy) NSString *isdriver;
@property (nonatomic ,copy) NSString *name;
@property (nonatomic ,copy) NSString *nick;
@property (nonatomic ,copy) NSString *online;
@property (nonatomic ,copy) NSString *phone;
@property (nonatomic ,copy) NSString *sex;
@property (nonatomic ,copy) NSString *status;
@property (nonatomic ,copy) NSString *userid;

@property (nonatomic ,strong) UIImage *sexImage;



@end
