//
//  JCKJDriverOrder.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverOrder.h"

@implementation JCKJDriverOrder



-(BOOL)isJieDan{
    
    if ([self.status isEqualToString:@"2"]) {
        return  YES;
    }else{
        return NO;
    }
    
}


-(BOOL)isLiXian{
    if ([self.status isEqualToString:@"3"]) {
        return  YES;
    }else{
        return NO;
    }
}

-(BOOL)isZaiXian{
    if ([self.status isEqualToString:@"1"] || [self.status isEqualToString:@"2"]) {
        return  YES;
    }else{
        return NO;
    }
}

-(CGFloat)latitude{
    
    if (_latitude > 0) {
        return _latitude;
    }
    
    NSArray *co  =  [self.coordinate componentsSeparatedByString:@","];
    
    return [[co lastObject] doubleValue];
    
}

-(CGFloat)longitude{
    
    if (_longitude > 0 ){
        return _longitude;
    }
    
    NSArray *co  =  [self.coordinate componentsSeparatedByString:@","];
    return [[co firstObject] doubleValue];
}
-(BOOL)isDD_QX{
    
    if ([_status isEqualToString:@"4"]) {
        return YES;
    }else{
        return NO;
    }
}


@end
