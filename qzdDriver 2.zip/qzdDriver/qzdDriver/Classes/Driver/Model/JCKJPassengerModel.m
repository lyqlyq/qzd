//
//  JCKJPassengerModel.m
//  qzdDriver
//
//  Created by pro on 2018/4/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPassengerModel.h"

@implementation JCKJPassengerModel

-(NSString *)phone_weihao{
    
    NSString *weihao = nil;
    
    
    if (_phone.length == 11 ) {
        
        weihao = [_phone substringWithRange:NSMakeRange(7, 4)];
        
    }
    
    return [NSString stringWithFormat:@"尾号%@",weihao];
    
}

@end
