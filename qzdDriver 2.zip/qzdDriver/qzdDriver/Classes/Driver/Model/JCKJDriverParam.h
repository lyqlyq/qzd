//
//  JCKJDriverParam.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJDriverParam : NSObject




/**位置信息*/
@property (nonatomic ,copy) NSString *coordinate;
/**速度*/
@property (nonatomic ,copy) NSString *speed;
/**方向*/
@property (nonatomic ,copy) NSString *direction;

@property (nonatomic ,assign) CGFloat mileage;

@property (nonatomic ,assign) CGFloat latitude;
@property (nonatomic ,assign) CGFloat longitude;

@property (nonatomic ,assign) CGFloat first_laitude_driver;
@property (nonatomic ,assign) CGFloat first_longitude_driver;


/**照片名称*/
@property (nonatomic ,copy) NSString *filename;

/**乘客行程ID*/
@property (nonatomic ,copy) NSString *orderid;

/**司机选定出发时间*/
@property (nonatomic ,copy) NSString *time;
/**接单行程ID*/
@property (nonatomic ,copy) NSString *travelid;

/**状态*/
@property (nonatomic ,copy) NSString *status;

@property (nonatomic ,assign) NSInteger type;
@property (nonatomic ,copy) NSString *color;

// 身份证

@property (nonatomic ,copy) NSString *birthday;
@property (nonatomic ,copy) NSString *address;
@property (nonatomic ,copy) NSString *sex;
@property (nonatomic ,copy) NSString *adress;
@property (nonatomic ,copy) NSString *cardurlb;

/**民族 -- 国家*/
@property (nonatomic ,copy) NSString *nation;
@property (nonatomic ,copy) NSString *realname;
@property (nonatomic ,copy) NSString *carid;


// 驾驶证识别
@property (nonatomic ,copy) NSString *drivecarnum;
@property (nonatomic ,copy) NSString *drivecarmod;
@property (nonatomic ,copy) NSString *el;
@property (nonatomic ,copy) NSString *drivecarbelo;
@property (nonatomic ,copy) NSString *ngto;
@property (nonatomic ,copy) NSString *drivecarbegin;
@property (nonatomic ,copy) NSString *driver_B_url;

//行驶证识别
@property (nonatomic ,copy) NSString *name;
@property (nonatomic ,copy) NSString *cartype;
@property (nonatomic ,copy) NSString *regtime;
@property (nonatomic ,copy) NSString *usetype;
@property (nonatomic ,copy) NSString *engineunm;
@property (nonatomic ,copy) NSString *carunm;
@property (nonatomic ,copy) NSString *carvin;
@property (nonatomic ,copy) NSString *comment;

// 车架号查询车辆信息
@property (nonatomic ,copy) NSString *brand;
@property (nonatomic ,copy) NSString *yeartype;
@property (nonatomic ,copy) NSString *environment;
@property (nonatomic ,copy) NSString *alstandards;
@property (nonatomic ,copy) NSString *comfuelcons;
@property (nonatomic ,copy) NSString *umption;
@property (nonatomic ,copy) NSString *engine;
@property (nonatomic ,copy) NSString *gearbox;
@property (nonatomic ,copy) NSString *drivemode;
@property (nonatomic ,copy) NSString *carbody;


@property (nonatomic ,copy) NSString *orderunm;

@property (nonatomic ,copy) NSString *url;



// 身份证

/**等于1   可以继续接单*/
@property (nonatomic ,assign) NSInteger change;

+(instancetype)param;


@end
