//
//  JCKJDriverOrder.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJPassengerInfoModel;
@class JCKJPassengerModel;
@interface JCKJDriverOrder : NSObject

@property (nonatomic ,copy) NSString *status;

@property (nonatomic ,copy) NSString *coordinate;

@property (nonatomic ,strong) JCKJPassengerInfoModel *order;
@property (nonatomic ,strong) JCKJPassengerModel *passenger;

@property (nonatomic ,copy) NSString *logintime;

@property (nonatomic ,assign) CGFloat latitude;
@property (nonatomic ,assign) CGFloat longitude;

@property (nonatomic ,assign) BOOL isJieDan;
@property (nonatomic ,assign) BOOL isZaiXian;
@property (nonatomic ,assign) BOOL isLiXian;
/**订单取消*/
@property (nonatomic ,assign) BOOL isDD_QX;



@end
