//
//  JCKJPassengerInfoModel.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJPassengerInfoModel : NSObject

@property (nonatomic ,copy) NSString * endcoordinate;
@property (nonatomic ,copy) NSString * endplace;

@property (nonatomic ,copy) NSString * price;
@property (nonatomic ,copy) NSString * startcoordinate;

@property (nonatomic ,copy) NSString * startplace;
@property (nonatomic ,copy) NSString * status;

@property (nonatomic ,assign) CGFloat startLatitude;
@property (nonatomic ,assign) CGFloat statrLongitude;

@property (nonatomic ,assign) CGFloat endLatitude;
@property (nonatomic ,assign) CGFloat endLongitude;

@property (nonatomic ,copy) NSString *orderunm;




@end
