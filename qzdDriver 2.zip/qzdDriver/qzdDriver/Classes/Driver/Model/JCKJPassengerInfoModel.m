//
//  JCKJPassengerInfoModel.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPassengerInfoModel.h"

@implementation JCKJPassengerInfoModel




-(CGFloat)startLatitude{
    
   NSArray *laLon = [self.startcoordinate componentsSeparatedByString:@","];
    
    return [[laLon lastObject] doubleValue];
    
}

-(CGFloat)statrLongitude{
    
    NSArray *laLon = [self.startcoordinate componentsSeparatedByString:@","];
    
    return [[laLon firstObject] doubleValue];
}

-(CGFloat)endLatitude{
    NSArray *laLon = [self.endcoordinate componentsSeparatedByString:@","];
    
    return [[laLon lastObject] doubleValue];
}

-(CGFloat)endLongitude{
    NSArray *laLon = [self.endcoordinate componentsSeparatedByString:@","];
    
    return [[laLon firstObject] doubleValue];
}




@end
