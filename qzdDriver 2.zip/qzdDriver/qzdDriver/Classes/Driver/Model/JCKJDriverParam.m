//
//  JCKJDriverParam.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverParam.h"

@implementation JCKJDriverParam



+(instancetype)param{
    
    JCKJDriverParam *param = [[JCKJDriverParam alloc] init];
    
    
    return param;
}

-(CGFloat)latitude{
    
   NSArray *points = [_coordinate componentsSeparatedByString:@","];
    return [[points lastObject] doubleValue];
}

-(CGFloat)longitude{
    NSArray *points = [_coordinate componentsSeparatedByString:@","];
    return [[points firstObject] doubleValue];
}

@end
