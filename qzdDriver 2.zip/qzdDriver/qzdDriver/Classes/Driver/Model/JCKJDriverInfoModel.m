//
//  JCKJDriverInfoModel.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverInfoModel.h"

@implementation JCKJDriverInfoModel





-(UIImage *)sexImage{
    
    if ([self.sex isEqualToString:@"1"]) {
        return [UIImage imageNamed:@"man"];
    }else{
        return [UIImage imageNamed:@"woman"];
    }
    
}

-(NSString *)nick{
    
    if (_nick == nil) {
        _nick = @"暂无昵称";
    }
    return _nick;
}


@end
