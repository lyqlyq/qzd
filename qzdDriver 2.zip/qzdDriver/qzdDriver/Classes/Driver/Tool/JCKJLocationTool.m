//
//  JCKJLocationTool.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJLocationTool.h"
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapLocationKit/AMapLocationKit.h>

#import "JCKJDriverParam.h"
#import "JCKJPoint.h"

@interface JCKJLocationTool()<AMapLocationManagerDelegate>

@property (nonatomic ,strong) AMapLocationManager *locaMgr;


@end

@implementation JCKJLocationTool


-(AMapLocationManager *)locaMgr{
    if (_locaMgr == nil) {
        _locaMgr = [[AMapLocationManager alloc] init];
        _locaMgr.delegate = self;
        _locaMgr.distanceFilter = 200;
    }
    return _locaMgr;
}

-(void)startDriverLocation{
    
  
    
    if ( [AMapLocationManager headingAvailable]) {
        [self.locaMgr startUpdatingHeading];
    }

    [self.locaMgr startUpdatingLocation];
    
}
- (void)amapLocationManager:(AMapLocationManager *)manager didUpdateLocation:(CLLocation *)location
{
    
    
    
    NSLog(@"location:{lat:%f; lon:%f; accuracy:%f}", location.coordinate.latitude, location.coordinate.longitude, location.horizontalAccuracy);
    
    NSString *coordinate = [[NSUserDefaults standardUserDefaults] objectForKey:jckj_driver_first_coordinate];
    
    if (coordinate == nil) {
        [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%f,%f",location.coordinate.latitude,location.coordinate.longitude] forKey:jckj_driver_first_coordinate];
        coordinate = [NSString stringWithFormat:@"%f,%f",location.coordinate.latitude,location.coordinate.longitude];
    }
    
    
    NSArray *first_La_Lo = [coordinate componentsSeparatedByString:@","];
    

    JCKJDriverParam *param = [JCKJDriverParam param];
    param.coordinate = [NSString stringWithFormat:@"%f,%f",location.coordinate.longitude,location.coordinate.latitude];
    param.speed = [NSString stringWithFormat:@"%f",location.speed];
    param.direction = [NSString stringWithFormat:@"%f",location.course];
    param.first_laitude_driver = [[first_La_Lo  firstObject] doubleValue];
    param.first_longitude_driver = [[first_La_Lo lastObject] doubleValue];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:driver_location_change_Note object:nil userInfo:param.mj_keyValues];


    NSLog(@"%@",param.mj_keyValues);

    if ([self.delegate respondsToSelector:@selector(JCKJLocationTool:LocationSuccessWithParam:)]) {
        [self.delegate JCKJLocationTool:self LocationSuccessWithParam:param];
    }
    
    
}

@end
