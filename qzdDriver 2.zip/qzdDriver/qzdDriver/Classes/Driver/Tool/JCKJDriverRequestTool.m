//
//  JCKJDriverRequestTool.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverRequestTool.h"
#import "LYQRequestTool.h"
#import "JCKJDriverParam.h"
#import "JCKJDriverInfoModel.h"
#import "JCKJDriverOrder.h"
#import "JCKJJZModel.h"

@implementation JCKJDriverRequestTool


/**获取司机信息的接口*/
+(void)get_detailsSuccess:(void(^)(JCKJDriverInfoModel *model))success failure:(void(^)(NSError *error))failure;
{
    
    
    [LYQRequestTool POSTURL:getdetails_URL params:nil success:^(id responseObject) {
        JCKJDriverInfoModel *infoModel = [JCKJDriverInfoModel mj_objectWithKeyValues:responseObject];
        
        if (success) {
            success(infoModel);
        }
        
        
    } failure:^(NSError *error) {
        
        
        
    } showMessage:nil isShowMessage:YES];
    
    
}


/**司机端司机发车接口*/
+(void)fastdriverstartParam:(JCKJDriverParam *)param success:(void(^)(JCKJDriverInfoModel *model))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:fastdriverstart_URL params:param.mj_keyValues success:^(id responseObject) {
        if (success) {
            success(nil);
        }
        
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    } showMessage:nil isShowMessage:YES];
    
}

/**司机端停止接单接口*/
+(void)driverstopSuccess:(void(^)())success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:driverstop_URL params:nil success:^(id responseObject) {
        if (success) {
            success();
        }
        
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    } showMessage:nil isShowMessage:YES];
    
}

/**车主刷新请求*/
+(void)driverrefreshParam:(JCKJDriverParam *)param success:(void(^)(JCKJDriverOrder *order))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:driverrefresh_URL params:param.mj_keyValues success:^(id responseObject) {
        
        JCKJDriverOrder *order = [JCKJDriverOrder mj_objectWithKeyValues:responseObject[@"info"]];
        
        if (success) {
            success(order);
        }
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    } showMessage:nil isShowMessage:NO];
}
/**驾照识别*/
+(void)authdriver_Param:(JCKJDriverParam *)param success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    
    NSString *info = @"驾照识别中";
    NSString *errorInfo = @"识别失败请重新上传";
    
    if (param.type == 2 || param.type == 3) {
        info = @"上传中";
        errorInfo = @"上传失败";
    }
    
    [LYQRequestTool POSTURL:@"authdriver" params:param.mj_keyValues success:^(id responseObject) {
        
        JCKJJZModel *model = [JCKJJZModel mj_objectWithKeyValues:responseObject[@"driverinfo"]];
        
        if (success) {
            success(model);
        }
        
        
    } failure:^(NSError *error) {
        LYQ_SHOW_INFO(errorInfo);
        
    } showMessage:info isShowMessage:YES];
    
}
/**行驶证识别*/
+(void)authcarParam:(JCKJDriverParam *)param success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    
    
    NSString *info = @"行驶证识别中";
    NSString *errorInfo = @"识别失败请重新上传";

    if (param.type == 2 || param.type == 3) {
        info = @"上传中";
        errorInfo = @"上传失败";

    }
    
    [LYQRequestTool POSTURL:@"authcar" params:param.mj_keyValues success:^(id responseObject) {
        
        JCKJJZModel *model = [JCKJJZModel mj_objectWithKeyValues:responseObject[@"driverinfo"]];
        if (success) {
            success(model);
        }
        
    } failure:^(NSError *error) {
        LYQ_SHOW_INFO(errorInfo);
    } showMessage:info isShowMessage:YES];
    
}
/**身份证识别*/
+(void)authman_Param:(JCKJDriverParam *)param success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    
    NSString *info = @"身份证识别中";
    NSString *errorInfo = @"识别失败请重新上传";

    if (param.type == 2 || param.type == 3) {
        info = @"上传中";
        errorInfo = @"上传失败";
    }
    
    [LYQRequestTool POSTURL:@"authman" params:param.mj_keyValues success:^(id responseObject) {
        
        JCKJJZModel *model = [JCKJJZModel mj_objectWithKeyValues:responseObject[@"cardinfo"]];
        
        
        if (param.type == 2 || param.type == 3) {
            if (success) {
                success(model);
            }
        }else{
            
            if (model.adress.length > 0) {
                if (success) {
                    success(model);
                }
            }else{
                LYQ_SHOW_INFO(errorInfo);
            }
            
            
            
        }
        
        
    } failure:^(NSError *error) {
        LYQ_SHOW_INFO(@"识别失败请重新上传");
    } showMessage:info isShowMessage:YES];
    
}


/**司机端获取乘客行程信息列表*/
+(void)sharepassengerSuccess:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:@"sharepassenger" params:nil success:^(id responseObject) {
        
      
    } failure:^(NSError *error) {

    } showMessage:nil isShowMessage:YES];
    
    
}

/**司机端获取自己发布行程信息列表*/
+(void)getsharetravel_d_Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:@"getsharetravel-d" params:nil success:^(id responseObject) {
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
    
    
}


/**司机端获取自己发布的行程产生的订单列表*/
+(void)getsharetravelorderlistParam:(JCKJDriverParam *)param Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:@"getsharetravelorderlist" params:param.mj_keyValues success:^(id responseObject) {
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
    
    
}
/**司机端获取乘客并产生订单*/
+(void)getpassengerParam:(JCKJDriverParam *)param Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:@"getpassenger" params:param.mj_keyValues success:^(id responseObject) {
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
    
    
}

/**司机端获取订单列表*/
+(void)getfastorderlistSuccess:(void(^)(NSMutableArray *models))success failure:(void(^)(NSError *error))failure{
    
    
    [LYQRequestTool POSTURL:@"getfastorderlist" params:nil success:^(id responseObject) {
        
        NSMutableArray *models = [JCKJJZModel mj_objectArrayWithKeyValuesArray:responseObject[@"orderlist"]];
        
        if (success) {
            success(models);
        }
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
    
}
/**司机改变自己的行程状态*/
+(void)driverchangestatusSuccess:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    
    
    [LYQRequestTool POSTURL:@"driverchangestatus" params:nil success:^(id responseObject) {
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
    
    
}
/**司机改变快车订单状态接口*/
+(void)fastdriverchangestatusParam:(JCKJDriverParam *)param Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    
    
    [LYQRequestTool POSTURL:@"fastdriverchangestatus" params:param.mj_keyValues success:^(id responseObject) {
        
        
        if (success) {
            success(nil);
        }
        
    } failure:^(NSError *error) {
        
        
        
        
    } showMessage:nil isShowMessage:YES];
    
    
}

/**司机取消订单*/
+(void)drivercancelfastorderParam:(JCKJDriverParam *)param Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure{
    
    
    
    [LYQRequestTool POSTURL:param.url params:param.mj_keyValues success:^(id responseObject) {
        
        
        if (success) {
            success(nil);
        }
        
    } failure:^(NSError *error) {
        
        
        
        
    } showMessage:nil isShowMessage:YES];
    
    
}



@end
