//
//  LYQCheckUserOpenLocationTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/6.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQCheckUserOpenLocationTool : NSObject

- (BOOL)checkLocationServicesAuthorizationStatus;

@end
