//
//  JCKJDriverRequestTool.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJDriverParam;
@class JCKJDriverInfoModel;
@class JCKJDriverOrder;
@class JCKJJZModel;
@interface JCKJDriverRequestTool : NSObject



/**获取司机信息的接口*/
+(void)get_detailsSuccess:(void(^)(JCKJDriverInfoModel *model))success failure:(void(^)(NSError *error))failure;

/**司机端司机发车接口*/
+(void)fastdriverstartParam:(JCKJDriverParam *)param success:(void(^)(JCKJDriverInfoModel *model))success failure:(void(^)(NSError *error))failure;

/**司机端停止接单接口*/
+(void)driverstopSuccess:(void(^)())success failure:(void(^)(NSError *error))failure;


/**车主刷新位置信息*/
+(void)driverrefreshParam:(JCKJDriverParam *)param success:(void(^)(JCKJDriverOrder *order))success failure:(void(^)(NSError *error))failure;

/**驾照识别*/
+(void)authdriver_Param:(JCKJDriverParam *)param success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;

/**行驶证识别*/
+(void)authcarParam:(JCKJDriverParam *)param success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;

/**身份证识别*/
+(void)authman_Param:(JCKJDriverParam *)param success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;

///**司机端获取乘客行程信息列表*/
//+(void)sharepassengerSuccess:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;
//
///**司机端获取自己发布的行程列表*/
//+(void)getsharetravel_d_Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;
//
//
///**司机端获取自己发布的行程产生的订单列表*/
//+(void)getsharetravelorderlistParam:(JCKJDriverParam *)param Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;


/**司机端获取乘客并产生订单*/
+(void)getpassengerParam:(JCKJDriverParam *)param Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;

/**司机端获取订单列表*/
+(void)getfastorderlistSuccess:(void(^)(NSMutableArray *models))success failure:(void(^)(NSError *error))failure;


/**司机改变自己的行程状态*/
+(void)driverchangestatusSuccess:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;

/**司机改变快车订单状态接口*/
+(void)fastdriverchangestatusParam:(JCKJDriverParam *)param Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;

+(void)drivercancelfastorderParam:(JCKJDriverParam *)param Success:(void(^)(JCKJJZModel *order))success failure:(void(^)(NSError *error))failure;

@end
