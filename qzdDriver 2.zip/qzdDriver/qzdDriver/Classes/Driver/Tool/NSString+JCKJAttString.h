//
//  NSString+JCKJAttString.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (JCKJAttString)

/**生产attString*/
+(NSMutableAttributedString *)getAllText:(NSString *)allText attText:(NSString *)attText attCorlo:(UIColor *)attTextColor attFont:(UIFont *)attTextFont allTextColor:(UIColor *)allColor;


/**生产红色的价格*/
+(NSMutableAttributedString *)getMoneyAtt_redText:(NSString *)price;




@end
