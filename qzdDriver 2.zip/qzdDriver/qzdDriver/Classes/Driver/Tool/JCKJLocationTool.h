//
//  JCKJLocationTool.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJDriverParam;
@class JCKJLocationTool;
//
@protocol JCKJLocationToolDelegate <NSObject>
-(void)JCKJLocationTool:(JCKJLocationTool *)tool LocationSuccessWithParam:(JCKJDriverParam *)param;
@end
/**司机定位信息的工具类*/
@interface JCKJLocationTool : NSObject

@property (nonatomic ,weak) id<JCKJLocationToolDelegate> delegate;

-(void)startDriverLocation;
@end
