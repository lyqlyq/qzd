//
//  JCKJDriverOrderDetialController.m
//  qzdDriver
//
//  Created by pro on 2018/4/14.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverOrderDetialController.h"

#import <UIImageView+WebCache.h>
#import "JCKJDriverOrder.h"
#import "JCKJPassengerInfoModel.h"
#import "JCKJPassengerModel.h"
#import "JCKJDriverParam.h"
#import "JCKJDriverRequestTool.h"
#import "LYQAlertView.h"
#import <UIButton+SGImagePosition.h>

@interface JCKJDriverOrderDetialController ()
@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
@property (weak, nonatomic) IBOutlet UILabel *nickNamel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIButton *startPlcae;
@property (weak, nonatomic) IBOutlet UIButton *endPlace;
@property (weak, nonatomic) IBOutlet UIButton *callButton;

@end

@implementation JCKJDriverOrderDetialController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"订单详情";
    
    [self.callButton SG_imagePositionStyle:SGImagePositionStyleRight spacing:8];
    
    [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:self.order.passenger.head] placeholderImage:JCKJ_headerImage];
    
    self.nickNamel.text = self.order.passenger.phone_weihao;
    
    self.timeLabel.text = self.order.logintime;
    
    [self.startPlcae setTitle:self.order.order.startplace forState:UIControlStateNormal];
    
    [self.endPlace setTitle:self.order.order.endplace forState:UIControlStateNormal];
    
    
}
- (IBAction)callClick:(UIButton *)sender {
    LYQCall_phone(self.order.passenger.phone);
}


/**取消订单*/
- (IBAction)cancleOrderClick:(UIButton *)sender {
    
    
    LYQAlertView *alertView  = [LYQAlertView alertViewWithType:alertViewType_SURE];
    
    alertView.contentText = @"每天只可免责取消一次，确定要取消吗？";
    [alertView show];
    
    alertView.sureClick = ^{
        
        JCKJDriverParam *param = [JCKJDriverParam param];
        param.url = @"drivercancelfastorder";
        param.orderunm = self.order.order.orderunm;
        
        [JCKJDriverRequestTool drivercancelfastorderParam:param Success:^(JCKJJZModel *order) {
            
            [self.navigationController popToRootViewControllerAnimated:YES];
            
        } failure:^(NSError *error) {
            
        }];
    };
   
    
}

/**联系不上乘客*/ 
- (IBAction)lxBuPassengerClick:(UIButton *)sender {
    
    
    LYQAlertView *alertView  = [LYQAlertView alertViewWithType:alertViewType_SURE];
    
    alertView.contentText = @"每天只可免责取消一次，确定要取消吗？";
    [alertView show];
    
    alertView.sureClick = ^{
        
        JCKJDriverParam *param = [JCKJDriverParam param];
        param.url = @"drivercancelfastorder";
        param.orderunm = self.order.order.orderunm;
        param.comment = @"联系不上乘客";
        
        [JCKJDriverRequestTool drivercancelfastorderParam:param Success:^(JCKJJZModel *order) {
            
            [self.navigationController popToRootViewControllerAnimated:YES];
            
        } failure:^(NSError *error) {
            
        }];
    };
    
    
    
}

@end
