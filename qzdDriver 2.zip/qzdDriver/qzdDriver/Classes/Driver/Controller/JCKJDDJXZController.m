//
//  JCKJDDJXZController.m
//  qzdDriver
//
//  Created by pro on 2018/3/23.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDDJXZController.h"
#import "LYQCancleBarButton.h"
#import "JCKJPassengerInfoModel.h"
#import "JCKJDriverOrder.h"
#import <MAMapKit/MAMapKit.h>

#import "CommonUtility.h"
#import "MANaviRoute.h"
#import "JCKJDriverParam.h"
#import "JCKJPassengerModel.h"

#import "JCKJ_DH_ViewController.h"
#import "JCKJDriverOrderDetialController.h"

#import "JCKJDriverRequestTool.h"

@interface JCKJDDJXZController ()


{
 
    CLLocationCoordinate2D coordinSTART[2];

    
}


#define DDSCD_Title @"已到达上车点"
#define CKYSC_Title @"乘客已上车"
#define CKYSD_Title @"乘客已送达"
#define moenyType_DQ_Title @"当前费用"



@property (weak, nonatomic) IBOutlet UIView *contentView;

@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *luChengLabel;
@property (weak, nonatomic) IBOutlet UILabel *daoDaLabel;
@property (weak, nonatomic) IBOutlet UIButton *daoHangButton;
@property (weak, nonatomic) IBOutlet UILabel *moneyTypeLabel;

@property (nonatomic ,strong) MAAnimatedAnnotation *dirvierAnnotation ;

/**用于显示当前路线方案*/
@property (strong, nonatomic) MANaviRoute * naviRoute;

/**路径规划信息*/
@property (strong, nonatomic) AMapRoute *route;


@property (nonatomic ,strong) JCKJDriverParam *lastPoint;


@end

@implementation JCKJDDJXZController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"订单进行中";
    
    self.navigationItem.rightBarButtonItem = [LYQCancleBarButton addItemButton:self action:@selector(ddxqClick) Title:@"订单详情"];
    self.navigationItem.hidesBackButton = YES;
    
    self.mapView.frame = CGRectMake(0, LYQ_NAV_H + 55, LYQ_SCREEN_W,LYQ_SCREEN_H - LYQ_NAV_H - 55 - 50);
    
    [self.view addSubview:self.mapView];
    
    [self.view bringSubviewToFront:self.daoHangButton];
    
    self.priceLabel.text = [NSString stringWithFormat:@"%@元",self.model.order.price];
    
    [self addDriverPointAndPassengerStartPoint];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(dirverLoctionChange:) name:driver_location_change_Note object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orderChange:) name:jckj_driver_OrderNoteName object:nil];
    
}

/**接受到通知 --  订单 */
-(void)orderChange:(NSNotification *)note{
    
    JCKJDriverOrder *model = [JCKJDriverOrder mj_objectWithKeyValues:note.userInfo];
    
    // 订单等于4  表示有乘客取消了
    if (model.isDD_QX) {
        
    }
    else{
        self.priceLabel.text = [NSString stringWithFormat:@"%@元",model.order.price];
    }
    
    
    
    
}

//添加司机和乘客的大头针模型
-(void)addDriverPointAndPassengerStartPoint{
    
    self.dirvierAnnotation = [[MAAnimatedAnnotation alloc] init];
   self.dirvierAnnotation.coordinate = CLLocationCoordinate2DMake(self.model.latitude,self.model.longitude);

    self.dirvierAnnotation.title = (NSString *)sjTitle;
    
    
    MAPointAnnotation *passStartAnnotation = [[MAPointAnnotation alloc] init];
    
    passStartAnnotation.title = (NSString *)qidiantitle;
    passStartAnnotation.coordinate = CLLocationCoordinate2DMake(self.model.order.startLatitude, self.model.order.statrLongitude);
    
    [self.mapView addAnnotation:self.dirvierAnnotation];
    [self.mapView addAnnotation:passStartAnnotation];
    
    
    // 起点
   
    
    [self searchRoutePlanningDriveStart:[AMapGeoPoint locationWithLatitude:self.model.latitude
                                                             longitude:self.model.longitude] endPoint:[AMapGeoPoint locationWithLatitude:self.model.order.startLatitude longitude:self.model.order.statrLongitude]];
    
}

-(void)searchRoutePlanningDriveStart:(AMapGeoPoint *)startPoint endPoint:(AMapGeoPoint *)endPoint{
    AMapDrivingRouteSearchRequest *navi = [[AMapDrivingRouteSearchRequest alloc] init];
    navi.requireExtension = YES;
    navi.strategy = 5;
    navi.origin = startPoint;
    navi.destination = endPoint;

    [self.search AMapDrivingRouteSearch:navi];
    
}


-(void)ddxqClick{
    JCKJDriverOrderDetialController *detial = [[JCKJDriverOrderDetialController alloc] init];
    detial.order = self.model;
    [self.navigationController pushViewController:detial animated:YES];
}

//导航
- (IBAction)daoHangClick:(UIButton *)sender {
    
    JCKJ_DH_ViewController *dhVC = [[JCKJ_DH_ViewController alloc] init];
    if ([self.daoDaLabel.text isEqualToString:DDSCD_Title]) {        
        dhVC.title = @"导航去接乘客";
        dhVC.isJie_passenger = YES;
    }else{
        dhVC.title = @"导航去送乘客";
    }
 
    dhVC.model = self.model;
    
    [self.navigationController pushViewController:dhVC animated:YES];
    
}


static const NSString *qidiantitle = @"起点";
static const NSString *endTitle = @"终点";
static const NSString *sjTitle = @"司机位置";

//打电话
- (IBAction)phoneClick:(UIButton *)sender {
    
    LYQCall_phone(self.model.passenger.phone);
    
}

//点击上车
- (IBAction)daoDaClick:(UIButton *)sender {
    
    NSString *tiStr = self.daoDaLabel.text;
    
    // 到达上车点
    if ([tiStr isEqualToString:DDSCD_Title]) {
       
        
        JCKJDriverParam *param = [JCKJDriverParam param];
        param.orderunm  = self.model.order.orderunm;
        param.status = @"3";
        
        [JCKJDriverRequestTool fastdriverchangestatusParam:param Success:^(JCKJJZModel *order) {
        
            self.daoDaLabel.text = CKYSC_Title;
       
        } failure:^(NSError *error) {
            
        }];
        
        
        
    }
    //乘客已上车
    if ([tiStr isEqualToString:CKYSC_Title]) {
        
        JCKJDriverParam *param = [JCKJDriverParam param];
        param.orderunm  = self.model.order.orderunm;
        param.status = @"4";
        
        [JCKJDriverRequestTool fastdriverchangestatusParam:param Success:^(JCKJJZModel *order) {
            
            // 重新规划路径
            [self addPassengerEndAnnotion];
            self.moneyTypeLabel.text = moenyType_DQ_Title;
            self.daoDaLabel.text = CKYSD_Title;
        } failure:^(NSError *error) {
            
        }];
    }
    //乘客已送达
    if ([tiStr isEqualToString:CKYSD_Title]) {
        JCKJDriverParam *param = [JCKJDriverParam param];
        param.orderunm  = self.model.order.orderunm;
        param.status = @"5";
        
        [JCKJDriverRequestTool fastdriverchangestatusParam:param Success:^(JCKJJZModel *order) {
          
            
        } failure:^(NSError *error) {
            
        }];
      
    }
    
    
    
    
}


-(void)addPassengerEndAnnotion{
    
    MAPointAnnotation *passEndAnnotation = [[MAPointAnnotation alloc] init];
    passEndAnnotation.title = (NSString *)endTitle;
    passEndAnnotation.coordinate = CLLocationCoordinate2DMake(self.model.order.endLatitude, self.model.order.endLongitude);
    
    [self.mapView addAnnotation:passEndAnnotation];
    
    AMapGeoPoint *start = [AMapGeoPoint locationWithLatitude:self.model.order.startLatitude longitude:self.model.order.statrLongitude];
    AMapGeoPoint *end = [AMapGeoPoint locationWithLatitude:self.model.order.endLatitude longitude:self.model.order.endLongitude];
    [self searchRoutePlanningDriveStart:start endPoint:end];
    
}


//路径规划搜索完成回调.
- (void)onRouteSearchDone:(AMapRouteSearchBaseRequest *)request response:(AMapRouteSearchResponse *)response{
    if (response.route == nil){
        return;
    }
    self.route = response.route;
    
    AMapPath *path = self.route.paths[0];
    
    self.luChengLabel.text = [NSString stringWithFormat:@"%ldkm",path.distance / 1000];
    
    self.timeLabel.text = [NSString stringWithFormat:@"%ld分钟",path.duration / 60];
    
    
    [self presentCurrentRouteCourse];
}
-(void)presentCurrentRouteCourse{
    
    [self.naviRoute removeFromMapView];  //清空地图上已有的路线
    AMapGeoPoint *startPoint = [AMapGeoPoint locationWithLatitude:self.model.latitude longitude:self.model.longitude]; //起点
    AMapGeoPoint *endPoint = [AMapGeoPoint locationWithLatitude:self.model.order.startLatitude longitude:self.model.order.statrLongitude];
    MANaviAnnotationType type = MANaviAnnotationTypeDrive; //驾车类型
    self.naviRoute = [MANaviRoute naviRouteForPath:self.route.paths[0] withNaviType:type showTraffic:NO startPoint:startPoint endPoint:endPoint];
    [self.naviRoute addToMapView:self.mapView];  //显示到地图上
    UIEdgeInsets edgePaddingRect = UIEdgeInsetsMake(60, 60, 60, 60);
    [self.mapView setVisibleMapRect:[CommonUtility mapRectForOverlays:self.naviRoute.routePolylines]
                        edgePadding:edgePaddingRect
                           animated:YES];
    
 //   AMapPath *path = self.route.paths[0];
    
//
//    for (AMapStep *step in path.steps) {
//        NSArray *point = [step.polyline componentsSeparatedByString:@";"];
//        for (NSString *pLoAndLa in point) {
//            NSArray * pLoAndLaArray = [pLoAndLa componentsSeparatedByString:@","];
//            double lon = [[pLoAndLaArray firstObject] doubleValue];
//            double lat = [[pLoAndLaArray lastObject] doubleValue];
//
//        }
//
//    }
//
    
    
}

//地图上覆盖物的渲染，可以设置路径线路的宽度，颜色等
- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id<MAOverlay>)overlay {
    NSLog(@"%@",overlay.class);
    //showTraffic为NO时，不需要带实时路况，路径为单一颜色，比如驾车线路目前为blueColor
    if ([overlay isKindOfClass:[MANaviPolyline class]]) {
        MANaviPolyline *naviPolyline = (MANaviPolyline *)overlay;
        MAPolylineRenderer *polylineRenderer = [[MAPolylineRenderer alloc] initWithPolyline:naviPolyline.polyline];
        polylineRenderer.lineWidth = 8;
        polylineRenderer.strokeColor = jckj_COLOR_driverMain;
        polylineRenderer.lineCapType = kMALineCapRound;
        return polylineRenderer;
    }
    
    return nil;
}


-(MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation{
    
    
    if([annotation isKindOfClass:[MAUserLocation class]]) {
        return nil;
    }
    
    if ([annotation isKindOfClass:[MAPointAnnotation class]]) {
        
        
        //标注的view的初始化和复用
        static NSString *routePlanningCellIdentifier = @"RoutePlanningCellIdentifier";
        MAAnnotationView *poiAnnotationView = (MAAnnotationView*)[self.mapView dequeueReusableAnnotationViewWithIdentifier:routePlanningCellIdentifier];
        
        
        if (poiAnnotationView == nil) {
            poiAnnotationView = [[MAAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:routePlanningCellIdentifier];
        }
        if ([[annotation title] isEqualToString:(NSString *)qidiantitle]) {
            poiAnnotationView.image = [UIImage imageNamed:@"qidian"];  //起点
        }
        if ([[annotation title] isEqualToString:(NSString *)endTitle]) {
            poiAnnotationView.image = [UIImage imageNamed:@"end"];  //终点
        }
        if ([[annotation title] isEqualToString:(NSString *)sjTitle]) {
            
            poiAnnotationView.image = [UIImage imageNamed:@"car"];  //终点
        }
        
        return poiAnnotationView;
        
    }
    
    return nil;
    
}

-(void)dirverLoctionChange:(NSNotification *)note{
    
    JCKJDriverParam *param = [JCKJDriverParam mj_objectWithKeyValues:note.mj_keyValues];
    
//    if (self.lastPoint == nil) {
//        self.lastPoint = param;
//        return;
//    }
//    if (self.lastPoint.latitude == param.latitude && self.lastPoint.longitude == param.longitude) {
//        return;
//    }
//
//
    coordinSTART[0].latitude = self.lastPoint.latitude;
    coordinSTART[0].longitude = self.lastPoint.longitude;
    coordinSTART[1].latitude = param.latitude;
    coordinSTART[1].longitude = param.longitude;
  
    LYQ_WEAK_SELF(self);
    [self.dirvierAnnotation addMoveAnimationWithKeyCoordinates:coordinSTART count:2 withDuration:10 withName:nil completeCallback:^(BOOL isFinished) {
        weakself.lastPoint = param;
    }];
    
}


@end
