//
//  JCKJDriverViewController.m
//  qzdDriver
//
//  Created by pro on 2018/3/23.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverViewController.h"
#import "LYQCancleBarButton.h"
#import "JCKJDDJXZController.h"

#import "JCKJDriverOrderController.h"
#import "LYQAlertView.h"

#import "JCKJPersonCenterController.h"
#import "JCKJDriverRequestTool.h"
#import "JCKJLocationTool.h"
#import "JCKJDriverParam.h"
#import "JCKJDriverOrder.h"
#import "JCKJPassengerInfoModel.h"

#import "JCKJAPIViewController.h"

@interface JCKJDriverViewController ()<JCKJLocationToolDelegate>
@property (weak, nonatomic) IBOutlet UIButton *faCheButton;

@property (nonatomic ,strong) JCKJLocationTool *locationTool;

@property (nonatomic ,strong) JCKJDriverParam *param;
@property (nonatomic ,strong) NSTimer *timer;

@property (nonatomic ,assign) BOOL isDriverJieDan;

@property (nonatomic ,assign) BOOL isDD_QX;


@end

@implementation JCKJDriverViewController



-(JCKJDriverParam *)param{
    
    if (_param == nil) {
        _param = [JCKJDriverParam param];
    }
    return _param;
    
}

-(JCKJLocationTool *)locationTool{
    if (_locationTool == nil) {
        _locationTool = [[JCKJLocationTool alloc] init];
        _locationTool.delegate = self;
    }
    return _locationTool;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"首页";


    self.navigationItem.leftBarButtonItem = [LYQCancleBarButton addItemWithImage:[UIImage imageNamed:@"PersonalCenter"] target:self action:@selector(personClick)];
    self.navigationItem.rightBarButtonItem = [LYQCancleBarButton addItemWithImage:[UIImage imageNamed:@"TheMessage"] target:self action:@selector(messageClick)];
    
    self.faCheButton.layer.cornerRadius = 4;
    self.faCheButton.layer.masksToBounds = YES;
    
    [self.locationTool startDriverLocation];


    self.timer = [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(loadRefaceDriverState) userInfo:nil repeats:YES];
    [self.timer fire];
    
    

    
}


-(void)loadRefaceDriverState{
     [self.locationTool startDriverLocation];
}

-(void)personClick{

    JCKJPersonCenterController *personVC = [[JCKJPersonCenterController alloc] init];
    
    [self.navigationController pushViewController:personVC animated:YES];
    
    
}

-(void)messageClick{
    
    JCKJAPIViewController *apiV = [[JCKJAPIViewController alloc] init];
    
    [self.navigationController pushViewController:apiV animated:YES];
}

// 获取到乘客的订单
-(void)loadPassengerOrder:(JCKJDriverOrder *)model{
    
    if (self.isDriverJieDan) {
        return;
    }
    JCKJDDJXZController *ddjxzVC = [[JCKJDDJXZController alloc] init];
    
    ddjxzVC.model = model;
    
    
    [self.navigationController pushViewController:ddjxzVC animated:YES];
}
- (IBAction)faClick:(UIButton *)sender {
    
    sender.selected = !sender.selected;
    
    if (sender.selected) {
        [JCKJDriverRequestTool fastdriverstartParam:self.param success:^(JCKJDriverInfoModel *model) {
            [self stopButton:NO];
        } failure:^(NSError *error) {
            
        }];
    }else{

        [JCKJDriverRequestTool driverstopSuccess:^{
            [self stopButton:YES];
        } failure:^(NSError *error) {
            
        }];
        
    }
    
    
    
}

-(void)stopButton:(BOOL)isStop{
    
    
    if (isStop) {
        [self.faCheButton setBackgroundColor:LYQ_COLOR_WITH_HEX(0xE8724E)];
        self.faCheButton.layer.borderColor = [UIColor clearColor].CGColor;
        self.faCheButton.layer.borderWidth = 0.0f;
        [self.faCheButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }else{
    
        [self.faCheButton setBackgroundColor:LYQ_COLOR_WITH_HEX(0x1A1B1B)];
        self.faCheButton.layer.borderColor = LYQ_COLOR_WITH_HEX(0xE8724E).CGColor;
        self.faCheButton.layer.borderWidth = 1.0f;
        [self.faCheButton setTitleColor:LYQ_COLOR_WITH_HEX(0xE8724E) forState:UIControlStateNormal];
    }
}

-(void)changFaCheBUttonStatus:(BOOL)is_zaiXian{
    
    if (is_zaiXian) {
        self.faCheButton.selected = YES;
        [self stopButton:NO];
    }else{
        self.faCheButton.selected = NO;
        [self stopButton:YES];

    }
    
    
}


-(void)JCKJLocationTool:(JCKJLocationTool *)tool LocationSuccessWithParam:(JCKJDriverParam *)param{
    
    MAMapPoint point1 = MAMapPointForCoordinate(CLLocationCoordinate2DMake(param.first_laitude_driver,param.first_longitude_driver));
    
    MAMapPoint point2 = MAMapPointForCoordinate(CLLocationCoordinate2DMake(param.latitude,param.longitude));


    
    CLLocationDistance distance = MAMetersBetweenMapPoints(point1,point2);
    
    self.param = param;
    
    if (self.isDD_QX) {
        self.param.change = 1;
    }else{
        self.param.change = 0;
    }
    
    param.mileage = distance;
    
    [JCKJDriverRequestTool driverrefreshParam:self.param success:^(JCKJDriverOrder *order) {
        
        
        [[NSNotificationCenter defaultCenter] postNotificationName:jckj_driver_OrderNoteName object:nil userInfo:order.mj_keyValues];
        
        if (order.isJieDan) {
            [self loadPassengerOrder:order];
             self.isDriverJieDan = YES;
        }
        
        if (order.isZaiXian) {
            [self changFaCheBUttonStatus:YES];
        }else{
            [self changFaCheBUttonStatus:NO];
        }
        
        
        if (order.isDD_QX) {
            self.isDD_QX = YES;
        }else{
            self.isDD_QX = NO;
        }
        
        
        
        
    } failure:^(NSError *error) {
        
    }];
}
- (IBAction)orderClick:(UIButton *)sender {
    
    JCKJDriverOrderController *driverOrderVC = [[JCKJDriverOrderController alloc] init];
    [self.navigationController pushViewController:driverOrderVC animated:YES];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.isDriverJieDan = NO;
}


@end
