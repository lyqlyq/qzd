//
//  JCKJ_DH_ViewController.h
//  qzdDriver
//
//  Created by pro on 2018/4/14.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>



@class JCKJDriverOrder;

@interface JCKJ_DH_ViewController : UIViewController

@property (nonatomic ,strong) JCKJDriverOrder *model;

@property (nonatomic ,assign) BOOL isJie_passenger;

@end
