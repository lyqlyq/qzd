//
//  JCKJ_DH_ViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/14.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJ_DH_ViewController.h"
#import <AMapNaviKit/AMapNaviKit.h>

#import "JCKJDriverOrder.h"
#import "JCKJPassengerInfoModel.h"

@interface JCKJ_DH_ViewController ()<AMapNaviDriveManagerDelegate,AMapNaviDriveViewDelegate>

@property (nonatomic, strong) AMapNaviDriveView *driveView;
@property (nonatomic, strong) AMapNaviPoint *startPoint;
@property (nonatomic, strong) AMapNaviPoint *endPoint;

@end

@implementation JCKJ_DH_ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
   
    if (self.isJie_passenger) {
         // 接乘客
        self.startPoint = [AMapNaviPoint locationWithLatitude:self.model.latitude longitude:self.model.longitude];
        self.endPoint   = [AMapNaviPoint locationWithLatitude:self.model.order.startLatitude longitude:self.model.order.statrLongitude];

        
    }else{
        // 送乘客
        self.startPoint = [AMapNaviPoint locationWithLatitude:self.model.order.startLatitude longitude:self.model.order.statrLongitude];
        self.endPoint   = [AMapNaviPoint locationWithLatitude:self.model.order.endLatitude longitude:self.model.order.endLongitude];

    }
     [[AMapNaviDriveManager sharedInstance] setDelegate:self];
    if (self.driveView == nil)
    {
        self.driveView = [[AMapNaviDriveView alloc] initWithFrame:CGRectMake(0, LYQ_NAV_H, LYQ_SCREEN_W, LYQ_SCREEN_H - LYQ_NAV_H)];
        [self.driveView setDelegate:self];
    }
    //将AMapNaviManager与AMapNaviDriveView关联起来
    [[AMapNaviDriveManager sharedInstance] addDataRepresentative:self.driveView];
    //将AManNaviDriveView显示出来
    [self.view addSubview:self.driveView];
    
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    //路径规划
    [[AMapNaviDriveManager sharedInstance] calculateDriveRouteWithStartPoints:@[self.startPoint]
                                                                    endPoints:@[self.endPoint]
                                                                    wayPoints:nil
                                                              drivingStrategy:AMapNaviDrivingStrategySingleDefault];
}

//路径规划成功后，开始模拟导航
- (void)driveManagerOnCalculateRouteSuccess:(AMapNaviDriveManager *)driveManager
{
    [[AMapNaviDriveManager sharedInstance] startEmulatorNavi];
}
- (void)driveViewCloseButtonClicked:(AMapNaviDriveView *)driveView{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)dealloc{
    
    [[AMapNaviDriveManager sharedInstance] stopNavi];
    self.driveView = nil;
    
}

@end
