//
//  JCKJDriverOrderController.m
//  qzdDriver
//
//  Created by pro on 2018/3/23.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverOrderController.h"
#import "JCKJDriverOrderCell.h"

#import "JCKJDriverRequestTool.h"
#import "JCKJJZModel.h"

@interface JCKJDriverOrderController ()<UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *todayOrderButton;
@property (weak, nonatomic) IBOutlet UIButton *historyOrderButton;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lien_X_Const;

@property (nonatomic ,strong) UIButton *seleButton;
@property (weak, nonatomic) IBOutlet UIScrollView *srcView;

@property (nonatomic ,strong) UITableView *oneTableView;

@property (nonatomic ,strong) UITableView *twoTableView;

@property (nonatomic ,strong) NSMutableArray *oneModels;
@property (nonatomic ,strong) NSMutableArray *twoModels;


@end

@implementation JCKJDriverOrderController

-(NSMutableArray *)oneModels{
    if (_oneModels == nil) {
        _oneModels = [NSMutableArray array];
    }
    return _oneModels;
    
}

-(NSMutableArray *)twoModels{
    
    if (_twoModels == nil) {
        _twoModels = [NSMutableArray array];
    }
    return _twoModels;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"订单";
    
    self.seleButton = self.todayOrderButton;
    
    self.oneTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, LYQ_SCREEN_W, self.srcView.xmg_height) style:UITableViewStylePlain];

    self.oneTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.twoTableView = [[UITableView alloc] initWithFrame:CGRectMake(LYQ_SCREEN_W, 0, LYQ_SCREEN_W, self.srcView.xmg_height) style:UITableViewStylePlain];
    self.twoTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.oneTableView.contentInset = UIEdgeInsetsMake(0, 0, 40, 0);
    self.twoTableView.contentInset = UIEdgeInsetsMake(0, 0, 40, 0);

    
    [self.srcView addSubview:self.oneTableView];
    [self.srcView addSubview:self.twoTableView];
    
    self.oneTableView.delegate = self;
    self.oneTableView.dataSource = self;
    
    self.twoTableView.dataSource = self;
    self.twoTableView.delegate = self;
    
    self.srcView.contentSize = CGSizeMake(LYQ_SCREEN_W * 2 , 0 );
    self.srcView.bounces = YES;
    self.srcView.pagingEnabled = YES;
    self.srcView.delegate = self;
    
    self.twoTableView.backgroundColor = LYQ_COLOR_WITH_HEX(0xf5f5f5);
    self.oneTableView.backgroundColor = LYQ_COLOR_WITH_HEX(0xf5f5f5);
    
    
    [JCKJDriverRequestTool getfastorderlistSuccess:^(NSMutableArray *models) {
        
        [models enumerateObjectsUsingBlock:^(JCKJJZModel *model, NSUInteger idx, BOOL * _Nonnull stop) {
            
            if ([model.today isEqualToString:@"2"]) {
                [self.twoModels addObject:model];
            }else{
                [self.oneModels addObject:model];
            }
            
        }];
        
        [self.oneTableView reloadData];
        
        [self.twoTableView reloadData];
        
    } failure:^(NSError *error) {
        
    }];

    
    
    
}

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (tableView == self.oneTableView) {
        
        return self.oneModels.count;
        
    }else{
        
        return self.twoModels.count;
    }
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    JCKJDriverOrderCell *cell = [JCKJDriverOrderCell driverOrderCellWithTableView:tableView];
    
    if (tableView == self.oneTableView) {
        
        cell.model = self.oneModels[indexPath.row];
        
    }else{
        
        cell.model = self.twoModels[indexPath.row];
    }

    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 155.0f;
}


-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
   
    CGFloat offset_x =  scrollView.contentOffset.x;
    
    if (self.srcView == scrollView) {
        if (offset_x == 0) {
            [self todayClick:self.todayOrderButton];
        }else{
            
            [self histClick:self.historyOrderButton];
        }
        
    }
    
}

- (IBAction)todayClick:(UIButton *)sender {
    self.seleButton.selected = NO;
    sender.selected = YES;
    self.seleButton = sender;
    
    [UIView animateWithDuration:0.2 animations:^{
        self.lien_X_Const.constant = 0;
        [self.view layoutIfNeeded];
    }];
    
    [UIView animateWithDuration:0.2 animations:^{
        self.srcView.contentOffset = CGPointMake(0, 0);
    }];
    
    
}
- (IBAction)histClick:(UIButton *)sender {
    
    self.seleButton.selected = NO;
    sender.selected = YES;
    self.seleButton = sender;
    
    [UIView animateWithDuration:0.2 animations:^{
        self.lien_X_Const.constant = LYQ_SCREEN_W * 0.5;
        [self.view layoutIfNeeded];
        [self.twoTableView reloadData];
    }];
    
    [UIView animateWithDuration:0.2 animations:^{
        self.srcView.contentOffset = CGPointMake(LYQ_SCREEN_W, 0);
        [self.oneTableView reloadData];
    }];
    
}


@end
