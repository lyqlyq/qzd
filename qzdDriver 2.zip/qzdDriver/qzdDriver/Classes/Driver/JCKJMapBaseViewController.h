//
//  JCKJMapBaseViewController.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/20.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MAMapKit/MAMapKit.h>
#import <AMapSearchKit/AMapSearchKit.h>

@class LYQAddressModel;
@interface JCKJMapBaseViewController : UIViewController <MAMapViewDelegate,AMapSearchDelegate>

@property (nonatomic ,strong) AMapReGeocodeSearchRequest *regeo;
@property (nonatomic, strong) AMapSearchAPI *search;
@property (nonatomic ,strong) MAMapView *mapView;


@end
