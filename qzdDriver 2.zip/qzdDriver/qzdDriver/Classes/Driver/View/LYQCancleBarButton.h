//
//  LYQCancleBarButton.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/5.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYQCancleBarButton : UIBarButtonItem


+(UIBarButtonItem *)addItemWithImage:(UIImage *)image target:(id)target action:(SEL)action;
+(UIBarButtonItem *)addItemButton:(id)target action:(SEL)action Title:(NSString *)title;
@end
