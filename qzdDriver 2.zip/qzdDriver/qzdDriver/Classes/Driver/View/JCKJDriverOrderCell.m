//
//  JCKJDriverOrderCell.m
//  qzdDriver
//
//  Created by pro on 2018/3/26.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverOrderCell.h"
#import <UIButton+SGImagePosition.h>
#import "JCKJJZModel.h"
#import "NSString+JCKJAttString.h"
#import <UIImageView+WebCache.h>
#import "JCKJPassengerModel.h"

@interface JCKJDriverOrderCell()

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *time;

@property (weak, nonatomic) IBOutlet UIButton *phoneButton;
@property (weak, nonatomic) IBOutlet UIButton *priceButton;
@property (weak, nonatomic) IBOutlet UIButton *start;
@property (weak, nonatomic) IBOutlet UIButton *end;
@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;

@property (weak, nonatomic) IBOutlet UIImageView *sexImage;

@end

@implementation JCKJDriverOrderCell

- (void)awakeFromNib {
    [super awakeFromNib];
   
    [self.phoneButton SG_imagePositionStyle:SGImagePositionStyleRight spacing:5];
    
}

-(void)setModel:(JCKJJZModel *)model{
       _model = model;
    
    [self.start setTitle:model.startplace forState:UIControlStateNormal];
    [self.end setTitle:model.endplace forState:UIControlStateNormal];
    self.time.text = model.time;
    [self.priceButton setAttributedTitle:[NSString getMoneyAtt_redText:model.price] forState:UIControlStateNormal];
    
    [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:model.passenger.head] placeholderImage:JCKJ_headerImage];
    
    if (model.passenger.sex.integerValue  == 1) {
        self.sexImage.image = [UIImage imageNamed:@"man"];
    }else{
        self.sexImage.image = [UIImage imageNamed:@"woman"];
    }
    self.name.text = model.passenger.nick;
    
}

+(instancetype)driverOrderCellWithTableView:(UITableView *)tableView{
    
    JCKJDriverOrderCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    
    if (cell == nil) {
        cell = [JCKJDriverOrderCell xmg_viewFromXib];
    }
    return cell;
    
}
- (IBAction)call:(UIButton *)sender {

    LYQCall_phone(self.model.passenger.phone);
}


@end
