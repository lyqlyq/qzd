//
//  JCKJDriverOrderCell.h
//  qzdDriver
//
//  Created by pro on 2018/3/26.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


@class JCKJJZModel;
@interface JCKJDriverOrderCell : UITableViewCell

@property (nonatomic ,strong) JCKJJZModel *model;

+(instancetype)driverOrderCellWithTableView:(UITableView *)tableView;

@end
