//
//  LYQCancleBarButton.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/5.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQCancleBarButton.h"

@implementation LYQCancleBarButton



+(UIBarButtonItem *)addItemWithImage:(UIImage *)image target:(id)target action:(SEL)action{
   
    image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStyleDone target:target action:action];
    return item;
    
}

+(UIBarButtonItem *)addItemButton:(id)target action:(SEL)action Title:(NSString *)title{
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:title style:1 target:target action:action];
    item.tintColor = LYQ_COLOR_WITH_HEX(0xECEAE0);
    [item setTitleTextAttributes:@{NSFontAttributeName:LYQ_SYS_FONT(14)} forState:UIControlStateNormal];
    [item setTitleTextAttributes:@{NSFontAttributeName:LYQ_SYS_FONT(14)} forState:UIControlStateSelected];
    return item;
    
}


@end
