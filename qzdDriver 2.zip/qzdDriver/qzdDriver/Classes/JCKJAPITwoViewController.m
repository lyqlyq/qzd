//
//  JCKJAPITwoViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/11.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJAPITwoViewController.h"

@interface JCKJAPITwoViewController ()

@end

@implementation JCKJAPITwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"接口测试2";


}
- (IBAction)selectVim:(id)sender {
}


@end
