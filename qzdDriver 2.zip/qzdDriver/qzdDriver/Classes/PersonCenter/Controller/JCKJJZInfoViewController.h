//
//  JCKJJZInfoViewController.h
//  qzdDriver
//
//  Created by pro on 2018/4/11.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^surcClickBlock)();

@class JCKJJZModel;
@interface JCKJJZInfoViewController : UIViewController


@property (nonatomic ,copy) surcClickBlock sureBlock;

@property (nonatomic ,strong) JCKJJZModel *model;

@end
