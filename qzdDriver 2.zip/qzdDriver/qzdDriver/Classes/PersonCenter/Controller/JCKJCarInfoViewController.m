//
//  JCKJCarInfoViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJCarInfoViewController.h"

@interface JCKJCarInfoViewController ()
@property (weak, nonatomic) IBOutlet UITextField *pingPai;
@property (weak, nonatomic) IBOutlet UITextField *carType;
@property (weak, nonatomic) IBOutlet UITextField *carVersion;
@property (weak, nonatomic) IBOutlet UITextField *carDate;

@property (weak, nonatomic) IBOutlet UITextField *carPaiLaineg;
@property (weak, nonatomic) IBOutlet UITextField *carUserCount;
@end

@implementation JCKJCarInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"车辆信息";
}

- (IBAction)sureClick:(id)sender {
}


@end
