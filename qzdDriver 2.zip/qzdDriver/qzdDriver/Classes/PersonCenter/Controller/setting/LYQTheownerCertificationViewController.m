
//
//  LYQTheownerCertificationViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQTheownerCertificationViewController.h"
#import "LYQJZAndXSZView.h"
#import "JCKJRZYQViewController.h"

#import "LYQUploadImageTool.h"
#import "JCKJDriverRequestTool.h"
#import "JCKJDriverParam.h"

#import "JCKJJZInfoViewController.h"
#import "JCKJDrivinglicenseInfoController.h"


@interface LYQTheownerCertificationViewController ()
@property (weak, nonatomic) IBOutlet UIButton *jz_Button;
@property (weak, nonatomic) IBOutlet UIButton *xsz_Button;
@property (weak, nonatomic) IBOutlet UIButton *tjsh_Button;
@property (weak, nonatomic) IBOutlet UIButton *jzfy_button;

@property (nonatomic ,strong) LYQJZAndXSZView *jaAndxszView;
@property (weak, nonatomic) IBOutlet UIButton *rzYaoqiu;

@property (nonatomic ,strong) JCKJDriverParam *param;

@end

@implementation LYQTheownerCertificationViewController

-(JCKJDriverParam *)param{
    if (_param == nil) {
        
        _param = [JCKJDriverParam param];
    }
    return _param;
}


-(LYQJZAndXSZView *)jaAndxszView{
    if (_jaAndxszView == nil) {
        _jaAndxszView = [LYQJZAndXSZView xmg_viewFromXib];
    }
    
    return _jaAndxszView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    self.title = @"车主认证";
    
    LYQ_WEAK_SELF(self);
    
    [self.rzYaoqiu cornerWithRadiusSize:7];
    
    self.jaAndxszView.choseImage = ^(UIImage *seleImage){
        
        
        
        [LYQUploadImageTool uploadImage:seleImage success:^(NSString *url) {
            
            weakself.param.filename = url;

            
          if (weakself.jaAndxszView.type == viewType_JZ) {
              
              [JCKJDriverRequestTool authdriver_Param:weakself.param success:^(JCKJJZModel *order) {
                  JCKJJZInfoViewController *jzVC = [[JCKJJZInfoViewController alloc] init];
                  
                  jzVC.model = order;
                  jzVC.sureBlock = ^{
                      [weakself.jz_Button setBackgroundImage:seleImage forState:UIControlStateNormal];
                      weakself.jz_Button.selected = YES;
                      [weakself changeTJButtonstatus];
                  };
                  [weakself.navigationController pushViewController:jzVC animated:YES];

                  
              } failure:^(NSError *error) {
                  
              }];
              
          }
            if (weakself.jaAndxszView.type == viewType_XSZ) {
                
                
                [JCKJDriverRequestTool authcarParam:weakself.param success:^(JCKJJZModel *order) {
                    
                    JCKJDrivinglicenseInfoController *xszVC = [[JCKJDrivinglicenseInfoController alloc] init];
                    xszVC.model = order;
                    [weakself.navigationController pushViewController:xszVC animated:YES];
                    
                    
                } failure:^(NSError *error) {
                    
                }];
            
            }
            
            if (weakself.jaAndxszView.type == viewType_JZFY) {
                
                
                [LYQUploadImageTool uploadImage:seleImage success:^(NSString *url) {
                    weakself.param.driver_B_url = url;
                    weakself.param.type = 3;
   
                    [JCKJDriverRequestTool authdriver_Param:weakself.param success:^(JCKJJZModel *order) {
                        
                        [weakself.jzfy_button setBackgroundImage:seleImage forState:UIControlStateNormal];
                         weakself.jzfy_button.selected = YES;
                        
                        [weakself changeTJButtonstatus];
                        
                    } failure:^(NSError *error) {
                        
                    }];
                    
                    
                    
                    
                } failure:^{
                    
                }];
                
                
                
            }
            
            
            
        } failure:^{
            
        }];
        
        
//        if (weakself.jaAndxszView.type == viewType_JZ) {
//            [weakself.jz_Button setBackgroundImage:seleImage forState:UIControlStateNormal];
//            weakself.jz_Button.selected = YES;
//        }else if(weakself.jaAndxszView.type == viewType_XSZ){
//            [weakself.xsz_Button setBackgroundImage:seleImage forState:UIControlStateNormal];
//            weakself.xsz_Button.selected = YES;
//        }else{
//            [weakself.jzfy_button setBackgroundImage:seleImage forState:UIControlStateNormal];
//            weakself.jzfy_button.selected = YES;
//
//        }
//
//
//        [weakself changeTJButtonstatus];
       
    };
    
}

-(void)changeTJButtonstatus{
    
    
    if (self.jz_Button.selected && self.xsz_Button.selected && self.jzfy_button.selected) {
        self.tjsh_Button.userInteractionEnabled = YES;
        [self.tjsh_Button setBackgroundColor:LYQ_COLOR_WITH_HEX(0x232323)];
    }else{
        self.tjsh_Button.userInteractionEnabled = NO;
        [self.tjsh_Button setBackgroundColor:LYQ_COLOR_WITH_HEX(0x565553)];

    }
    
    
    
}

- (IBAction)jzButtonClick:(UIButton *)sender {
    
    self.jaAndxszView.type = viewType_JZ;
    
    [self.jaAndxszView show];
    
    
}
- (IBAction)xszButtonClick:(UIButton *)sender {
    
    self.jaAndxszView.type = viewType_XSZ;
    
    [self.jaAndxszView show];
    
}
- (IBAction)jzfyButtonClick:(UIButton *)sender {
    
    self.jaAndxszView.type = viewType_JZFY;
    
    [self.jaAndxszView show];
}



- (IBAction)tjsh_ButtonClick:(UIButton *)sender {
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)rzyaoqiu:(UIButton *)sender {
    
    JCKJRZYQViewController *rzVC = [[JCKJRZYQViewController alloc] init];
    
    [self.navigationController pushViewController:rzVC animated:YES];
    
}

@end
