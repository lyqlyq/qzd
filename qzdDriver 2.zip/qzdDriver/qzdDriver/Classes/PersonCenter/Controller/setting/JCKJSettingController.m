//
//  JCKJSettingController.m
//  qzdDriver
//
//  Created by pro on 2018/4/4.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJSettingController.h"
#import "JCKJChangePassController.h"
#import "JCKJChangePhoneViewController.h"
#import "LYQHelpViewController.h"

@interface JCKJSettingController ()

@end

@implementation JCKJSettingController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"设置";
    
    
}

/**重置密码*/
- (IBAction)changePassClick:(UIButton *)sender {
    JCKJChangePassController *passVC = [[JCKJChangePassController alloc] init];
    [self.navigationController pushViewController:passVC animated:YES];
}

- (IBAction)changePhone:(UIButton *)sender {
    
    JCKJChangePhoneViewController *phoneVC = [[JCKJChangePhoneViewController alloc] init];
    [self.navigationController pushViewController:phoneVC animated:YES];
    
}
- (IBAction)helpClick:(UIButton *)sender {
    
    LYQHelpViewController *helpVC = [[LYQHelpViewController alloc] init];
    
    [self.navigationController pushViewController:helpVC animated:YES];
}


@end
