//
//  JCKJChangePassController.m
//  qzdDriver
//
//  Created by pro on 2018/4/4.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJChangePassController.h"
#import "JCKJNextPassViewController.h"
#import "LYQTextFiledMangerTool.h"

#import <UIButton+SGCountdown.h>
#import "JCKJLoginParam.h"

#import "JCKJLoginRequestTool.h"

@interface JCKJChangePassController ()<LYQTextFiledMangerToolDelegate>
@property (weak, nonatomic) IBOutlet UIButton *codeButton;

@property (weak, nonatomic) IBOutlet UITextField *phoneTextF;
@property (nonatomic ,strong) JCKJLoginParam *param;

@property (nonatomic ,strong) LYQTextFiledMangerTool *TextFTool;

@property (weak, nonatomic) IBOutlet UIButton *nextButton;

@end

@implementation JCKJChangePassController

-(LYQTextFiledMangerTool *)TextFTool{
    if (_TextFTool == nil) {
        _TextFTool = [[LYQTextFiledMangerTool alloc] init];
       
        _TextFTool.delegate = self;
    }
    return  _TextFTool;
    
}

-(JCKJLoginParam *)param{
    if (_param == nil) {
        
        _param = [JCKJLoginParam param];
    }
    return _param;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"重置密码";
    
    self.codeButton.highlighted  = NO;

}


/**下一步*/
- (IBAction)nextButton:(UIButton *)sender {
    
    JCKJNextPassViewController *nextVC = [[JCKJNextPassViewController alloc] init];
    [self.navigationController pushViewController:nextVC animated:YES];
}
- (IBAction)codeButtonClick:(UIButton *)sender {
    
    self.param.phone = self.phoneTextF.text;
    self.codeButton.userInteractionEnabled = NO;
    [JCKJLoginRequestTool POSTCodeParam:self.param success:^(JCKJLoginModel *model) {
        [self.codeButton SG_countdownWithSecond:60 completion:^{
            [self.codeButton setTitle:@"获取验证码" forState:UIControlStateNormal];
            self.codeButton.userInteractionEnabled = YES;
        }];
    } failure:^(NSError *error) {
        
    }];
    
   
    
}

-(NSMutableArray<UITextField *> *)textFiledMangerWithTextFiledArray:(LYQTextFiledMangerTool *)manger{
    
    NSMutableArray *textFS = [NSMutableArray array];
    [textFS addObject:self.phoneTextF];
    return textFS;
}

-(void)textFiledMangerCanBeClick:(LYQTextFiledMangerTool *)manger{
    [self.nextButton setBackgroundColor:jckj_LightRedClick_Color];
    self.nextButton.userInteractionEnabled = YES;
}
-(void)textFiledMangerNoClickAble:(LYQTextFiledMangerTool *)manger{
    [self.nextButton setBackgroundColor:jckj_NOclick_Color];
    self.nextButton.userInteractionEnabled = NO;
}



@end
