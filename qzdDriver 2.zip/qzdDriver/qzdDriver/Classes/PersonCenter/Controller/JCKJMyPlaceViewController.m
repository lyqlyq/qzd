//
//  JCKJMyPlaceViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJMyPlaceViewController.h"

#import "JCKJPlaceCell.h"

@interface JCKJMyPlaceViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation JCKJMyPlaceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
  
    self.title = @"我的行程";
    
    self.tableView.contentInset = UIEdgeInsetsMake(5, 0, 0, 0);
    
}


#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 10;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5.0f;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    JCKJPlaceCell *cell = [JCKJPlaceCell placeCellWithTableView:tableView];
    
    
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 144.0f;
}

@end
