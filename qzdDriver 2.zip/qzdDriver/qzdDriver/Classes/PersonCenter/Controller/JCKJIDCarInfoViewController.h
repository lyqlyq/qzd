//
//  JCKJIDCarInfoViewController.h
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^uploadSuccessBlock)();

@class JCKJJZModel;
@interface JCKJIDCarInfoViewController : UIViewController


@property (nonatomic ,copy) uploadSuccessBlock successBlock;

@property (nonatomic ,strong)  JCKJJZModel*model;

@end
