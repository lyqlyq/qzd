//
//  JCKJIDCar_RZViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJIDCar_RZViewController.h"
#import "JCKJRZYQViewController.h"
#import "LYQJZAndXSZView.h"
#import "LYQUploadImageTool.h"
#import "JCKJDriverRequestTool.h"
#import "JCKJDriverParam.h"
#import "JCKJIDCarInfoViewController.h"

#import "LYQTheownerCertificationViewController.h"
#import "JCKJJZModel.h"


@interface JCKJIDCar_RZViewController ()
@property (weak, nonatomic) IBOutlet UIButton *rzLbale;
@property (weak, nonatomic) IBOutlet UIButton *idCar_ZM;
@property (weak, nonatomic) IBOutlet UIButton *IdCar_FM;
@property (weak, nonatomic) IBOutlet UIButton *nextButton;
@property (nonatomic ,strong) JCKJDriverParam *param;
@property (nonatomic ,strong) LYQJZAndXSZView *jaAndxszView;

@end

@implementation JCKJIDCar_RZViewController

-(JCKJDriverParam *)param{
    if (_param == nil) {
        _param = [JCKJDriverParam param];
    }
    return _param;
}

-(LYQJZAndXSZView *)jaAndxszView{
    if (_jaAndxszView == nil) {
        _jaAndxszView = [LYQJZAndXSZView xmg_viewFromXib];
    }
    
    return _jaAndxszView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.rzLbale cornerWithRadiusSize:7];
    self.title = @"车主认证";
    
//    JCKJDriverParam *param = [JCKJDriverParam param];
//
//    param.type = 3;
//    [JCKJDriverRequestTool authman_Param:param success:^(JCKJJZModel *order) {
//
//
//
//    } failure:^(NSError *error) {
//
//    }];
    
    
    LYQ_WEAK_SELF(self);
    
    self.jaAndxszView.choseImage = ^(UIImage *seleImage){
        if (weakself.jaAndxszView.type == viewType_SFZ_FM) {
            
            [LYQUploadImageTool uploadImage:seleImage success:^(NSString *url) {
                
                JCKJDriverParam *param = [JCKJDriverParam param];
                param.type  =3;
                param.cardurlb = url;
                
                [JCKJDriverRequestTool authman_Param:param success:^(JCKJJZModel *order) {
                    [weakself.IdCar_FM setImage:seleImage forState:UIControlStateNormal];
                    weakself.IdCar_FM.selected  = YES;
                    
                    [weakself changeNextButtonState];

                    
                } failure:^(NSError *error) {
                    
                }];
                
            } failure:^{
                
            }];
            
           

        }
        
        if (weakself.jaAndxszView.type == viewType_SFZ_ZM) {
            
        //    [weakself.idCar_ZM setBackgroundImage:seleImage forState:UIControlStateNormal];
            
            [LYQUploadImageTool uploadImage:seleImage success:^(NSString *url) {
                weakself.param.filename = url;
                
                [JCKJDriverRequestTool authman_Param:weakself.param success:^(JCKJJZModel *order) {
                    
                    JCKJIDCarInfoViewController *sfzInfo = [[JCKJIDCarInfoViewController alloc] init];
                    sfzInfo.model = order;
                    sfzInfo.successBlock = ^{
                        [weakself.idCar_ZM setImage:seleImage forState:UIControlStateNormal];
                        weakself.idCar_ZM.selected  = YES;
                        [weakself changeNextButtonState];

                    };
                    [weakself.navigationController pushViewController:sfzInfo animated:YES];
                    
                } failure:^(NSError *error) {
                    
                }];
                
            } failure:^{
                
            }];
        }
        
        
        
    };
    
    
    
    
    
}

-(void)changeNextButtonState{
    
    if (self.IdCar_FM.selected && self.idCar_ZM.selected) {
        [self.nextButton setBackgroundColor:jckj_LightRedClick_Color];
        self.nextButton.userInteractionEnabled = YES;
    }
}

- (IBAction)zmClick:(UIButton *)sender {
    
    self.jaAndxszView.type = viewType_SFZ_ZM;
    [self.jaAndxszView show];
    
}

- (IBAction)fmClick:(UIButton *)sender {
    self.jaAndxszView.type = viewType_SFZ_FM;
    [self.jaAndxszView show];
    
    
}






- (IBAction)nextButton:(id)sender {
 
    LYQTheownerCertificationViewController *theVC = [[LYQTheownerCertificationViewController alloc] init];
    
    [self.navigationController pushViewController:theVC animated:YES];
    
}






- (IBAction)RzCLick:(UIButton *)sender {
    
    JCKJRZYQViewController *rzVC = [[JCKJRZYQViewController alloc] init];
    
    [self.navigationController pushViewController:rzVC animated:YES];
    
}

@end
