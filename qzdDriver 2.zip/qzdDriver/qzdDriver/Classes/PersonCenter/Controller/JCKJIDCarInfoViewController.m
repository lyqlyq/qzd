//
//  JCKJIDCarInfoViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJIDCarInfoViewController.h"

#import "JCKJJZModel.h"

#import "JCKJDriverParam.h"
#import "JCKJDriverRequestTool.h"

@interface JCKJIDCarInfoViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextF;
@property (weak, nonatomic) IBOutlet UITextField *sexTextF;
@property (weak, nonatomic) IBOutlet UITextField *mzTextF;
@property (weak, nonatomic) IBOutlet UITextField *briTextF;
@property (weak, nonatomic) IBOutlet UITextField *addressTextF;
@property (weak, nonatomic) IBOutlet UITextField *idCarNumTextF;


@end

@implementation JCKJIDCarInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"身份证信息";
    
    self.addressTextF.text = self.model.adress;
    self.briTextF.text = self.model.birthday;
    self.nameTextF.text = self.model.realname;
    self.mzTextF.text = self.model.nation;
    self.idCarNumTextF.text = self.model.carid;
    self.sexTextF.text = self.model.sex;
    
}
- (IBAction)sureClick:(UIButton *)sender {
    
    JCKJDriverParam *param = [JCKJDriverParam mj_objectWithKeyValues:self.model.mj_keyValues];
    param.type = 2;
    [JCKJDriverRequestTool authman_Param:param success:^(JCKJJZModel *order) {
        
        if (self.successBlock) {
            self.successBlock();
        }
        
        [self.navigationController popViewControllerAnimated:YES];
        
    } failure:^(NSError *error) {
        
    }];
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];


}


@end
