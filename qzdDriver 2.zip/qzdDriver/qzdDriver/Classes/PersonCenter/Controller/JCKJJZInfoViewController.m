//
//  JCKJJZInfoViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/11.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJJZInfoViewController.h"
#import "JCKJJZModel.h"
#import "JCKJDriverRequestTool.h"
#import "JCKJDriverParam.h"

@interface JCKJJZInfoViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextF;
@property (weak, nonatomic) IBOutlet UITextField *sexTextF;
@property (weak, nonatomic) IBOutlet UITextField *gjTextF;
@property (weak, nonatomic) IBOutlet UITextField *addressTextF;
@property (weak, nonatomic) IBOutlet UITextField *briTextF;
@property (weak, nonatomic) IBOutlet UITextField *timeTextF;
@property (weak, nonatomic) IBOutlet UITextField *cxTextF;
@property (weak, nonatomic) IBOutlet UITextField *dateTextF;

@end

@implementation JCKJJZInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"驾照信息";
    
    self.nameTextF.text = self.model.name;
    self.sexTextF.text = self.model.sex;
    self.gjTextF.text = self.model.nation;
    self.addressTextF.text = self.model.address;
    self.briTextF.text = self.model.birthday;
    self.timeTextF.text = self.model.drivecarbegintime;
    self.cxTextF.text = self.model.drivecarmodel;
    self.dateTextF.text = self.model.drivecarbelongto;
    
    
    
    
}

- (IBAction)sureClick:(UIButton *)sender {
    
    
    JCKJDriverParam *param = [JCKJDriverParam mj_objectWithKeyValues:self.model.mj_keyValues];
    param.type = 2;
    
    [JCKJDriverRequestTool authdriver_Param:param success:^(JCKJJZModel *order) {
        
        if (self.sureBlock) {
            self.sureBlock();
        }
        [self.navigationController popViewControllerAnimated:YES];
    } failure:^(NSError *error) {
        
    }];
    
    
    
}

@end
