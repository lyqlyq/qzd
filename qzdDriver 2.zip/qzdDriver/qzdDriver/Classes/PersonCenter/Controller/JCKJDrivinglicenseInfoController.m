//
//  JCKJDrivinglicenseInfoController.m
//  qzdDriver
//
//  Created by pro on 2018/4/11.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDrivinglicenseInfoController.h"
#import "JCKJJZModel.h"
#import "JCKJChoseColorView.h"
#import "JCKJCarInfoViewController.h"

#import "JCKJDriverParam.h"
#import "JCKJDriverRequestTool.h"


@interface JCKJDrivinglicenseInfoController ()
@property (weak, nonatomic) IBOutlet UITextField *carNumber;
@property (weak, nonatomic) IBOutlet UITextField *carType;
@property (weak, nonatomic) IBOutlet UITextField *carOwner;
@property (weak, nonatomic) IBOutlet UITextField *address;
@property (weak, nonatomic) IBOutlet UITextField *sy_type;
@property (weak, nonatomic) IBOutlet UITextField *car_xhao;
@property (weak, nonatomic) IBOutlet UITextField *car_SBDM;
@property (weak, nonatomic) IBOutlet UITextField *registDate;
@property (weak, nonatomic) IBOutlet UITextField *fzrq_date;
@property (weak, nonatomic) IBOutlet UILabel *carColorLabel;


@end

@implementation JCKJDrivinglicenseInfoController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"行驶证信息";
    
    self.address.text = self.model.address;
    self.carType.text = self.model.modetype;
    self.carNumber.text = self.model.carunm;
    self.car_SBDM.text = self.model.carvin;
    self.carOwner.text = self.model.name;
    self.sy_type.text = self.model.usetype;
    self.registDate.text = self.model.regtime;
    self.fzrq_date.text = self.model.gettime;
    self.car_xhao.text = self.model.cartype;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)choseColorClick:(UIButton *)sender {
    
    JCKJChoseColorView *choseView = [JCKJChoseColorView xmg_viewFromXib];
    choseView.seleColorBlock = ^(UIColor *seleColor, NSString *colorText) {
        self.carColorLabel.text = colorText;
    };
    
    [choseView show];
    
}

/**确认信息*/
- (IBAction)nextClick:(UIButton *)sender {
    
    JCKJDriverParam *param = [JCKJDriverParam mj_objectWithKeyValues:self.model.mj_keyValues];
    param.type = 2;
    param.color = self.carColorLabel.text;

    [JCKJDriverRequestTool authcarParam:param success:^(JCKJJZModel *order) {
        
        [self.navigationController popViewControllerAnimated:YES];
        
    } failure:^(NSError *error) {
        
    }];
    
}


@end
