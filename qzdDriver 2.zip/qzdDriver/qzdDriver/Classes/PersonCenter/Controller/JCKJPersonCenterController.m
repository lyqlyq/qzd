//
//  JCKJPersonCenterController.m
//  qzdDriver
//
//  Created by pro on 2018/4/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPersonCenterController.h"
#import <UIButton+SGImagePosition.h>

#import "JCKJMyPlaceViewController.h"
#import "JCKJMoenyViewController.h"
#import "JCKJSettingController.h"

#import "JCKJDriverRequestTool.h"
#import "JCKJDriverInfoModel.h"
#import <UIImageView+WebCache.h>

#import "JCKJIDCar_RZViewController.h"
#import "LYQTheownerCertificationViewController.h"


@interface JCKJPersonCenterController ()
@property (weak, nonatomic) IBOutlet UIButton *placeButton;
@property (weak, nonatomic) IBOutlet UIButton *moenyButton;
@property (weak, nonatomic) IBOutlet UIButton *settingButton;

//头像
@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
//昵称
@property (weak, nonatomic) IBOutlet UILabel *nickNameLabel;
//性别
@property (weak, nonatomic) IBOutlet UIImageView *sexImage;
//星级
@property (weak, nonatomic) IBOutlet UILabel *xjLabel;
@property (weak, nonatomic) IBOutlet UILabel *rezhengLable;

@end

@implementation JCKJPersonCenterController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self.placeButton SG_imagePositionStyle:SGImagePositionStyleTop spacing:5];
    [self.moenyButton SG_imagePositionStyle:SGImagePositionStyleTop spacing:5];
    [self.settingButton SG_imagePositionStyle:SGImagePositionStyleTop spacing:5];
    
    [self.rezhengLable cornerWithRadiusSize:7];
    
    self.rezhengLable.layer.borderColor = jckj_COLOR_driverMain.CGColor;
    self.rezhengLable.layer.borderWidth = 1.0f;
    
    
    [JCKJDriverRequestTool get_detailsSuccess:^(JCKJDriverInfoModel *model) {
        [self.headerImageView sd_setImageWithURL:[NSURL URLWithString:model.head] placeholderImage:JCKJ_headerImage];
        
        self.nickNameLabel.text = model.nick;
        self.sexImage.image = model.sexImage;
    } failure:^(NSError *error) {
        
    }];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/**我的行程*/
- (IBAction)myPlaceClick:(UIButton *)sender {
    
    JCKJMyPlaceViewController *myPlaceVC = [[JCKJMyPlaceViewController alloc] init];
    [self.navigationController pushViewController:myPlaceVC animated:YES];
}
/**钱包*/
- (IBAction)qianBaoClick:(UIButton *)sender {
    
    JCKJMoenyViewController *moneyVC = [[JCKJMoenyViewController alloc] init];
    [self.navigationController pushViewController:moneyVC animated:YES];
}
/**设置*/
- (IBAction)settingClick:(UIButton *)sender {
    
    JCKJSettingController *settingVC = [[JCKJSettingController alloc] init];
    [self.navigationController pushViewController:settingVC animated:YES];
}

- (IBAction)reZhengClick:(id)sender {
    
//    LYQTheownerCertificationViewController *e = [[LYQTheownerCertificationViewController alloc] init];
//    [self.navigationController pushViewController:e animated:YES];
    
    
    JCKJIDCar_RZViewController *idCarVc = [[JCKJIDCar_RZViewController alloc] init];

    [self.navigationController pushViewController:idCarVc animated:YES];
}

@end
