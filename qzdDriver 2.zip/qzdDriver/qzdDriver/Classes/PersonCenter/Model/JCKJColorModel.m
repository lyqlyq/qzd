//
//  JCKJColorModel.m
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJColorModel.h"

@implementation JCKJColorModel


+(NSMutableArray<JCKJColorModel *> *)colorModelsArrays{
    
    NSMutableArray *textArrays = [NSMutableArray array];
    [textArrays addObject:@"黑色"];
    [textArrays addObject:@"银色"];
    [textArrays addObject:@"灰色"];
    
    [textArrays addObject:@"白色"];
    [textArrays addObject:@"红色"];
    [textArrays addObject:@"金色"];
    
    [textArrays addObject:@"蓝色"];
    [textArrays addObject:@"棕色"];
    [textArrays addObject:@"紫色"];
    
    [textArrays addObject:@"绿色"];
    [textArrays addObject:@"粉色"];
    [textArrays addObject:@"黄色"];
    
    NSMutableArray *colorArrays = [NSMutableArray array];
    
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0x1A1B1B)];
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0xD3D4D8)];
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0x8D8D8F)];
    
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0xFFFFFF)];
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0xE84E4E)];
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0xD8AE2F)];
    
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0x2433C0)];
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0x694807)];
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0xB44EE8)];
    
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0x1D7206)];
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0xF197A0)];
    [colorArrays addObject:LYQ_COLOR_WITH_HEX(0xF0C238)];

    NSMutableArray *models = [NSMutableArray array];
    
    for (NSInteger i = 0 ; i < textArrays.count; i ++) {
        JCKJColorModel *model = [[JCKJColorModel alloc] init];
        model.color = colorArrays[i];
        model.text = textArrays[i];
        [models addObject:model];
    }
    
   
    return models;
  
}

@end
