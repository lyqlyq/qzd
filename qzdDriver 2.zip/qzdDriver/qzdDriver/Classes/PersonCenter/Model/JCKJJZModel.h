//
//  JCKJJZModel.h
//  qzdDriver
//
//  Created by pro on 2018/4/11.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJPassengerModel;
@interface JCKJJZModel : NSObject


@property (nonatomic ,copy) NSString *address;

@property (nonatomic ,copy) NSString *birthday;

@property (nonatomic ,copy) NSString *drivecarbegintime;


@property (nonatomic ,copy) NSString *drivecarbelongto;

@property (nonatomic ,copy) NSString *drivecarmodel;

@property (nonatomic ,copy) NSString *drivecarnum;

@property (nonatomic ,copy) NSString *name;

@property (nonatomic ,copy) NSString *nation;

@property (nonatomic ,copy) NSString *sex;


@property (nonatomic ,copy) NSString *realname;

@property (nonatomic ,copy) NSString *carid;

@property (nonatomic ,strong) NSString *adress;

@property (nonatomic ,copy) NSString *cartype;
@property (nonatomic ,copy) NSString *carunm;
@property (nonatomic ,copy) NSString *carvin;
@property (nonatomic ,copy) NSString *comment;
@property (nonatomic ,copy) NSString *engineunm;
@property (nonatomic ,copy) NSString *gettime;
@property (nonatomic ,copy) NSString *regtime;
@property (nonatomic ,copy) NSString *usetype;
@property (nonatomic ,copy) NSString *modetype;

@property (nonatomic ,copy) NSString *filename;



//订单
@property (nonatomic ,copy) NSString *appointmentime;
@property (nonatomic ,copy) NSString *driverid;
@property (nonatomic ,copy) NSString *endcoordinate;
@property (nonatomic ,copy) NSString *endplace;
@property (nonatomic ,copy) NSString *isappointment;
@property (nonatomic ,copy) NSString *orderunm;
@property (nonatomic ,copy) NSString *price;
@property (nonatomic ,copy) NSString *passengerid;
@property (nonatomic ,copy) NSString *startcoordinate;
@property (nonatomic ,copy) NSString *startplace;
@property (nonatomic ,copy) NSString *status;
@property (nonatomic ,copy) NSString *thinksmoney;
@property (nonatomic ,copy) NSString *time;
@property (nonatomic ,copy) NSString *today;
@property (nonatomic ,strong) JCKJPassengerModel *passenger;







@end
