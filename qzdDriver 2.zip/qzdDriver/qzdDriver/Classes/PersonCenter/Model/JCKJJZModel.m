//
//  JCKJJZModel.m
//  qzdDriver
//
//  Created by pro on 2018/4/11.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJJZModel.h"

@implementation JCKJJZModel


-(NSString *)birthday{
    return [self dateString:_birthday];
}

-(NSString *)drivecarbegintime{
    
    return [self dateString:_drivecarbegintime];

}

-(NSString *)drivecarbelongto{
    
    NSArray *startEndDate  = [_drivecarbelongto componentsSeparatedByString:@"-"];
    NSString *startDate = [startEndDate firstObject];
    NSString *endDate = [startEndDate lastObject];

    NSString *startyear =  [startDate substringWithRange:NSMakeRange(0, 4)];
    NSString *startmonth = [startDate substringWithRange:NSMakeRange(4, 2)];
    NSString *startday = [startDate substringWithRange:NSMakeRange(6, 2)];
    
    NSString *endyear =  [endDate substringWithRange:NSMakeRange(0, 4)];
    NSString *endmonth = [endDate substringWithRange:NSMakeRange(4, 2)];
    NSString *endday = [endDate substringWithRange:NSMakeRange(6, 2)];
    
    
    return [NSString stringWithFormat:@"%@-%@-%@至%@-%@-%@",startyear,startmonth,startday,endyear,endmonth,endday];
    
}


-(NSString *)gettime{
    return [self dateString:_gettime];

}

-(NSString *)regtime{
    return [self dateString:_regtime];
}


-(NSString *)dateString:(NSString *)str{
    
    if (str.length < 8) {
        return @"";
    }
    
    NSString *year =[str substringWithRange:NSMakeRange(0, 4)];
    NSString *month = [str substringWithRange:NSMakeRange(4, 2)];
    NSString *day = [str substringWithRange:NSMakeRange(6, 2)];
    
    return [NSString stringWithFormat:@"%@-%@-%@",year,month,day];

}

@end
