//
//  JCKJColorModel.h
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJColorModel : NSObject


@property (nonatomic ,copy) UIColor *color;
@property (nonatomic ,copy) NSString *text;


+(NSMutableArray <JCKJColorModel *> *)colorModelsArrays;


@end
