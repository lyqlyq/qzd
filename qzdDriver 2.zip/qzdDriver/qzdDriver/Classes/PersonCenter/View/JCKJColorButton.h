//
//  JCKJColorButton.h
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


@class JCKJColorModel;
@interface JCKJColorButton : UIView

@property (weak, nonatomic) IBOutlet UIButton *clickButton;

@property (nonatomic ,assign) BOOL isSelect;

@property (nonatomic ,strong) JCKJColorModel *model;

+(instancetype)colorButton;

@end
