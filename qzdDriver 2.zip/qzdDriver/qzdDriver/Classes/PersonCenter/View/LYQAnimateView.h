//
//  LYQAnimateView.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/24.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYQAnimateView : UIView

@property (weak, nonatomic) IBOutlet UIView *bottomView;

@property (nonatomic ,assign) CGFloat bottomView_Height;

@property (nonatomic ,assign) BOOL istouViewNoDissmiss;

+(instancetype)animateViewWithBottomHeight:(CGFloat)height;



-(void)show;

-(void)dissmissWithCompletion:(void(^)())completion;


@end
