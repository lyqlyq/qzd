//
//  JCKJChoseColorView.h
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^choseBlock)(UIColor *seleColor,NSString *colorText);

@interface JCKJChoseColorView : UIView

@property (nonatomic ,copy) choseBlock seleColorBlock;

-(void)show;

@end
