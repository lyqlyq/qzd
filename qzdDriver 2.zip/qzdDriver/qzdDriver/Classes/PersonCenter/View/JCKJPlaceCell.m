//
//  JCKJPlaceCell.m
//  qzdDriver
//
//  Created by pro on 2018/4/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPlaceCell.h"

@interface JCKJPlaceCell()
@property (weak, nonatomic) IBOutlet UIView *bottomView;

@end

@implementation JCKJPlaceCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+(instancetype)placeCellWithTableView:(UITableView *)tableView{
    
    JCKJPlaceCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(self)];
    if (cell == nil) {
        cell = [JCKJPlaceCell xmg_viewFromXib];
    }
    return cell;
}

-(void)setFrame:(CGRect)frame{
    frame.origin.x = 5;
    frame.size.width = LYQ_SCREEN_W - 10;
    [super setFrame:frame];
}



@end
