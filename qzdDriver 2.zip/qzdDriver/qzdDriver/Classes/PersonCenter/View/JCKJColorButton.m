//
//  JCKJColorButton.m
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJColorButton.h"
#import "JCKJColorModel.h"

@interface JCKJColorButton ()

@property (weak, nonatomic) IBOutlet UIView *colorView;
@property (weak, nonatomic) IBOutlet UILabel *colorLabe;



@end


@implementation JCKJColorButton

-(void)awakeFromNib{
    [super awakeFromNib];
    [self.colorView cornerWithRadiusSize:7];
    [self cornerWithRadiusSize:4];
    
}

+(instancetype)colorButton{
    
    JCKJColorButton *colorButton = [JCKJColorButton xmg_viewFromXib];
    return colorButton;
}

-(void)setModel:(JCKJColorModel *)model{
    
    _model = model;
    
    self.colorView.backgroundColor = model.color;
    self.colorLabe.text = model.text;
    
}
-(void)setIsSelect:(BOOL)isSelect{
    
    _isSelect = isSelect;
    if (isSelect) {
        self.layer.borderWidth = 1;
        self.layer.borderColor = LYQ_COLOR_WITH_HEX(0xE8724E).CGColor;
    }else{
        self.layer.borderWidth = 0;
        self.layer.borderColor = [UIColor clearColor].CGColor;
    }
    
}

-(void)setFrame:(CGRect)frame{
    frame.size.width = 88;
    frame.size.height = 34;
    [super setFrame:frame];
}

@end
