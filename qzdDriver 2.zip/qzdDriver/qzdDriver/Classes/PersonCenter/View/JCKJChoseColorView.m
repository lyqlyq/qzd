//
//  JCKJChoseColorView.m
//  qzdDriver
//
//  Created by pro on 2018/4/12.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJChoseColorView.h"
#import "LYQAnimateView.h"
#import "JCKJColorButton.h"
#import "JCKJColorModel.h"


#define bottomView_H 316

@interface JCKJChoseColorView()

@property (weak, nonatomic) IBOutlet UIView *bottomView;

@property (nonatomic ,strong) LYQAnimateView *animateView;

@property (nonatomic ,strong) NSMutableArray *colorViewArrays;

@property (nonatomic ,strong) UIButton *seleButton;



@end


@implementation JCKJChoseColorView


-(NSMutableArray *)colorViewArrays{
    if (_colorViewArrays == nil) {
        _colorViewArrays = [NSMutableArray array];
    }
    return _colorViewArrays;
}

-(LYQAnimateView *)animateView{
    
    if (_animateView == nil) {
        
        _animateView = [LYQAnimateView xmg_viewFromXib];
        _animateView.istouViewNoDissmiss = YES;
    }
    
    return _animateView;
    
}
-(void)awakeFromNib{
    [super awakeFromNib];
    self.autoresizingMask = UIViewAutoresizingNone;
    
   
}

-(void)show{
    self.frame = CGRectMake(0, 0, LYQ_SCREEN_W, bottomView_H);
    self.animateView.bottomView_Height = self.xmg_height;
    [self.animateView.bottomView addSubview:self];
    [self.animateView show];
}

-(void)dissmiss{
    [self.animateView dissmissWithCompletion:^{
        [self removeFromSuperview];
    }];
}

- (IBAction)cancleButtonClick:(id)sender {
    [self dissmiss];
    
}

#define kButtonH 35 //每个小视图高80
#define kButtonW 88 //每个小视图宽80
#define kColCount 3 //每行视图数量一定，都是三个
#define kStart_X 20   //适配屏幕，起点20
#define kStart_Y 25   //适配屏幕，起点20


-(void)layoutSubviews{
    [super layoutSubviews];
    
    NSMutableArray *models = [JCKJColorModel colorModelsArrays];
    CGFloat button_X = 20;
    CGFloat button_Y = 25;
    CGFloat button_marginX = (LYQ_SCREEN_W - kStart_X * 2 - kColCount * kButtonW) / (kColCount - 1);
    CGFloat button_marginY = 25;
    for (NSInteger i = 0 ; i < models.count ; i ++) {
        
        JCKJColorButton *button = [JCKJColorButton colorButton];
        // 行号
        NSInteger row = i/kColCount;
        
        //列号
        NSInteger col = i%kColCount;
        
        button_X = kStart_X + (kButtonW + button_marginX) * col;
        button_Y = kStart_Y + (kButtonH + button_marginY) * row;
        button.frame = CGRectMake(button_X, button_Y, kButtonW, kButtonH);
        button.model = models[i];
        button.clickButton.tag = i ;
        [button.clickButton addTarget:self action:@selector(colorButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.colorViewArrays addObject:button];
        [self.bottomView addSubview:button];
    }
    
    
}

-(void)colorButtonClick:(UIButton *)clickButton{
    
    JCKJColorButton *seleButton = self.colorViewArrays[clickButton.tag];
    [self.colorViewArrays enumerateObjectsUsingBlock:^(JCKJColorButton *colorButton, NSUInteger idx, BOOL * _Nonnull stop) {
        if (colorButton == seleButton) {
            colorButton.isSelect = YES;
        }else{
            colorButton.isSelect = NO;
        }
    }];
    
}

- (IBAction)sureClick:(UIButton *)sender {
    
    [self dissmiss];
    
    [self.colorViewArrays enumerateObjectsUsingBlock:^(JCKJColorButton *colorButton, NSUInteger idx, BOOL * _Nonnull stop) {
        if (colorButton.isSelect) {
            if (self.seleColorBlock) {
                self.seleColorBlock(colorButton.model.color, colorButton.model.text);
            }
        }
        
    }];
    
    
    
}




@end
