//
//  LYQHudView.m
//  quanzhouda
//
//  Created by pro on 2017/11/20.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQHudView.h"
#import "LYQCreateUITool.h"
#import <MJExtension.h>

@interface LYQHudView ()


@end

static  LYQHudView *_hud  = nil;

@implementation LYQHudView


+(void)showInfo:(NSString *)info{
    

    CGFloat _tishiH = 36 ;
    
    UILabel *tiLabel = [LYQCreateUITool labelWithTextColor:[UIColor whiteColor] font:14.0f bgColor:LYQ_RGB_COLOR_A(0, 0, 0, 0.7) text:nil];
    [tiLabel cornerWithRadiusSize:3];
    
    if (_hud == nil) {
        _hud = [[LYQHudView alloc] initWithFrame:CGRectMake(0, 0,LYQ_SCREEN_W, LYQ_SCREEN_H)];
        _hud.backgroundColor = [UIColor clearColor];
      
    }
    
  
    

    CGSize sizeToFit = [info boundingRectWithSize:CGSizeMake(MAXFLOAT, _tishiH) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:tiLabel.font} context:nil].size;

    CGFloat _tishiW = sizeToFit.width + 30 ;
    CGFloat _tishiX = (LYQ_SCREEN_W -  _tishiW) * 0.5;
    CGFloat _tishiY = (LYQ_SCREEN_H - _tishiH) * 0.5;
    
    tiLabel.frame = CGRectMake(_tishiX, _tishiY, _tishiW, _tishiH);
    tiLabel.transform  = CGAffineTransformMakeScale(0.001,0.001);

    dispatch_async(dispatch_get_main_queue(), ^{
        tiLabel.text = info;
        [_hud addSubview:tiLabel];
        [[UIApplication sharedApplication].keyWindow addSubview:_hud];

        dispatch_async(dispatch_get_main_queue(), ^{
            [UIView animateWithDuration:0.5 animations:^{
                tiLabel.transform = CGAffineTransformIdentity;
            } completion:^(BOOL finished) {
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [UIView animateWithDuration:0.2 animations:^{
                        tiLabel.transform  = CGAffineTransformMakeScale(0.001, 0.001);
                    } completion:^(BOOL finished) {
                        tiLabel.transform = CGAffineTransformIdentity;
                        tiLabel.text = nil;
                        [tiLabel removeFromSuperview];
                        [_hud removeFromSuperview];
                    }];
                });
            }];
        });



    });

//
    
   
}

+(void)showPhoneError{
    [self showInfo:@"手机号错误"];

}

+(void)showPassWordError{
    [self showInfo:@"请输入6-12位字母数字"];

}

+(void)showCodeError{
    [self showInfo:@"验证码错误"];

}

@end
