//
//  LYQCreateUITool.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <UIKit/UIkit.h>

@interface LYQCreateUITool : NSObject
/**快速生产UIlabel*/
+(UILabel *)labelWithFrame:(CGRect )frame color:(UIColor *)color font:(CGFloat )fontSize bgColor:(UIColor *)bgColor text:(NSString *)text;

/**快速生产UIlabel 不带Frame*/
+(UILabel *)labelWithTextColor:(UIColor *)textColor font:(CGFloat )fontSize bgColor:(UIColor *)bgColor text:(NSString *)text;

/**快速生产UIButton*/
+(UIButton *)normalButtonWithFrame:(CGRect )frame titleColor:(UIColor *)titleColor font:(CGFloat )fontSize normalBgColor:(UIColor *)bgColor text:(NSString *)text;

/**快速生产UITableView*/
+(UITableView *)tableViewWithFram:(CGRect)frame delegate:(id)delegate dataSource:(id)dataSource;

/**快速生产UIScrollView*/
+(UIScrollView *)scrollViewWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor contentSize:(CGSize)size delegate:(id)delegate;

/**导航条返回按钮*/
+(UIBarButtonItem *)blackItemWithTarger:(id)tagert select:(SEL)action;

@end
