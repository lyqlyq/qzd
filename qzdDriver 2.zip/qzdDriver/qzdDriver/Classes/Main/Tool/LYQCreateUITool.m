//
//  LYQCreateUITool.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQCreateUITool.h"

@implementation LYQCreateUITool

+(UILabel *)labelWithFrame:(CGRect )frame color:(UIColor *)color font:(CGFloat )fontSize bgColor:(UIColor *)bgColor text:(NSString *)text{
    
    UILabel * label = [self labelWithTextColor:color font:fontSize bgColor:color text:text];
    label.frame = frame;
    return label;
}

+(UILabel *)labelWithTextColor:(UIColor *)textColor font:(CGFloat )fontSize bgColor:(UIColor *)bgColor text:(NSString *)text{
    UILabel *label = [[UILabel alloc] init];
    label.text = text;
    label.textColor = textColor;
    label.font = LYQ_SYS_FONT(fontSize);
    label.backgroundColor = nil;
    label.textAlignment = NSTextAlignmentCenter;
    
    return label;
}


+(UIButton *)normalButtonWithFrame:(CGRect )frame titleColor:(UIColor *)titleColor font:(CGFloat )fontSize normalBgColor:(UIColor *)bgColor text:(NSString *)text{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:text forState:UIControlStateNormal];
    [btn setBackgroundColor:bgColor];
    [btn setTitleColor:titleColor forState:UIControlStateNormal];
     btn.titleLabel.font = LYQ_SYS_FONT(fontSize);
     btn.frame = frame;
    return btn;
}
+(UITableView *)tableViewWithFram:(CGRect)frame delegate:(id)delegate dataSource:(id)dataSource{
    
    UITableView *tableView = [[UITableView alloc] init];
    
    tableView.frame = frame;
    tableView.showsVerticalScrollIndicator = YES;
    tableView.showsHorizontalScrollIndicator = YES;
    tableView.separatorStyle =UITableViewCellSeparatorStyleNone;
    tableView.delegate = delegate;
    tableView.dataSource = dataSource;
    tableView.backgroundColor = [UIColor clearColor];
    return tableView;
    
}

+(UIScrollView *)scrollViewWithFrame:(CGRect)frame bgColor:(UIColor *)bgColor contentSize:(CGSize)size delegate:(id)delegate{
    UIScrollView *sc  = [[UIScrollView alloc] init];
    sc.frame = frame;
    sc.backgroundColor = bgColor;
    sc.contentSize = size;
    sc.bounces = NO;
    sc.pagingEnabled = YES;
    sc.showsVerticalScrollIndicator = NO;
    sc.showsHorizontalScrollIndicator = NO;
    sc.delegate = delegate;
    return sc;
}

+(UIBarButtonItem *)blackItemWithTarger:(id)tagert select:(SEL)action{
    
    
    UIImage *leftImage = [LYQ_IMAGENAME(@"return_jckj") imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithImage:leftImage style:0 target:tagert action:action];
    return item;
}


@end
