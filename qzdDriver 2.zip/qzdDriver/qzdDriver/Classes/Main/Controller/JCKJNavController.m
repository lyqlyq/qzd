//
//  JCKJNavController.m
//  qzdDriver
//
//  Created by pro on 2018/3/23.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJNavController.h"
#import "JCKJDDJXZController.h"

@interface JCKJNavController ()<UIGestureRecognizerDelegate>

@end

@implementation JCKJNavController

+(void)initialize{
    UINavigationBar *navBar = [UINavigationBar appearanceWhenContainedIn:self, nil];
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = LYQ_SYS_FONT(16);
    attrs[NSForegroundColorAttributeName] =LYQ_COLOR_WITH_HEX(0xECEAE0);
    [navBar setTitleTextAttributes:attrs];
 //   [navBar setBackgroundColor:LYQ_COLOR_WITH_HEX(0x1A1B1B)];
 
    [navBar setBarTintColor:[UIColor blackColor]];
   // [navBar setTintColor:LYQ_COLOR_WITH_HEX(0x1A1B1B)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self.interactivePopGestureRecognizer.delegate action:@selector(handleNavigationTransition:)];
    
    [self.view addGestureRecognizer:pan];
    
    //控制手势什么时候触发,只有非根控制器才需要触发手势
    pan.delegate = self;
    
    // 禁止之前手势
    self.interactivePopGestureRecognizer.enabled = NO;
    

}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    
    if (self.childViewControllers.count > 0) { // 非根控制器
        // 恢复滑动返回功能 -> 分析:把系统的返回按钮覆盖 -> 1.手势失效(1.手势被清空 2.可能手势代理做了一些事情,导致手势失效)
        viewController.hidesBottomBarWhenPushed = YES;
        
        if ([viewController isKindOfClass:[JCKJDDJXZController class]]) {
        }else{
        
            UIImage *leftImage = [[UIImage imageNamed:@"return"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
            UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithImage:leftImage style:UIBarButtonItemStyleDone target:self action:@selector(black)];
            viewController.navigationItem.leftBarButtonItem = left;
        }
     
        
    }
    
    // 真正在跳转
    [super pushViewController:viewController animated:animated];
}

-(BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    
   UIViewController *vc = [self.viewControllers lastObject];
    
    if ([vc isKindOfClass:[JCKJDDJXZController class]]) {
        return NO;
    }else{
        return YES;
    }
    
}

- (void)black
{
    [self popViewControllerAnimated:YES];
}



@end
