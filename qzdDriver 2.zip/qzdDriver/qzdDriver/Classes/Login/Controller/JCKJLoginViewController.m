//
//  JCKJLoginViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/9.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJLoginViewController.h"
#import "JCKJRegisterViewController.h"
#import "LYQTextFiledMangerTool.h"

#import "JCKJDriverViewController.h"
#import "JCKJNavController.h"

#import "JCKJLoginParam.h"
#import "JCKJLoginRequestTool.h"


@interface JCKJLoginViewController ()<UINavigationControllerDelegate,LYQTextFiledMangerToolDelegate>
@property (weak, nonatomic) IBOutlet UITextField *phoneTextF;
@property (weak, nonatomic) IBOutlet UITextField *passWordTextF;

@property (weak, nonatomic) IBOutlet UIButton *loginButton;

@property (nonatomic ,strong) LYQTextFiledMangerTool *textFTool;

@end

@implementation JCKJLoginViewController

-(LYQTextFiledMangerTool *)textFTool{
    if (_textFTool == nil) {
        _textFTool = [[LYQTextFiledMangerTool alloc] init];
        _textFTool.delegate = self;
    }
    return _textFTool;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.delegate = self;
    [self.loginButton cornerWithRadiusSize:4];
    
    [self.textFTool startMangerTextFs];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    // 判断要显示的控制器是否是自己
    BOOL isShowHomePage = [viewController isKindOfClass:[self class]];
    
    [self.navigationController setNavigationBarHidden:isShowHomePage animated:YES];
}


-(NSMutableArray<UITextField *> *)textFiledMangerWithTextFiledArray:(LYQTextFiledMangerTool *)manger{
    
    NSMutableArray *textFs = [NSMutableArray array];
    [textFs addObject:self.phoneTextF];
    [textFs addObject:self.passWordTextF];
    
    return textFs;
}

-(void)textFiledMangerCanBeClick:(LYQTextFiledMangerTool *)manger{
    [self.loginButton setBackgroundColor:LYQ_COLOR_WITH_HEX(0x3F3E3E)];
    self.loginButton.userInteractionEnabled = YES;
}

-(void)textFiledMangerNoClickAble:(LYQTextFiledMangerTool *)manger{
    [self.loginButton setBackgroundColor:LYQ_COLOR_WITH_HEX(0x6D6D6D)];
    self.loginButton.userInteractionEnabled = NO;


}


// 找回密码
- (IBAction)zhPassWordClick:(UIButton *)sender {
    JCKJRegisterViewController *registerVC = [[JCKJRegisterViewController alloc] init];
    registerVC.isChangePass = YES;
    [self.navigationController pushViewController:registerVC animated:YES];
}
- (IBAction)registerClick:(UIButton *)sender {
    JCKJRegisterViewController *registerVC = [[JCKJRegisterViewController alloc] init];
    registerVC.isChangePass = NO;
    [self.navigationController pushViewController:registerVC animated:YES];
}
- (IBAction)loginClick:(UIButton *)sender {
    
    JCKJLoginParam *param = [JCKJLoginParam param];
    param.phone = self.phoneTextF.text;
    param.password = self.passWordTextF.text;
    
    [JCKJLoginRequestTool POSTLoginParam:param success:^(JCKJLoginModel *model) {
        
     JCKJDriverViewController *driver = [[JCKJDriverViewController alloc] init];
     JCKJNavController *nav = [[JCKJNavController alloc] initWithRootViewController:driver];
     [UIApplication sharedApplication].keyWindow.rootViewController = nav;
    } failure:^(NSError *error) {
        
    }];
}

@end
