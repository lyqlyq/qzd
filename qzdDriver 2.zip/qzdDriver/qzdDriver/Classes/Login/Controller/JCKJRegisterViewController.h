//
//  JCKJRegisterViewController.h
//  qzdDriver
//
//  Created by pro on 2018/4/9.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCKJRegisterViewController : UIViewController

@property (nonatomic ,assign) BOOL isChangePass;

@end
