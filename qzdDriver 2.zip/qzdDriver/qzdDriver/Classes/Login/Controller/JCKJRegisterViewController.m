//
//  JCKJRegisterViewController.m
//  qzdDriver
//
//  Created by pro on 2018/4/9.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJRegisterViewController.h"
#import "LYQTextFiledMangerTool.h"
#import <UIButton+SGCountdown.h>

#import "JCKJLoginRequestTool.h"
#import "JCKJLoginParam.h"
#import "JCKJNavController.h"
#import "JCKJDriverViewController.h"

@interface JCKJRegisterViewController ()<LYQTextFiledMangerToolDelegate>
@property (weak, nonatomic) IBOutlet UIButton *registButton;
@property (weak, nonatomic) IBOutlet UIButton *codeButton;
@property (weak, nonatomic) IBOutlet UIButton *bottonLabel;
@property (weak, nonatomic) IBOutlet UITextField *phoneTextF;
@property (weak, nonatomic) IBOutlet UITextField *codeTextF;
@property (weak, nonatomic) IBOutlet UITextField *passWordTextF;

@property (nonatomic ,strong) LYQTextFiledMangerTool *textFTool;

@property (nonatomic ,strong) JCKJLoginParam *param;


@end

@implementation JCKJRegisterViewController

-(JCKJLoginParam *)param{
    if (_param == nil) {
        _param = [JCKJLoginParam param];
    }
    return _param;
}

-(LYQTextFiledMangerTool *)textFTool{
    if (_textFTool == nil) {
        _textFTool = [[LYQTextFiledMangerTool alloc] init];
        _textFTool.delegate = self;
    }
    return _textFTool;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.isChangePass) {
        self.title = @"找回密码";
        self.bottonLabel.hidden = YES;

    }else{
        self.title = @"手机号码注册";

    }
    
    [self.registButton cornerWithRadiusSize:4];
    [self.codeButton cornerWithRadiusSize:4];
    
    [self.textFTool startMangerTextFs];
    
}

-(NSMutableArray<UITextField *> *)textFiledMangerWithTextFiledArray:(LYQTextFiledMangerTool *)manger{
    
    NSMutableArray *textFs = [NSMutableArray array];
    [textFs addObject:self.phoneTextF];
    [textFs addObject:self.passWordTextF];
    [textFs addObject:self.codeTextF];
    
    return textFs;
}

-(void)textFiledMangerCanBeClick:(LYQTextFiledMangerTool *)manger{
    [self.registButton setBackgroundColor:LYQ_COLOR_WITH_HEX(0x3F3E3E)];
    self.registButton.userInteractionEnabled = YES;
}

-(void)textFiledMangerNoClickAble:(LYQTextFiledMangerTool *)manger{
    [self.registButton setBackgroundColor:LYQ_COLOR_WITH_HEX(0x6D6D6D)];
    self.registButton.userInteractionEnabled = NO;
    
    
}
- (IBAction)codeClick:(UIButton *)sender {
    if (!(self.phoneTextF.text.length > 1)) {
        return;
    }
    self.param.phone = self.phoneTextF.text;
    sender.userInteractionEnabled = NO;

    [JCKJLoginRequestTool POSTCodeParam:self.param success:^(JCKJLoginModel *model) {
        
            [self.codeButton SG_countdownWithSec:60 completion:^{
                sender.userInteractionEnabled = YES;
                [sender setTitle:@"获取验证码" forState:UIControlStateNormal];
            }];
        
        
    } failure:^(NSError *error) {
        
    }];
    
    

    
}

- (IBAction)registerClick:(id)sender {
   
    self.param.password = self.passWordTextF.text;
    self.param.code = self.codeTextF.text;
    self.param.phone = self.phoneTextF.text;
    
    if (self.isChangePass) {
        [JCKJLoginRequestTool POSTChangePasswordParam:self.param success:^(JCKJLoginModel *model){
            [self.navigationController popViewControllerAnimated:YES];
        } failure:^(NSError *error) {
            
        }];
    }else{
        [JCKJLoginRequestTool POSTRegisterParam:self.param success:^(JCKJLoginModel *model) {
            
            JCKJDriverViewController *driver = [[JCKJDriverViewController alloc] init];
            JCKJNavController *nav = [[JCKJNavController alloc] initWithRootViewController:driver];
            [UIApplication sharedApplication].keyWindow.rootViewController = nav;
            
        } failure:^(NSError *error) {
            
        }];
    }
   
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}


-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.navigationController.navigationBar setHidden:NO];
}
@end
