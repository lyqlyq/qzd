//
//  JCKJLoginRequestTool.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJLoginRequestTool.h"
#import "LYQRequestTool.h"
#import "JCKJLoginParam.h"
#import "JCKJLoginModel.h"

@implementation JCKJLoginRequestTool

/**登录*/
+(void)POSTLoginParam:(JCKJLoginParam *)loginParam success:(void(^)(JCKJLoginModel *model))success failure:(void(^)(NSError *error))failure{
    
    
    [LYQRequestTool POSTURL:login_URL params:loginParam.mj_keyValues success:^(id responseObject) {
        
        JCKJLoginModel *model = [JCKJLoginModel mj_objectWithKeyValues:responseObject];

        if (model.token.length > 0) {
            [[NSUserDefaults standardUserDefaults] setObject:model.token forKey:lyq_Token];
        }
        if (success) {
            success(model);
        }
        
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
    
    
    
    
}

/**注册*/
+(void)POSTRegisterParam:(JCKJLoginParam *)registerParam success:(void(^)(JCKJLoginModel *model))success failure:(void(^)(NSError *error))failure{
    [LYQRequestTool POSTURL:fast_register_URL params:registerParam.mj_keyValues success:^(id responseObject) {
        
        JCKJLoginModel *model = [JCKJLoginModel mj_objectWithKeyValues:responseObject];
        
        if (model.token.length > 0) {
            [[NSUserDefaults standardUserDefaults] setObject:model.token forKey:lyq_Token];
        }
        if (success) {
            success(model);
        }
        
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
    
}

/**验证码*/
+(void)POSTCodeParam:(JCKJLoginParam *)codeParam success:(void(^)(JCKJLoginModel *model))success failure:(void(^)(NSError *error))failure{
    [LYQRequestTool POSTURL:get_code_URL params:codeParam.mj_keyValues success:^(id responseObject) {
        
        
        JCKJLoginModel *model = [JCKJLoginModel mj_objectWithKeyValues:responseObject];
        if (success) {
            success(model);
        }
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
}

/**修改密码*/
+(void)POSTChangePasswordParam:(JCKJLoginParam *)passwordParam success:(void(^)(JCKJLoginModel *model))success failure:(void(^)(NSError *error))failure{
    [LYQRequestTool POSTURL:forgetpwd_URL params:passwordParam.mj_keyValues success:^(id responseObject) {
        
        JCKJLoginModel *model = [JCKJLoginModel mj_objectWithKeyValues:responseObject];
        
        if (success) {
            success(model);
        }
        
        
    } failure:^(NSError *error) {
        
    } showMessage:nil isShowMessage:YES];
}


@end
