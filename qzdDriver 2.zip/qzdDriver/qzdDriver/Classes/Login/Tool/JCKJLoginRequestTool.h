//
//  JCKJLoginRequestTool.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJLoginParam;
@class JCKJLoginModel;
@interface JCKJLoginRequestTool : NSObject


/**登录*/
+(void)POSTLoginParam:(JCKJLoginParam *)loginParam success:(void(^)(JCKJLoginModel *model))success failure:(void(^)(NSError *error))failure;

/**注册*/
+(void)POSTRegisterParam:(JCKJLoginParam *)registerParam success:(void(^)(JCKJLoginModel *model))success failure:(void(^)(NSError *error))failure;

/**验证码*/
+(void)POSTCodeParam:(JCKJLoginParam *)codeParam success:(void(^)(JCKJLoginModel *model))success failure:(void(^)(NSError *error))failure;

/**修改密码*/
+(void)POSTChangePasswordParam:(JCKJLoginParam *)passwordParam success:(void(^)(JCKJLoginModel *model))success failure:(void(^)(NSError *error))failure;

@end
