//
//  JCKJLoginParam.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJLoginParam.h"

@implementation JCKJLoginParam


+(instancetype)param{
    
    JCKJLoginParam *param = [[JCKJLoginParam alloc] init];
    return param;
}

-(instancetype)init{
    if (self = [super init]) {
        self.isDriver = YES;
    }
    return self;
}

@end
