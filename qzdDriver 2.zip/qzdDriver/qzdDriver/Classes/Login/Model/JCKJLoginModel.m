//
//  JCKJLoginModel.m
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJLoginModel.h"

@implementation JCKJLoginModel

@end
