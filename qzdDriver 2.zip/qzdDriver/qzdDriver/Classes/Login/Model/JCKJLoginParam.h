//
//  JCKJLoginParam.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJLoginParam : NSObject

@property (nonatomic ,copy) NSString *phone;
@property (nonatomic ,copy) NSString *password;
@property (nonatomic ,copy) NSString *code;
@property (nonatomic ,assign) BOOL isDriver;


+(instancetype)param;

@end
