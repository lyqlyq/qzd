//
//  JCKJLoginModel.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJLoginModel : NSObject

@property (nonatomic ,copy) NSString *msg;

@property (nonatomic ,copy) NSString *token;

@end
