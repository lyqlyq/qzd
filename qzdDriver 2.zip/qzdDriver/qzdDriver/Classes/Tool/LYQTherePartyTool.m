//
//  LYQTherePartyTool.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQTherePartyTool.h"
#import <IQKeyboardManager.h>
#import <AMapFoundationKit/AMapFoundationKit.h>




@interface LYQTherePartyTool ()

@end

@implementation LYQTherePartyTool

+(void)startKeyboardMgr{
    
    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager]; // 获取类库的单例变量
    keyboardManager.enable = YES; // 控制整个功能是否启用
    keyboardManager.enableAutoToolbar = YES;
    
    
}

+(void)setUpAMapServicesKey{
    
    [AMapServices sharedServices].apiKey = @"581e97ef4bbefce945cd012a63604ff3";
    
}


  

/*
 *
 nonceStr = bh8OJFjPpHSYG1pP;
 openID = wxa963062d72a92503;
 package = "Sign=WXPay";
 partnerId = 1488055302;
 prepayId = wx201801151735393025bee4060496768332;
 sign = F6C544CE4D5C4002FD40853A6820B51E;
 timeStamp = 1516008939;
 type = 0;
 */

/*
 *微信支付
 */



@end
