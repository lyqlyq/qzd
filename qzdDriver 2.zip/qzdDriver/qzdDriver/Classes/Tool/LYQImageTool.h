//
//  LYQImageTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef enum : NSUInteger {
    choseImageType_XC,
    choseImageType_XJ
} choseImageType;

@interface LYQImageTool : NSObject

+(void)imageToolWithType:(choseImageType)type Success:(void (^)(UIImage *image))success;

@end
