//
//  LYQTherePartyTool.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

/**三方管理工具*/
@interface LYQTherePartyTool : NSObject

/**开启全局键盘管理工具*/
+(void)startKeyboardMgr;

/**初始化阿里云地图*/
+(void)setUpAMapServicesKey;

/**初始化推送通知*/
+(void)setUpJPush:(NSDictionary *)launchingOption delegate:(id)delegate;

/**注册通知的Token*/
+(void)registerDeviceToken:(NSData *)tooken;

/**处理回调的通知*/
+(void)handleRemoteNotification:(NSDictionary *)userInfo;

/**设置别名*/
+(void)setAlias:(NSString *)alias;

/*
 *微信支付
 */
+(void)wChatPay:(NSDictionary *)param;

+(void)setBageZeroNumber;

+(void)makeAllEffective;

@end
