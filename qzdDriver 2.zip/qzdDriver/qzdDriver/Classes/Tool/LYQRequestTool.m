//
//  LYQRequestTool.m
//  quanzhouda
//
//  Created by pro on 2017/11/30.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQRequestTool.h"

#import <AFNetworking.h>
#import "LYQResponseModel.h"
#import "LYQHUD.h"

#define SUCCESS @"success"
#define SUCCESS_INFO @"success_info"


#define FAILURE @"failure"
#define FAILURE_INFO @"failure_info"


@implementation LYQRequestTool

+(void)POSTURL:(NSString *)url params:(NSDictionary *)params success:(void(^)(id responseObject))success failure:(void(^)(NSError *error))failure showMessage:(NSString *)message isShowMessage:(BOOL)isShow{
    
    NSLog(@"参数----%@",params);
    url = [NSString stringWithFormat:@"%@%@",LYQ_HOST,url];

    NSLog(@"url----%@",url);

 
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    manager.requestSerializer.timeoutInterval = 10.f;

    
    NSString *token = [[NSUserDefaults standardUserDefaults] objectForKey:lyq_Token];
    
    if (token.length > 1) {
        NSString *requestToken = [NSString stringWithFormat:@"Bearer %@",token];
        [manager.requestSerializer setValue:requestToken forHTTPHeaderField:@"Authorization"];
    }else{
    }
    
    if (isShow) {
        [LYQHUD showMessage:message];
    }
    
    [manager POST:url parameters:params progress:^(NSProgress * _Nonnull uploadProgress) {
        
        
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (responseObject) {
                [LYQHUD dissmiss];
            
            NSLog(@"%@",responseObject);
            
            LYQResponseModel * model = [LYQResponseModel mj_objectWithKeyValues:responseObject];
            if (model.code == 200) {
                if (success) {
                    success(model.success);
                }
            }else{

            }
            
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
        
        NSLog(@"error---%@",error);
        
       
        
        if (error.code == 3840 || error.code == -1016) {
          //  LYQ_SHOW_INFO(@"数据解析错误");
            NSLog(@"数据解析错误");
        }else if(error.code == 404){
            //LYQ_SHOW_INFO(@"未找到服务器");
            NSLog(@"未找到服务器");

      
        }else if (error.code == -1001){
            
            //LYQ_SHOW_INFO(@"请求超时,请重新请求");
            
            NSLog(@"请求超时,请重新请求");

        }
        
        else{
//            LYQ_SHOW_INFO(@"服务端错误");
            NSLog(@"服务端错误");

        }
          [LYQHUD dissmiss];
     

    }];
    
}
        
   


@end
