//
//  JCKJAPI.h
//  qzdDriver
//
//  Created by pro on 2018/4/10.
//  Copyright © 2018年 pro. All rights reserved.
//

#ifndef JCKJAPI_h
#define JCKJAPI_h

#pragma mark -----------------登录与注册-----------4----------



/**域名*/
//#define LYQ_HOST @"http://192.168.1.8"
#define LYQ_HOST @"http://qzd.abzjc.com/api/"

#define lyq_Token @"token"

#define search_phone_URL @"verifyphone"

/**验证验证码*/
#define yz_code_URL @"verifycode"

/**登录接口*/
#define login_URL @"login"

/**首页车辆信息展示*/
#define cars_info_URL @"get-car"

/**获取验证码*/
#define get_code_URL @"sendmsg"

/**快速注册接口*/
#define fast_register_URL @"fastregister"

// 修改密码
#define forgetpwd_URL @"forgetpwd"

//获取用户信息
#define getdetails_URL @"get-details"

//发车
#define fastdriverstart_URL @"fastdriverstart"
//收车
#define driverstop_URL @"driverstop"

#define driverrefresh_URL @"driverrefresh"

#define getuploadtoken_URL @"getuploadtoken"




#endif
