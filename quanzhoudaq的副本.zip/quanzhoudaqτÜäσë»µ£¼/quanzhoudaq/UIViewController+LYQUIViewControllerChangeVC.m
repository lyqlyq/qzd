//
//  UIViewController+LYQUIViewControllerChangeVC.m
//  quanzhoudaq
//
//  Created by pro on 2018/2/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "UIViewController+LYQUIViewControllerChangeVC.h"
#import <objc/runtime.h>
@implementation UIViewController (LYQUIViewControllerChangeVC)


+(void)load{

   
    Method  originaM = class_getInstanceMethod([self class], @selector(viewDidLoad));
    Method  exchangeM = class_getInstanceMethod([self class], @selector(lyq_viewDidLoad));
    method_exchangeImplementations(originaM, exchangeM);

    
}
-(void)lyq_viewDidLoad{
    
  
    LYQLog(@"当前控制器名称:----%@----",NSStringFromClass([self class]));

    [self lyq_viewDidLoad];
}

@end
