//
//  JCKJParam.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJParam : NSObject


/**行程类型 1：快车 2：顺风车 3：顺丰带 4:优享顺风车*/
@property (nonatomic ,copy) NSString *type;

@property (nonatomic ,copy) NSString *thinksmoney;

@property (nonatomic ,copy) NSString *comment;


+(instancetype)param;
@end
