//
//  JCKJParam.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJParam.h"

@implementation JCKJParam

+(instancetype)param{
    
    return [[self alloc] init];
    
}

-(instancetype)init{
    if (self = [super init]) {
        self.thinksmoney = @"0";
        self.comment = @" ";
    }
    return self;
}

@end
