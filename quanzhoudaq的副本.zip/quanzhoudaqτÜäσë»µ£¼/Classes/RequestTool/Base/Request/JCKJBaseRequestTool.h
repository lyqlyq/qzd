//
//  JCKJBaseRequestTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "JCKJParam.h"
@class JCKJPriceModel;
@interface JCKJBaseRequestTool : NSObject


/**获取车费*/
+(void)POST_CountpriceParams:(JCKJParam *)params success:(void(^)( JCKJPriceModel *priceModel))success failure:(void(^)(NSError *error))failure;

@end
