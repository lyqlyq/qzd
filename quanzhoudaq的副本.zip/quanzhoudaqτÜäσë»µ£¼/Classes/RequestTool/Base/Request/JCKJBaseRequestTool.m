//
//  JCKJBaseRequestTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJBaseRequestTool.h"
#import "LYQRequestTool.h"
#import "JCKJParam.h"
#import "JCKJPriceModel.h"


@implementation JCKJBaseRequestTool


/**获取车费*/
+(void)POST_CountpriceParams:(JCKJParam *)params success:(void(^)(JCKJPriceModel *priceModel))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:countprice_URL params:params.mj_keyValues success:^(id responseObject) {
        
        JCKJPriceModel *priceModel = [JCKJPriceModel mj_objectWithKeyValues:responseObject[@"price"]];
        
        if (success) {
            success(priceModel);
        }
        
        
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    } showMessage:nil isShowMessage:NO];
    
}

@end
