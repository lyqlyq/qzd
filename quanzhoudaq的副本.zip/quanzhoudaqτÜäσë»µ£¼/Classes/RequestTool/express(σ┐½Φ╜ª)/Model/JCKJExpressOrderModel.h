//
//  JCKJExpressOrderModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJExpressOrderModel : NSObject

@property (nonatomic ,copy) NSString *comment;
@property (nonatomic ,copy) NSString *created_at;
@property (nonatomic ,copy) NSString *endcoordinate;
@property (nonatomic ,copy) NSString *endplace;
@property (nonatomic ,copy) NSString *id;
@property (nonatomic ,copy) NSString *orderunm;
@property (nonatomic ,copy) NSString *passengerid;
@property (nonatomic ,copy) NSString *price;
@property (nonatomic ,copy) NSString *startcoordinate;
@property (nonatomic ,copy) NSString *startplace;
@property (nonatomic ,copy) NSString *status;
@property (nonatomic ,copy) NSString *thinksmoney;
@property (nonatomic ,copy) NSString *updated_at;




@end
