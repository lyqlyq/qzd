//
//  JCKJPriceModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

/*
 *  away": 177.19, 里程
 "mileage": 105.96, // 里程费
 "starprice": 5,  // 起步价
 "total": 110.96,  // 总价
 "info": 214,  // 备注信息
 "discount": 11.1, // 折扣
 "price": 99.87 // 价格
 "backprice":  // 返程费用
 */

@interface JCKJPriceModel : NSObject

/**里程*/
@property (nonatomic ,copy) NSString * away;
/**里程费*/
@property (nonatomic ,copy) NSString * mileage;
/**起步价*/
@property (nonatomic ,copy) NSString * starprice;
/**总价*/
@property (nonatomic ,copy) NSString * total;
/**备注信息*/
@property (nonatomic ,copy) NSString * info;
/**折扣*/
@property (nonatomic ,copy) NSString * discount;
/**价格*/
@property (nonatomic ,copy) NSString * price;
/**返程费用*/
@property (nonatomic ,copy) NSString * backprice;




@end
