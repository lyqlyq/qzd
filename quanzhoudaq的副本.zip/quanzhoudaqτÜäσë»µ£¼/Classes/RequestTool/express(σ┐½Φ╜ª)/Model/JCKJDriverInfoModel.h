//
//  JCKJDriverInfoModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJDriverInfoModel : NSObject

/**车型*/
@property (nonatomic ,copy) NSString *brand;
/**车牌号*/
@property (nonatomic ,copy) NSString *carunm;
/**颜色*/
@property (nonatomic ,copy) NSString *color;
/**头像*/
@property (nonatomic ,copy) NSString *head;
/**星级*/
@property (nonatomic ,copy) NSString *level;
/**名字*/
@property (nonatomic ,copy) NSString *name;
/**电话*/
@property (nonatomic ,copy) NSString *phone;
/**性别*/
@property (nonatomic ,copy) NSString *sex;



@end
