//
//  JCKJPriceModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPriceModel.h"

@implementation JCKJPriceModel


-(NSString *)price{
    double priceInt = [_price doubleValue];
    
    NSString *sepPrice = [NSString stringWithFormat:@"%.2f",priceInt];
    
    return sepPrice;
}

@end
