//
//  JCKJDriverInfoModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverInfoModel.h"

@implementation JCKJDriverInfoModel

@end
