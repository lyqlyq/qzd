//
//  JCKJExpressRequestTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJDriverCarInfoModel;
@class JCKJExpressParam;
@class JCKJExpressOrderModel;
@class JCKJDriverInfoModel;
@class JCKJCarInfoModel;
@interface JCKJExpressRequestTool : NSObject


/**获取首页 车辆信息*/
+(void)POST_DirverCarsInfoParams:(JCKJExpressParam *)params success:(void(^)(NSMutableArray *carInfoModels))success failure:(void(^)(NSError *error))failure;

/**呼叫快车*/
+(void)POST_PushFastCarParams:(JCKJExpressParam *)params success:(void(^)(JCKJExpressOrderModel * expModel))success failure:(void(^)(NSError *error))failure;

/**查看车主是否接单*/
+(void)POST_getDriver_JD:(JCKJExpressParam *)params success:(void(^)(JCKJExpressOrderModel * expModel))success failure:(void(^)(NSError *error))failure;

/**查看快车接单车主的信息*/
+(void)POST_getDriverInfo:(JCKJExpressParam *)params success:(void(^)(JCKJCarInfoModel * carModel))success failure:(void(^)(NSError *error))failure;

/**查看快车 车主的详情*/
+(void)POST_get_JD_DriverInfo:(JCKJExpressParam *)params success:(void(^)(JCKJDriverInfoModel * driverInfoModel))success failure:(void(^)(NSError *error))failure;

/**取消快车*/
+(void)POST_cancelfastorder:(JCKJExpressParam *)params success:(void(^)())success failure:(void(^)(NSError *error))failure;

@end
