//
//  JCKJExpressRequestTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJExpressRequestTool.h"
#import "LYQRequestTool.h"
#import "JCKJExpressParam.h"
#import "JCKJDriverCarInfoModel.h"
#import "JCKJExpressOrderModel.h"
#import "JCKJCarInfoModel.h"
#import "JCKJDriverInfoModel.h"

@implementation JCKJExpressRequestTool


/**获取首页 车辆信息*/
+(void)POST_DirverCarsInfoParams:(JCKJExpressParam *)params success:(void(^)(NSMutableArray *carInfoModels))success failure:(void(^)(NSError *error))failure{
    
    
        [LYQRequestTool POSTURL:cars_info_URL params:params.mj_keyValues success:^(id responseObject) {
            NSMutableArray *carModels = [JCKJDriverCarInfoModel mj_objectArrayWithKeyValuesArray:responseObject[@"car"]];
            
            if (success) {
                success(carModels);
            }
            
        } failure:^(NSError *error) {
            if (failure) {
                failure(error);
            }
            
        } showMessage:nil isShowMessage:NO];

    
    
}

/**呼叫快车*/
+(void)POST_PushFastCarParams:(JCKJExpressParam *)params success:(void(^)(JCKJExpressOrderModel * expModel))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:publishfast_URL params:params.mj_keyValues success:^(id responseObject) {
       
        JCKJExpressOrderModel *orderModel = [JCKJExpressOrderModel mj_objectWithKeyValues:responseObject[@"orderinfo"]];
        
        if (success) {
            success(orderModel);
        }
        
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
        
    } showMessage:nil isShowMessage:NO];
    
    
}

/**查看车主是否接单*/
+(void)POST_getDriver_JD:(JCKJExpressParam *)params success:(void(^)(JCKJExpressOrderModel * expModel))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:fastorderinfo_URL params:params.mj_keyValues success:^(id responseObject) {
        JCKJExpressOrderModel *model = [JCKJExpressOrderModel mj_objectWithKeyValues:responseObject[@"orderinfo"]];
        
        if (success) {
            success(model);
        }
        
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
        
    } showMessage:nil isShowMessage:NO];
}

/**查看快车接单车主的信息*/
+(void)POST_getDriverInfo:(JCKJExpressParam *)params success:(void(^)(JCKJCarInfoModel * carModel))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:getfastcarinfo_URL params:params.mj_keyValues success:^(id responseObject) {
        JCKJCarInfoModel *model = [JCKJCarInfoModel mj_objectWithKeyValues:responseObject[@"carinfo"]];
        if (success) {
            success(model);
        }
        
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
        
    } showMessage:nil isShowMessage:NO];
    
}

/**获取车主信息*/
+(void)POST_get_JD_DriverInfo:(JCKJExpressParam *)params success:(void(^)(JCKJDriverInfoModel * driverInfoModel))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:getfastdriverinfo_URL params:params.mj_keyValues success:^(id responseObject) {
        JCKJDriverInfoModel *model = [JCKJDriverInfoModel mj_objectWithKeyValues:responseObject[@"driverinfo"]];
        if (success) {
            success(model);
        }
        
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
        
    } showMessage:nil isShowMessage:NO];
}

+(void)POST_cancelfastorder:(JCKJExpressParam *)params success:(void(^)())success failure:(void(^)(NSError *error))failure{
    [LYQRequestTool POSTURL:cancelfastorder_URL params:params.mj_keyValues success:^(id responseObject) {
        
        if (success) {
            success();
        }
        
    } failure:^(NSError *error) {
        if (failure) {
            failure(error);
        }
    } showMessage:nil isShowMessage:YES];
    
}

@end
