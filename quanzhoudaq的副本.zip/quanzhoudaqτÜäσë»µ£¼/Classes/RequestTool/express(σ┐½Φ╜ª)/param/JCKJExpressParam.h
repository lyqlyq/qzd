//
//  JCKJExpressParam.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJParam.h"

#import <AMapNaviKit/AMapNaviKit.h>

@interface JCKJExpressParam : JCKJParam


@property (nonatomic ,strong) AMapNaviPoint *satrtPoint;

@property (nonatomic ,strong) AMapNaviPoint *endPoint;

/**起点坐标*/
@property (nonatomic ,copy) NSString *startcoordinate;

/**终点坐标*/
@property (nonatomic ,copy) NSString *endcoordinate;

@property (nonatomic ,strong) NSString *coordinate;

/**订单号*/
@property (nonatomic ,copy) NSString *ordernum;


@end
