//
//  JCKJExpressParam.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJExpressParam.h"

@implementation JCKJExpressParam

-(instancetype)init{
    if (self = [super init]) {
        self.type = @"1";
     
    }
    return self;
}


-(NSString *)startcoordinate{
    
    if (_startcoordinate.length > 0) {
        return _startcoordinate;
    }
    
    NSString *startNate = [NSString stringWithFormat:@"%f,%f",self.satrtPoint.longitude,self.satrtPoint.latitude];
    return startNate;
    
}

-(NSString *)endcoordinate{
    
    if (_endcoordinate.length > 0) {
        return _endcoordinate;
    }
    
    NSString *endNate = [NSString stringWithFormat:@"%f,%f",self.endPoint.longitude,self.endPoint.latitude];
    return endNate;
    
}

@end
