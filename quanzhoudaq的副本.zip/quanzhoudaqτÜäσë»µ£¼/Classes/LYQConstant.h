//
//  LYQConstant.h
//  quanzhoudaq
//
//  Created by pro on 2018/2/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#ifndef LYQConstant_h
#define LYQConstant_h


#pragma mark -----------------首页---------------------


#define HomeTitleSelectColor  LYQ_COLOR_WITH_HEX(0xE8724E)

#define HomeTitleNorColor LYQ_COLOR_WITH_HEX(0xECEAE0)

#define lyq_Token @"token"

#endif /* LYQConstant_h */
