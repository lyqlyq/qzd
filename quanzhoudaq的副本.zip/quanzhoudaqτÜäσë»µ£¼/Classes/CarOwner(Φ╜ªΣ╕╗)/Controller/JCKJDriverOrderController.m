//
//  JCKJDriverOrderController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverOrderController.h"
#import "JCKJPassengerPlaceView.h"
#import "JCKJPassengerPlaceCell.h"

@interface JCKJDriverOrderController ()<UITableViewDelegate,UITableViewDataSource,UIGestureRecognizerDelegate>
@property (weak, nonatomic) IBOutlet UIView *driverPlace;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation JCKJDriverOrderController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"我的订单";
    
    JCKJPassengerPlaceView *placeV = [JCKJPassengerPlaceView xmg_viewFromXib];
    placeV.frame = self.driverPlace.bounds;
    placeV.isHidenDetialImageView = YES;
    placeV.isDriverColor = YES;
    placeV.stateText =@"我的行程导航";
    [self.driverPlace addSubview:placeV];

    
    
}
-(void)panClick{
    
}

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 1;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 10;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    JCKJPassengerPlaceCell *cell = [JCKJPassengerPlaceCell passengerPlaceCellWithTableView:tableView];
    
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5.0f;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 150.0f;
}


- (NSArray<UITableViewRowAction *> *)tableView:(UITableView *)tableView editActionsForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewRowAction *deleteAction = [UITableViewRowAction rowActionWithStyle:UITableViewRowActionStyleDestructive title:@"删除" handler:^(UITableViewRowAction * _Nonnull action, NSIndexPath * _Nonnull indexPath) {
        LYQLog(@"点击了删除");
    }];
  
    return @[deleteAction];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    editingStyle = UITableViewCellEditingStyleDelete;
}


-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    // 输出点击的view的类名
    NSLog(@"%@", NSStringFromClass([touch.view class]));
    
    // 若为UITableViewCellContentView（即点击了tableViewCell），则不截获Touch事件
    if ([NSStringFromClass([touch.view class]) isEqualToString:@"UITableViewCellContentView"]) {
        return NO;
    }
    return  YES;
}


@end
