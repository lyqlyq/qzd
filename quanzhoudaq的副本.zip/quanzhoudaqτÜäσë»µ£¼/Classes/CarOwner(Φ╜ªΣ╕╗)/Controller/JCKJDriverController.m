//
//  JCKJDriverController.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/8.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverController.h"
#import "JCKJEndOrderController.h"

@interface JCKJDriverController ()

@property (weak, nonatomic) IBOutlet UILabel *wszLabel;
@end

@implementation JCKJDriverController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"车主中心";
    
    
    self.wszLabel.layer.masksToBounds = YES;
    self.wszLabel.layer.cornerRadius = 7.0f;
    
    self.wszLabel.layer.borderWidth = 1.0f;
    self.wszLabel.layer.borderColor = [LYQ_COLOR_WITH_HEX(0x1FAD9F) CGColor];
    
    
}
//我的订单
- (IBAction)my_DDClick:(UIButton *)sender {
    
    JCKJEndOrderController *endOrderVC = [[JCKJEndOrderController alloc] init];
    
    [self.navigationController pushViewController:endOrderVC animated:YES];
}
//余额
- (IBAction)yeClick:(UIButton *)sender {
}
// 常用路线
- (IBAction)cyluClick:(id)sender {
}

@end
