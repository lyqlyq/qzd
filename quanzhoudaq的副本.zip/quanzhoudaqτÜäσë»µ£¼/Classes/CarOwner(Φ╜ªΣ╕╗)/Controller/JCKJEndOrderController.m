//
//  JCKJEndOrderController.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/8.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJEndOrderController.h"
#import "JCKJEndOrderCell.h"

@interface JCKJEndOrderController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation JCKJEndOrderController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"我的订单";
    
}


#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 1;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    JCKJEndOrderCell *cell = [JCKJEndOrderCell JCKJEndOrderCellWithTableView:tableView];

    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 5.0f;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 113.0f;
}


@end
