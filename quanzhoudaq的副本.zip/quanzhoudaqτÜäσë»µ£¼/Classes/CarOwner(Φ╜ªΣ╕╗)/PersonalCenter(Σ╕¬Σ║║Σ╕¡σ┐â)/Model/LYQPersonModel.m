//
//  LYQPersonModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQPersonModel.h"

@implementation LYQPersonModel

+(NSMutableArray *)persons{
   
    NSMutableArray *models = [NSMutableArray array];
    NSArray *image_names = @[@"person_trip",@"perosn_TheWallet",@"invoice",@"RealnameAuthentication",@"TheownerCertification",@"preferential",@"Help",@"SetUp"];
    NSArray *title_names = @[@"行程",@"钱包",@"发票",@"实名认证",@"车主认证",@"优惠活动",@"帮助与反馈",@"设置"];
    NSArray *controller_names=@[@"LYQTripViewController",@"LYQTheWalletViewController",@"LYQInvoiceViewController",@"LYQRealnameAuthenticationViewController",@"LYQTheownerCertificationViewController",@"LYQPreferentialViewController",@"LYQHelpViewController",@"LYQSetUpViewController"];
    
    for (NSInteger i = 0 ; i < image_names.count ; i ++) {
        
        LYQPersonModel *model = [[LYQPersonModel alloc] init];
        model.image_name = image_names[i];
        model.title_name = title_names[i];
        model.controller_name = controller_names[i];
        [models addObject:model];
    }
    
    return models;
    
}

@end
