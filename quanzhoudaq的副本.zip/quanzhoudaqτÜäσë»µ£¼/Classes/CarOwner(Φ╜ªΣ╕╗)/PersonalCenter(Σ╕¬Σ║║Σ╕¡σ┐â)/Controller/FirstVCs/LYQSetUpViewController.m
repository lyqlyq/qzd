

//
//  LYQSetUpViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQSetUpViewController.h"
#import "LYQForGetPassWordController.h"

#import "LYQChoseWindowTool.h"
#import "LYQUserTool.h"
#import "LYQAlertView.h"

@interface LYQSetUpViewController ()

@property (nonatomic ,strong) LYQAlertView *alertView;

@end

@implementation LYQSetUpViewController

-(LYQAlertView *)alertView{
    if (_alertView == nil) {
        
        _alertView = [LYQAlertView alertViewWithType:alertViewType_SURE title:@"是否确定退出?"];
    }
    return _alertView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/**密码设置*/
- (IBAction)passChangeClick:(UIButton *)sender {
    
    LYQForGetPassWordController *passWordVC = [[LYQForGetPassWordController alloc] init];
    passWordVC.isPOP = YES;
    [self.navigationController pushViewController:passWordVC animated:YES];
}
/**关于全州达*/

- (IBAction)abolutSelf:(UIButton *)sender {
    
    
}
/**退出登录*/

- (IBAction)TCDKClick:(id)sender {
    
    [self.alertView show];
    
    self.alertView.sureClick = ^{
        [LYQUserTool remove];
        [LYQChoseWindowTool choseWindowWithWindow:LYQ_KeyWindow];
    };
    
}

@end
