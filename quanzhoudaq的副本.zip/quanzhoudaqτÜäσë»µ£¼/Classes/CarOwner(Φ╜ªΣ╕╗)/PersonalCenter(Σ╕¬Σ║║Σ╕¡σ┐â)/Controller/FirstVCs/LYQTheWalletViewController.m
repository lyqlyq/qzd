//
//  LYQTheWalletViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQTheWalletViewController.h"

#import "LYQRechargeViewController.h"
@interface LYQTheWalletViewController ()
@property (weak, nonatomic) IBOutlet UIButton *tx_Button;
@property (weak, nonatomic) IBOutlet UIButton *cz_Button;

@end

@implementation LYQTheWalletViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    [self.tx_Button cornerWithRadiusSize:4];
    [self.cz_Button cornerWithRadiusSize:4];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)txButtonClick:(id)sender {
}
- (IBAction)czButtonClick:(id)sender {
    
    LYQRechargeViewController *rechargeVC = [[LYQRechargeViewController alloc] init];
    
    [self.navigationController pushViewController:rechargeVC animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
