



//
//  LYQHelpViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQHelpViewController.h"
#import "UITextField+Placeholder.h"
#import "LYQAlertView.h"

#import <UITextView+BAKit.h>

@interface LYQHelpViewController ()
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UILabel *countLabel;
@property (weak, nonatomic) IBOutlet UIButton *tj_Button;

@property (nonatomic ,strong) LYQAlertView *alertView;


@end

@implementation LYQHelpViewController


-(LYQAlertView *)alertView{
    
    if (_alertView == nil) {
        _alertView = [LYQAlertView alertViewWithType:alertViewType_Call];
    }
    return _alertView;
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
 
    self.textView.ba_maxWordLimitNumber = [self.countLabel.text integerValue];

    self.textView.ba_placeholder = @"输入反馈信息，我们会尽快处理。";
    self.textView.ba_placeholderColor = LYQ_COLOR_WITH_HEX(0x979595);
    
    self.textView.ba_textView_WordDidChangedBlock = ^(NSInteger current_wordNumber) {
    
        NSInteger  nextNum =  self.textView.ba_maxWordLimitNumber - current_wordNumber;
         self.countLabel.text = LYQ_NSStringFormat(@"%ld",nextNum);
        LYQLog(@"%ld",current_wordNumber);
        
        [self changeTjButtonStatus];
        
    };
    
    
    
    self.alertView.sureClick = ^{
        NSMutableString * str = [[NSMutableString alloc]initWithFormat:@"tel:%@",@"4006001234"];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
    };
    
    
    
    
    
    
}
- (IBAction)tjButtonClick:(UIButton *)sender {
    
    
}
-(void)changeTjButtonStatus{
    if ( self.textView.ba_textView_isEmpty){
        
        self.tj_Button.userInteractionEnabled = NO;
        [self.tj_Button setBackgroundColor:LYQ_COLOR_WITH_HEX(0x565553)];
    }else{
        self.tj_Button.userInteractionEnabled = YES;
        [self.tj_Button setBackgroundColor:LYQ_COLOR_WITH_HEX(0x232323)];
    }
    
 
    
}
- (IBAction)callClick:(UIButton *)sender {
    
    self.alertView.contentText = @"400-600-1234";
    [self.alertView show];
    
}


@end
