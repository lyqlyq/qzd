//
//  LYQRechargeViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQRechargeViewController.h"

#import "LYQTextFiledMangerTool.h"
#import "LYQTherePartyTool.h"

@interface LYQRechargeViewController ()<LYQTextFiledMangerToolDelegate>
@property (weak, nonatomic) IBOutlet UIButton *weChatStatusButton;
@property (weak, nonatomic) IBOutlet UIButton *aiPayStatusButton;

@property (nonatomic ,strong) UIButton *seleButton;
@property (weak, nonatomic) IBOutlet UITextField *moneyTextF;
@property (weak, nonatomic) IBOutlet UIButton *sureButton;

@property (nonatomic ,strong) LYQTextFiledMangerTool *textFMgr;



@end

@implementation LYQRechargeViewController

-(LYQTextFiledMangerTool *)textFMgr{
    if (_textFMgr == nil) {
        _textFMgr = [[LYQTextFiledMangerTool alloc] init];
        _textFMgr.delegate = self;
    }
    return _textFMgr;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"充值";
    self.seleButton = self.weChatStatusButton;
    
    
    [self.textFMgr startMangerTextFs];
    
    
}

- (NSMutableArray<UITextField *> *)textFiledMangerWithTextFiledArray:(LYQTextFiledMangerTool *)manger{
    
    NSMutableArray *textfS = [NSMutableArray array];
    
    [textfS addObject:self.moneyTextF];
    
    return textfS;
    
}

-(void)textFiledMangerCanBeClick:(LYQTextFiledMangerTool *)manger{
    self.sureButton.userInteractionEnabled = YES;
    [self.sureButton setBackgroundColor:LYQ_COLOR_WITH_HEX(0x232323)];

}

-(void)textFiledMangerNoClickAble:(LYQTextFiledMangerTool *)manger{
    self.sureButton.userInteractionEnabled = NO;
    [self.sureButton setBackgroundColor:LYQ_COLOR_WITH_HEX(0x565553)];

}


- (IBAction)weChatClick:(UIButton *)sender {
    self.weChatStatusButton.selected = YES;
    self.aiPayStatusButton.selected = NO;
    
}
- (IBAction)aiPayClick:(UIButton *)sender {
    self.weChatStatusButton.selected = NO;
    self.aiPayStatusButton.selected = YES;
}

- (IBAction)sureButtonClick:(UIButton *)sender {
    
    if (self.weChatStatusButton.selected) {
        [LYQTherePartyTool wChatPay:nil];
    }else{
        
    }
    
}

@end
