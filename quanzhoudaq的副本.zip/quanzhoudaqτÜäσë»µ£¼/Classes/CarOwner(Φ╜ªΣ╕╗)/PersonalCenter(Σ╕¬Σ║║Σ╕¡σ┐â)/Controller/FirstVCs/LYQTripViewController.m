//
//  LYQTripViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQTripViewController.h"

@interface LYQTripViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lineView_X;

@property (nonatomic ,strong) UIButton *seleButton;
@property (weak, nonatomic) IBOutlet UIButton *sk_button;
@property (weak, nonatomic) IBOutlet UIButton *cz_button;

@end

@implementation LYQTripViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.sk_button setHighlighted:NO];
    [self.cz_button setHighlighted:NO];

    self.seleButton = self.sk_button;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)shengClick:(UIButton *)sender {
    
    [self moveLineView:sender];
}
- (IBAction)cheClick:(UIButton *)sender {
    [self moveLineView:sender];
}

-(void)moveLineView:(UIButton *)seleButton{
    self.seleButton.selected = NO;
    seleButton.selected = YES;
    self.seleButton = seleButton;
    
    
    [UIView animateWithDuration:0.3 animations:^{
        self.lineView_X.constant = seleButton.xmg_x;
    } completion:^(BOOL finished) {
        [self.view layoutIfNeeded];
    }];
    
}

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 10;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cell_Id = @"cell_Id";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cell_Id];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cell_Id];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row];
    
    
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}



@end
