//
//  LYQJZAndXSZView.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQJZAndXSZView.h"

#import "LYQAnimateView.h"
#import "LYQImageTool.h"



@interface LYQJZAndXSZView ()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imageV;
@property (weak, nonatomic) IBOutlet UILabel *tishiLabel;

@property (nonatomic ,strong) LYQAnimateView *animateView;


@end

@implementation LYQJZAndXSZView

-(LYQAnimateView *)animateView{
    
    if (_animateView == nil) {
        
        _animateView = [LYQAnimateView xmg_viewFromXib];
    }
    
    return _animateView;
    
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.autoresizingMask = UIViewAutoresizingNone;
}


+(instancetype)JZAndXSZViewWithType:(viewType)type{
    
    LYQJZAndXSZView *v = [LYQJZAndXSZView xmg_viewFromXib];
    v.frame = CGRectMake(0, 0, LYQ_SCREEN_W, 438);
    v.type = type;
    return v;
}

-(void)setType:(viewType)type{
    _type = type;
    
    // 驾照
    if (type == viewType_JZ) {
        self.titleLabel.text = @"本人驾照";
        self.tishiLabel.text = @"请提交驾驶证正面照片，确保文字清晰、 无反光、 无遮挡";
        self.imageV.image = LYQ_IMAGENAME(@"Adriver'sLicense");
    }else{
        self.titleLabel.text = @"本人(或他人)行驶证";
        self.tishiLabel.text = @"请提交行驶证正面照片，确保文字清晰、 无反光、 无遮挡";
        self.imageV.image = LYQ_IMAGENAME(@"VehicleLicense");
    }
    
}

-(void)show{
    self.frame = CGRectMake(0, 0, LYQ_SCREEN_W, 438);
    self.animateView.bottomView_Height = self.xmg_height;

    [self.animateView.bottomView addSubview:self];
    [self.animateView show];
}

-(void)dissmiss{
    [self.animateView dissmissWithCompletion:^{
        [self removeFromSuperview];
    }];
}

- (IBAction)cancleButtonClick:(id)sender {
    [self dissmiss];
    
}
- (IBAction)paClick:(id)sender {
  
    
    [self.animateView dissmissWithCompletion:^{
        [self removeFromSuperview];
        [LYQImageTool imageToolWithType:choseImageType_XJ Success:^(UIImage *image) {
            if (self.choseImage) {
                self.choseImage(image);
            }
        }];
    }];
    
   
    
}
- (IBAction)xiangceClick:(id)sender {
    
    
    [self.animateView dissmissWithCompletion:^{
        [self removeFromSuperview];
        [LYQImageTool imageToolWithType:choseImageType_XC Success:^(UIImage *image) {
            if (self.choseImage) {
                self.choseImage(image);
            }
        }];
    }];
    
   
    
}

@end
