//
//  LYQJZAndXSZView.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef enum : NSUInteger {
    viewType_JZ,
    viewType_XSZ
} viewType;

@interface LYQJZAndXSZView : UIView


@property (nonatomic ,copy) void(^(choseImage))(UIImage *seleImageV);

@property (nonatomic ,assign) viewType type;

+(instancetype)JZAndXSZViewWithType:(viewType)type;



-(void)show;



@end
