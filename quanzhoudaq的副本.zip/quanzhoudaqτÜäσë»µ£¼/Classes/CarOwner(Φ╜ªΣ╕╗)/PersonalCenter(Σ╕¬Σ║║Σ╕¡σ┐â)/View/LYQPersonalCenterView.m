//
//  LYQPersonalCenterView.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQPersonalCenterView.h"
#import "LYQUser.h"
#import "LYQUserTool.h"
#import "LYQPersonModel.h"
#import <UIImageView+WebCache.h>

@interface LYQPersonalCenterView ()<UITableViewDelegate,UITableViewDataSource>


@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UIImageView *hederImageV;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (nonatomic ,strong) NSMutableArray *models;


@end


@implementation LYQPersonalCenterView

+(instancetype)personalCenterView{
    
    LYQPersonalCenterView *personView = [LYQPersonalCenterView xmg_viewFromXib];
    personView.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
    personView.transform = CGAffineTransformMakeTranslation(-LYQ_SCREEN_W, 0);
    return personView;
    
    
}

-(void)awakeFromNib{
    
    [super awakeFromNib];
    
    LYQUser *user = [LYQUserTool getUser];
    
    [self.hederImageV cornerWithRadiusSize:40];
    
    [self.hederImageV sd_setImageWithURL:[NSURL URLWithString:user.u_head] placeholderImage:LYQ_IMAGENAME(@"logo")];
    
    self.nameLabel.text = user.u_name;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    
    [self loadData];
    
}

-(void)loadData{
    
    self.models = [LYQPersonModel persons];
    
}

-(void)show{
    
    [UIView animateWithDuration:0.3 animations:^{
        self.transform = CGAffineTransformIdentity;
        self.backgroundColor = LYQ_RGB_COLOR_A(0, 0, 0, 0.6);
    }];
    
    [LYQ_KeyWindow addSubview:self];
    
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [self dissmissCompletion:nil];
}

-(void)dissmissCompletion:(void(^)())completion{
    
    [UIView animateWithDuration:0.3 animations:^{
        self.transform = CGAffineTransformMakeTranslation(-LYQ_SCREEN_W, 0);;
        self.backgroundColor = LYQ_RGB_COLOR_A(0, 0, 0, 0);
    } completion:^(BOOL finished) {
        if (completion) {
            completion();
        }
        [self removeFromSuperview];
    }];
    
}



#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.models.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cell_Id = @"cell_Id";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cell_Id];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cell_Id];
    }
    
    LYQPersonModel *model = self.models[indexPath.row];
    
    cell.textLabel.text = model.title_name;
    cell.imageView.image = LYQ_IMAGENAME(model.image_name);
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LYQPersonModel *model = self.models[indexPath.row];
    
    [self dissmissCompletion:^{
        if (self.didSelectRowBlock) {
            self.didSelectRowBlock(model);
        }
    }];

    
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}


@end
