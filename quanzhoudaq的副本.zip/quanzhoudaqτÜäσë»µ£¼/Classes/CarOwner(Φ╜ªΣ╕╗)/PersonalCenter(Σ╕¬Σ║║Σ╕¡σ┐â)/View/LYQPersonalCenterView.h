//
//  LYQPersonalCenterView.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LYQPersonModel;

@interface LYQPersonalCenterView : UIView


@property (nonatomic ,copy) void(^didSelectRowBlock)(LYQPersonModel *model);


+(instancetype)personalCenterView;

-(void)show;

-(void)dissmiss;

@end
