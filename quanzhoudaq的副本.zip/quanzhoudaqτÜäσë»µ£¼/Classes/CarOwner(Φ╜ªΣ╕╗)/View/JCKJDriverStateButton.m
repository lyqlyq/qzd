//
//  JCKJDriverStateButton.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverStateButton.h"

@implementation JCKJDriverStateButton

-(instancetype)init{
    if (self = [super init]) {
        [self setUp];
    }
    return self;
}

-(void)awakeFromNib{
    [super awakeFromNib];

    [self setUp];
}

-(void)setUp{
    
    self.layer.masksToBounds = YES;
    self.layer.cornerRadius = 4;
    
}

-(void)setUserInteractionEnabled:(BOOL)userInteractionEnabled{
    [super setUserInteractionEnabled:userInteractionEnabled];
    
    if (userInteractionEnabled) {
        [self setBackgroundColor:jckj_COLOR_ligthRed];

    }else{
        [self setBackgroundColor:LYQ_COLOR_WITH_HEX(0x979595)];
    }
    
    
}

@end
