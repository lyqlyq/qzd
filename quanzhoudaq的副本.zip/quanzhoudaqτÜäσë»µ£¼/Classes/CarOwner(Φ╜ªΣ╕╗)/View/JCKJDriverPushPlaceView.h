//
//  JCKJDriverPushPlaceView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCKJDriverPushPlaceView : UIView


+(instancetype)pushPlaceView;

-(void)show;

-(void)dissmiss;

@end
