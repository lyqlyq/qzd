//
//  JCKJEndOrderCell.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/8.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJEndOrderCell.h"

@interface JCKJEndOrderCell()
@property (weak, nonatomic) IBOutlet UIButton *stateButton;

@end

@implementation JCKJEndOrderCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.stateButton.layer.masksToBounds = YES;
    self.stateButton.layer.cornerRadius = 4;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
+(instancetype)JCKJEndOrderCellWithTableView:(UITableView *)tableView{
    
    JCKJEndOrderCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(self)];
    if (cell == nil) {
        cell = [JCKJEndOrderCell xmg_viewFromXib];
    }
    
    return cell;
    
}
@end
