//
//  JCKJDriverInfoPlaceCell.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverInfoPlaceCell.h"

#import "JCKJDriverStateButton.h"
#import "JCKJMoneyButton.h"

@interface JCKJDriverInfoPlaceCell()
@property (weak, nonatomic) IBOutlet JCKJDriverStateButton *stateButton;
@property (weak, nonatomic) IBOutlet JCKJMoneyButton *moneyButton;

@end

@implementation JCKJDriverInfoPlaceCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    self.moneyButton.money = 32;
    
}

+(instancetype)driverInfoPlaceCellWithTableView:(UITableView *)tableView{
    
    JCKJDriverInfoPlaceCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    
    if (cell == nil ) {
        cell = [JCKJDriverInfoPlaceCell xmg_viewFromXib];
    }
    
    return cell;
    
}

@end
