//
//  JCKJDriverPushPlaceView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/30.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverPushPlaceView.h"
#import "NSString+JCKJAttString.h"



#define bottomeView_H 115

@interface JCKJDriverPushPlaceView ()
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet UIButton *priceButton;


@end



@implementation JCKJDriverPushPlaceView

-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.bottomView.transform = CGAffineTransformMakeTranslation(0,bottomeView_H);
    
    NSString *allTextMoney = @"23 元";
    NSString *attText = @"23";
    
    NSMutableAttributedString *seleText = [NSString getAllText:allTextMoney attText:attText attCorlo:nil attFont:LYQ_SYS_FONT(20) allTextColor:jckj_COLOR_driverMain];
    
    [self.priceButton setAttributedTitle:seleText forState:UIControlStateNormal];
    
    
    
    
}

+(instancetype)pushPlaceView{
    JCKJDriverPushPlaceView *ppplaceView = [JCKJDriverPushPlaceView xmg_viewFromXib];
    return ppplaceView;
}

-(void)show{
    self.frame =LYQ_KeyWindow.bounds;
    
    [LYQ_KeyWindow addSubview:self];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundColor = LYQ_RGB_COLOR_A_Mian;
        self.bottomView.transform = CGAffineTransformIdentity;
    }];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self dissmiss];
}

-(void)dissmiss{
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.transform = CGAffineTransformMakeTranslation(0, bottomeView_H);
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    }completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}


@end
