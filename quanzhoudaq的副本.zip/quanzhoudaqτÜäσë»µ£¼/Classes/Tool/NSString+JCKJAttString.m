//
//  NSString+JCKJAttString.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "NSString+JCKJAttString.h"

@implementation NSString (JCKJAttString)

+(NSMutableAttributedString *)getAllText:(NSString *)allText attText:(NSString *)attText attCorlo:(UIColor *)attTextColor attFont:(UIFont *)attTextFont allTextColor:(UIColor *)allColor{
    
    NSMutableAttributedString *allAttText = [[NSMutableAttributedString alloc] initWithString:allText];
    
    NSArray *textArray = [allText componentsSeparatedByString:attText];
   
    NSString *firstText = [textArray firstObject];
    NSRange attRange = NSMakeRange(firstText.length, attText.length);
    [allAttText addAttribute:NSFontAttributeName value:attTextFont range:attRange];

    if (allColor) {
        [allAttText addAttribute:NSForegroundColorAttributeName value:allColor range:NSMakeRange(0, allText.length)];
    }else{
        [allAttText addAttribute:NSForegroundColorAttributeName value:attTextColor range:attRange];


    }
    
    return allAttText;
    
    
}

+(NSMutableAttributedString *)getMoneyAtt_redText:(NSString *)price{
    
    NSString *allText = [NSString stringWithFormat:@"%@ 元",price];
    NSString *attText = [NSString stringWithFormat:@"%@",price];
    NSMutableAttributedString *strAttPrice = [NSString getAllText:allText attText:attText attCorlo:nil attFont:LYQ_SYS_FONT(20) allTextColor:jckj_COLOR_ligthRed];
    
    return strAttPrice;
}

@end
