//
//  LYQPromptTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/25.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>




/**生产提示文字的工具类*/
@interface LYQPromptTool : NSObject


+(NSString *)prompt_carOwner_canclePlace;


/**联系电话*/
+(NSString *)prompt_phone;

/**车主取消全部订单--在取消行程*/
+(NSString *)prompt_cancle_All_DD;

/**车主取消订单*/
+(NSString *)prompt_cancle_order;

/**车主取消行程*/
+(NSString *)prompt_cancle_XC_no;

/**到达出发时间*/
+(NSString *)prompt_daodaChuFaTime;

/**距离出发还有3个小 时，现在取消行程，平台 将扣除20元作为车主的补偿。*/
+(NSString *)prompt_SK_cancle;
/**你有一个行程在规定时间内未完成 支付，现在系统帮你取消行程，如 果有需要请重新发布行程。*/
+(NSString *)prompt_sys_cancle;
/**你还未完成支付， 确定要取消行程吗？*/
+(NSString *)prompt_cancle_noPay;
/**王先生愿意与你同行*/
+(NSString *)prompt_arg;

/**王先生拒绝了你的同行请求*/
+(NSString *)prompt_JuJue;

/**系统正在为你寻找车主，确定要取消行程么？*/
+(NSString *)prompt_cancleWithState:(NSInteger)state_place;




@end
