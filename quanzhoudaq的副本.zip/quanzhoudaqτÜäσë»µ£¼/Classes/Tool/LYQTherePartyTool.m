//
//  LYQTherePartyTool.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQTherePartyTool.h"
#import <IQKeyboardManager.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <JPUSHService.h>

#import <AvoidCrash.h>
#import <WXApi.h>


@interface LYQTherePartyTool ()

@end

@implementation LYQTherePartyTool

+(void)startKeyboardMgr{
    
    IQKeyboardManager *keyboardManager = [IQKeyboardManager sharedManager]; // 获取类库的单例变量
    keyboardManager.enable = YES; // 控制整个功能是否启用
    keyboardManager.enableAutoToolbar = YES;
    
    
}

+(void)setUpAMapServicesKey{
    
    [AMapServices sharedServices].apiKey = @"5c1b89258014f3001287ea0a3178e838";
    
}

+(void)setUpJPush:(NSDictionary *)launchingOption delegate:(id)delegate{
    
    JPUSHRegisterEntity * entity = [[JPUSHRegisterEntity alloc] init];
      entity.types = JPAuthorizationOptionAlert|JPAuthorizationOptionBadge|JPAuthorizationOptionSound;
    if ([[UIDevice currentDevice].systemVersion floatValue] >= 8.0) {
        
        [JPUSHService registerForRemoteNotificationTypes:(UIUserNotificationTypeBadge |
                                                          UIUserNotificationTypeSound |
                                                          UIUserNotificationTypeAlert)
                                              categories:nil];
    }
    [JPUSHService registerForRemoteNotificationConfig:entity delegate:delegate];
    [JPUSHService setupWithOption:launchingOption appKey:@"497a2ce1c4b9556eb96e7034"
                          channel:nil
                 apsForProduction:NO
            advertisingIdentifier:nil];
    

}

+(void)registerDeviceToken:(NSData *)tooken{
    /// Required - 注册 DeviceToken
    [JPUSHService registerDeviceToken:tooken];
    
}

+(void)handleRemoteNotification:(NSDictionary *)userInfo{
    
    [JPUSHService handleRemoteNotification:userInfo];
    
}

+(void)setAlias:(NSString *)alias{
    
    [JPUSHService setAlias:alias completion:^(NSInteger iResCode, NSString *iAlias, NSInteger seq) {
        
        
      
        
  
    } seq:0];
    
}

+(void)setBageZeroNumber{
    [JPUSHService setBadge:0];
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
}

+(void)makeAllEffective{
    
    [AvoidCrash makeAllEffective];
    
}
/*
 *
 nonceStr = bh8OJFjPpHSYG1pP;
 openID = wxa963062d72a92503;
 package = "Sign=WXPay";
 partnerId = 1488055302;
 prepayId = wx201801151735393025bee4060496768332;
 sign = F6C544CE4D5C4002FD40853A6820B51E;
 timeStamp = 1516008939;
 type = 0;
 */

/*
 *微信支付
 */
+(void)wChatPay:(NSDictionary *)param{
    
    if (param == nil) return;
    PayReq *request = [[PayReq alloc] init];
    request.openID = [param objectForKey:@"appid"];
    request.partnerId = [param objectForKey:@"partnerid"];
    request.prepayId= [param objectForKey:@"prepayid"];
    request.package = @"Sign=WXPay";
    request.nonceStr= [param objectForKey:@"noncestr"];
    request.timeStamp = [[param objectForKey:@"timestamp"] intValue];
    request.sign = [param objectForKey:@"sign"];
    
   BOOL n =  [WXApi sendReq:request];
   

    
}


@end
