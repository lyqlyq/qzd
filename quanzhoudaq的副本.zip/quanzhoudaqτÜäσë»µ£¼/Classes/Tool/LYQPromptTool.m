//
//  LYQPromptTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/25.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQPromptTool.h"

@implementation LYQPromptTool
/**联系电话*/
+(NSString *)prompt_phone{
    
    return @"400-600-1234";
    
}

/**车主取消全部订单--在取消行程*/
+(NSString *)prompt_cancle_All_DD{
    
    return @"你已取消了全部订单， 是否确认取消当前行程？";
    
}

+(NSString *)prompt_carOwner_canclePlace{
    return @"你还未接单,\n确定要取消行程吗 ?";
}

/**车主取消订单*/
+(NSString *)prompt_cancle_order{
    return @"你已接单，取消订单将扣除10元 作为乘客的补偿，确定要取消行程吗？";
}

/**车主取消行程*/
+(NSString *)prompt_cancle_XC_no{
    return @"你已接单，如果要取消行程，请先取消订单。";
}

/**到达出发时间*/
+(NSString *)prompt_daodaChuFaTime{
    return @"您已到出发时间，当前没有接到订单，是否导航出发。";
}

/**距离出发还有3个小 时，现在取消行程，平台 将扣除20元作为车主的补偿。*/
+(NSString *)prompt_SK_cancle{
    return @"距离出发还有3个小 时，现在取消行程，平台将扣除20元作为车主的补偿。";
}
/**你有一个行程在规定时间内未完成 支付，现在系统帮你取消行程，如 果有需要请重新发布行程。*/
+(NSString *)prompt_sys_cancle{
    return @"你有一个行程在规定时间内未完成 支付，现在系统帮你取消行程，如 果有需要请重新发布行程。";
}
/**你还未完成支付， 确定要取消行程吗？*/
+(NSString *)prompt_cancle_noPay{
    
    return @"你还未完成支付， 确定要取消行程吗";
}
/**王先生愿意与你同行*/
+(NSString *)prompt_arg{
    return @"王先生愿意与你同行";
}

/**王先生拒绝了你的同行请求*/
+(NSString *)prompt_JuJue{
    return @"王先生拒绝了你的同行请求";
}

/**系统正在为你寻找车主，确定要取 消行程么？*/
+(NSString *)prompt_cancleWithState:(NSInteger)state_place{
    
    if (state_place == 1) {
         return @"系统正在为你寻找车主,确定要取消行程么?";
    }
    if (state_place == 2) {
         return @"你还未完成支付,确定要取消行程吗么?";
    }
    if (state_place == 3) {
        return @"司机已经接单,确定要取消行程么?";

    }
    if (state_place == 4) {
        return @"司机已经接单,确定要取消行程么?";

    }
    if (state_place == 5) {
        return @"司机已经接单,确定要取消行程么?";

    }
    
    return @"司机已经接单,确定要取消行程么?";

}
@end
