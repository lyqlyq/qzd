//
//  LYQCheckUserOpenLocationTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/6.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQCheckUserOpenLocationTool.h"

#import <CoreLocation/CoreLocation.h>

@interface LYQCheckUserOpenLocationTool()<CLLocationManagerDelegate,UIAlertViewDelegate>

@property (nonatomic ,strong) CLLocationManager *locationMgr;

@property (nonatomic ,strong) UIAlertView *alerView;

@end




@implementation LYQCheckUserOpenLocationTool

-(CLLocationManager *)locationMgr{
    
    if (_locationMgr == nil) {
        _locationMgr = [[CLLocationManager alloc] init];
    }
    return _locationMgr;
    
}

-(UIAlertView *)alerView{
    
    if (_alerView == nil) {
        _alerView = [[UIAlertView alloc] initWithTitle:@"定位服务未开启" message:@"请在系统设置中开启服务" delegate:self cancelButtonTitle:@"暂不" otherButtonTitles:@"去设置", nil];
    }
    
    return _alerView;
    
}

- (BOOL)checkLocationServicesAuthorizationStatus{
    
    
    return [self reportLocationServicesAuthorizationStatus:[CLLocationManager authorizationStatus]];
    
}


- (BOOL)reportLocationServicesAuthorizationStatus:(CLAuthorizationStatus)status
{
    if(status == kCLAuthorizationStatusNotDetermined)
    {
        //未决定，继续请求授权
        
        [self requestLocationServicesAuthorization];
        
        return NO;
    }
    else if(status == kCLAuthorizationStatusRestricted)
    {
        //受限制，尝试提示然后进入设置页面进行处理（根据API说明一般不会返回该值）
        [self alertViewWithMessage];
        return NO;
        
    }
    else if(status == kCLAuthorizationStatusDenied)
    {
        //拒绝使用，提示是否进入设置页面进行修改
        [self alertViewWithMessage];
        return NO;
        
    }
    else if(status == kCLAuthorizationStatusAuthorizedWhenInUse)
    {
        //授权使用，不做处理
        return YES;
        
    }
    else if(status == kCLAuthorizationStatusAuthorizedAlways)
    {
        //始终使用，不做处理
        return YES;
    }
    
    return NO;
    
}

-(void)alertViewWithMessage {
 
    [self.alerView show];
    
    
}


-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    
    if (buttonIndex == 0)
    {
        
    }
    else
    {
        //进入系统设置页面，APP本身的权限管理页面
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
    }
}



-(void)requestLocationServicesAuthorization
{
    //CLLocationManager的实例对象一定要保持生命周期的存活
    
    [self.locationMgr requestWhenInUseAuthorization];
    [self.locationMgr requestAlwaysAuthorization];
    [self.locationMgr startUpdatingLocation];
}






@end
