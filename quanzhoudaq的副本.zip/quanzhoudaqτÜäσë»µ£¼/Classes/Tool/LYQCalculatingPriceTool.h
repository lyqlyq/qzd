//
//  LYQCalculatingPriceTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQCalculatingPriceTool : NSObject

/**顺风车价格计算*/
+(NSString *)priceWithFreeRideRoteLength:(CGFloat)length addPrice:(CGFloat)addPrice;
/**顺风带价格计算*/
+(NSString *)priceWithwindBeltRoteLength:(CGFloat)length addPrice:(CGFloat)addPrice;


@end
