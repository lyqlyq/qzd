//
//  LYQChoseWindowTool.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQChoseWindowTool.h"
#import "LYQHomeViewController.h"
#import "LYQNavController.h"

#import "LYQTherePartyTool.h"

@implementation LYQChoseWindowTool

+(void)choseWindowWithWindow:(UIWindow *)window{
    
    LYQHomeViewController *homeVC = [[LYQHomeViewController alloc] init];
    LYQNavController *nav = [[LYQNavController alloc] initWithRootViewController:homeVC];
    window.rootViewController = nav;
    
//    if ([LYQUserTool getUser]) {
//        LYQHomeViewController *homeVC = [[LYQHomeViewController alloc] init];
//        LYQNavController *nav = [[LYQNavController alloc] initWithRootViewController:homeVC];
//        window.rootViewController = nav;
//
//        [LYQTherePartyTool setAlias:[LYQUserTool getUser].u_id];
//
//
//    }else{
//
//
//        LYQLoginViewController *loginVC = [[LYQLoginViewController alloc] init];
//        window.rootViewController = loginVC;
//
//    }
//
    
    [window makeKeyAndVisible];
    
}

@end
