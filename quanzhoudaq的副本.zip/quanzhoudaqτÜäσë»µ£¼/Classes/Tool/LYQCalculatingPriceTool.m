//
//  LYQCalculatingPriceTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQCalculatingPriceTool.h"

@implementation LYQCalculatingPriceTool
/**顺风车价格计算*/
+(NSString *)priceWithFreeRideRoteLength:(CGFloat)length addPrice:(CGFloat)addPrice{
    return @"0.01";
    // 公里数
    NSInteger  kilometreNum = length / 1000;
    
    CGFloat price = 0;
    if (kilometreNum >= 6) {
       price =  (kilometreNum - 6) * 1.1 + 14 ;
    }else if(kilometreNum >= 30){
        price = (kilometreNum - 30) * 0.5 + 14 ;
    }else if (kilometreNum >= 100){
        price = (kilometreNum - 100) * 0.45 + 14 ;

    }else if (kilometreNum >= 300){
        price = (kilometreNum - 300) * 0.4 + 14 ;

    }else{
        price = 14.0f ;
    }
    price = price + addPrice;
    
    return LYQ_NSStringFormat(@"%.01f",price);
    
}
/**顺风带价格计算*/
+(NSString *)priceWithwindBeltRoteLength:(CGFloat)length addPrice:(CGFloat)addPrice{
    
    return @"0.01";
    return LYQ_NSStringFormat(@"%.01f 元",((length / 1000) * 0.05) + 20 + addPrice );

}
@end
