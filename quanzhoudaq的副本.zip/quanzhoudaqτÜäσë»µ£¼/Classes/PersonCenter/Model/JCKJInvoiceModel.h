//
//  JCKJInvoiceModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/2.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    invoiceTypeNet,
    invoiceTypePre
} invoiceType;

@interface JCKJInvoiceModel : NSObject


+(NSMutableArray *)getInvoiceModels;

+(NSMutableArray *)getUserInfoWith:(invoiceType)type;


@end
