//
//  JCKJInvoiceModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/2.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJInvoiceModel.h"

@implementation JCKJInvoiceModel





+(NSMutableArray *)getInvoiceModels{
    
    NSMutableArray *invoicesArray = [NSMutableArray array];
    
    [invoicesArray addObject:@"抬头类型"];
    [invoicesArray addObject:@"抬头名称"];
    [invoicesArray addObject:@"纳税人识别号"];
    [invoicesArray addObject:@"发票内容"];
    [invoicesArray addObject:@"开票金额"];
    [invoicesArray addObject:@"更多信息"];
    return invoicesArray;
}

+(NSMutableArray *)getUserInfoWith:(invoiceType)type{
    
    NSMutableArray *infoArray = [NSMutableArray array];
    
    if (type == invoiceTypeNet) {
        [infoArray addObject:@"联系人姓名"];
        [infoArray addObject:@"电话"];
        [infoArray addObject:@"邮箱"];

    }else{
        [infoArray addObject:@"联系人姓名"];
        [infoArray addObject:@"电话"];
        [infoArray addObject:@"地址"];
        [infoArray addObject:@"门牌号"];

    }
    
    return infoArray;
}



@end
