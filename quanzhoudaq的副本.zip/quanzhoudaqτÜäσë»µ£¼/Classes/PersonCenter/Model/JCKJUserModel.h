//
//  JCKJUserModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJUserModel : NSObject <NSCoding>

@property (nonatomic ,copy) NSString *email;
@property (nonatomic ,copy) NSString *freeze_money;
@property (nonatomic ,copy) NSString *head;
@property (nonatomic ,copy) NSString *isdriver;
@property (nonatomic ,copy) NSString *mount;
@property (nonatomic ,copy) NSString *name;
@property (nonatomic ,copy) NSString *nick;
@property (nonatomic ,copy) NSString *online;
@property (nonatomic ,copy) NSString *phone;
@property (nonatomic ,copy) NSString *sex;
@property (nonatomic ,copy) NSString *status;
@property (nonatomic ,copy) NSString *userid;

@end
