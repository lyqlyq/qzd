//
//  JCKJUserTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJUserTool.h"
#import "JCKJUserModel.h"

#define fileName [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject stringByAppendingPathComponent:@"usermodel.data"]




@implementation JCKJUserTool

+(void)save:(JCKJUserModel *)user{
    
    [NSKeyedArchiver archiveRootObject:user toFile:fileName];
    
}
+(void)remove{
    
    [NSKeyedArchiver archiveRootObject:nil toFile:fileName];
}
+(JCKJUserModel *)getUser{
    
    if(![[NSFileManager defaultManager] fileExistsAtPath:fileName])
    {
        return nil;
    }
    
    JCKJUserModel *model = [NSKeyedUnarchiver unarchiveObjectWithFile:fileName];
    return  model;
    
}
+(void)updateUser:(JCKJUserModel *)user{
    
    // 删除
    [self remove];
    
    //
    // 保存
    [self save:user];
    
}

+(BOOL)checkHaseUser{
    
    JCKJUserModel *user =   [self getUser];
    
    if (user == nil) {
        return NO;
    }else{
        
        return YES;
    }
    
}




@end
