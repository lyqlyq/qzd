//
//  JCKJUserTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJUserModel;

@interface JCKJUserTool : NSObject

+(void)save:(JCKJUserModel *)user;
+(void)remove;
+(JCKJUserModel *)getUser;
+(void)updateUser:(JCKJUserModel *)user;
+(BOOL)checkHaseUser;

@end
