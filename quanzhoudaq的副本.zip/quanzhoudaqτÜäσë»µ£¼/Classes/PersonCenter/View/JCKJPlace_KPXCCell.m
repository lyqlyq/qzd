//
//  JCKJPlace_KPXCCell.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/2.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPlace_KPXCCell.h"

@implementation JCKJPlace_KPXCCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


+(instancetype)kpxcPlaceCell:(UITableView *)tableView{
    
    JCKJPlace_KPXCCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(self)];
    if (cell == nil) {
        cell = [JCKJPlace_KPXCCell xmg_viewFromXib];
    }
    return cell;
}
- (IBAction)choseButtonClick:(UIButton *)sender {
    
    sender.selected = !sender.selected;
}

@end
