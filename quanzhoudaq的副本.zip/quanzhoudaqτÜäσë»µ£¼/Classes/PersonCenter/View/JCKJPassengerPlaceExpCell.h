//
//  JCKJPassengerPlaceExpCell.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/2.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCKJPassengerPlaceExpCell : UITableViewCell


+(instancetype)passengerPlaceExpCellWithTableView:(UITableView *)tableView;

@end
