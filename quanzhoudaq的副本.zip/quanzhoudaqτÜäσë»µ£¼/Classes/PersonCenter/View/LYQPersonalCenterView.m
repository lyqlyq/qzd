//
//  LYQPersonalCenterView.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQPersonalCenterView.h"

#import "LYQPersonModel.h"
#import <UIImageView+WebCache.h>
#import "JCKJUserModel.h"

@interface LYQPersonalCenterView ()<UITableViewDelegate,UITableViewDataSource>


@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UIImageView *hederImageV;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

@property (nonatomic ,strong) NSMutableArray *models;

@property (weak, nonatomic) IBOutlet UIView *leftView;

@end


@implementation LYQPersonalCenterView

+(instancetype)personalCenterView{
    
    LYQPersonalCenterView *personView = [LYQPersonalCenterView xmg_viewFromXib];
 
    return personView;
    
}

-(void)setModel:(JCKJUserModel *)model{
    _model = model;
    [self.hederImageV sd_setImageWithURL:[NSURL URLWithString:model.head] placeholderImage:headerImageDefault];
    self.nameLabel.text = model.nick;
}

-(void)awakeFromNib{
    
    [super awakeFromNib];
    
    [self.hederImageV cornerWithRadiusSize:40];
    

    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.backgroundColor = LYQ_RGB_COLOR_A_Mian;
    
    self.leftView.transform = CGAffineTransformMakeTranslation(-LYQ_SCREEN_W, 0);
    
    
    [self loadData];
    
}

-(void)loadData{
    
    self.models = [LYQPersonModel persons];
    
}

-(void)show{
    
  
    [LYQ_KeyWindow addSubview:self];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.leftView.transform = CGAffineTransformIdentity;

    }];
    
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [self dissmissCompletion:nil];
}

-(void)dissmissCompletion:(void(^)())completion{
    
    [UIView animateWithDuration:0.3 animations:^{
        self.leftView.transform = CGAffineTransformMakeTranslation(-LYQ_SCREEN_W, 0);;
    } completion:^(BOOL finished) {
        if (completion) {
            completion();
        }
        [self removeFromSuperview];
    }];
    
}



#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.models.count;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cell_Id = @"cell_Id";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cell_Id];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cell_Id];
    }
    
    LYQPersonModel *model = self.models[indexPath.row];
    
    cell.textLabel.text = model.title_name;
    cell.imageView.image = LYQ_IMAGENAME(model.image_name);
    cell.textLabel.textColor = jckj_label_Text_Color;
    cell.textLabel.font = LYQ_SYS_FONT(14);
    
    UIView *bgView = [[UIView alloc] init];
    bgView.frame = cell.frame;
    bgView.backgroundColor = jckj_COLOR_ligthRed;
    cell.selectedBackgroundView = bgView;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LYQPersonModel *model = self.models[indexPath.row];
    
    [self dissmissCompletion:^{
        if (self.didSelectRowBlock) {
            self.didSelectRowBlock(model);
        }
    }];

    
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 55.0f;
}


@end
