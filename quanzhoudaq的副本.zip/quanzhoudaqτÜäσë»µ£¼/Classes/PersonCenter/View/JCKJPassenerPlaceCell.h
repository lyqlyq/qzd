//
//  JCKJPassenerPlaceCell.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/2.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCKJPassenerPlaceCell : UITableViewCell


+(instancetype)passengerPlaceCellWithTableView:(UITableView *)tableView;

@end
