//
//  JCKJPassenerPlaceCell.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/2.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPassenerPlaceCell.h"

@implementation JCKJPassenerPlaceCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+(instancetype)passengerPlaceCellWithTableView:(UITableView *)tableView{
    
    JCKJPassenerPlaceCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    
    if (cell == nil) {
        cell = [JCKJPassenerPlaceCell xmg_viewFromXib];
    }
    
    return cell;
    
}

@end
