//
//  LYQAnimateView.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/24.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQAnimateView.h"

@interface LYQAnimateView ()

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomView_H;

@end

@implementation LYQAnimateView

+(instancetype)animateViewWithBottomHeight:(CGFloat)height{
    
    LYQAnimateView *animateView = [LYQAnimateView xmg_viewFromXib];
    animateView.bottomView_Height = height;
    return animateView;
}

-(void)setBottomView_Height:(CGFloat)bottomView_Height{
    _bottomView_Height = bottomView_Height;
    self.bottomView.transform = CGAffineTransformMakeTranslation(0, bottomView_Height);
    self.bottomView_H.constant = bottomView_Height;
}

-(void)show{
    [LYQ_KeyWindow addSubview:self];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.transform = CGAffineTransformIdentity;
        self.backgroundColor = LYQ_RGB_COLOR_A_Mian;
    }];
    
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    [self dissmissWithCompletion:nil];
    
}

-(void)dissmissWithCompletion:(void(^)())completion{
    
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.transform = CGAffineTransformMakeTranslation(0, self.bottomView_Height);
        self.backgroundColor = LYQ_RGB_COLOR_A(0, 0, 0, 0);

    }completion:^(BOOL finished) {
        [self  removeFromSuperview];
        if (completion) {
            completion();
        }
    } ];
    
}


@end
