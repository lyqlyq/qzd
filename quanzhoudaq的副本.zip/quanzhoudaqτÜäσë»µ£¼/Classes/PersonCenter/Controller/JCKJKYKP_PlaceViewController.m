//
//  JCKJKYKP_PlaceViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/2.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJKYKP_PlaceViewController.h"

#import "JCKJPlace_KPXCCell.h"

@interface JCKJKYKP_PlaceViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UIButton *nextButton;
@end

@implementation JCKJKYKP_PlaceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title =@"可开票行程";
    
    [self.nextButton cornerWithRadiusSize:4];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 1;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 5;
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    JCKJPlace_KPXCCell *cell = [JCKJPlace_KPXCCell kpxcPlaceCell:tableView];
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 102.0f;
}

/**下一步*/
- (IBAction)nextBUttonClick:(UIButton *)sender {
    
    
    
}

@end
