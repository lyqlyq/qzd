//
//  LYQPersonalCenterController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQPersonalCenterController.h"

@interface LYQPersonalCenterController ()

@end

@implementation LYQPersonalCenterController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    
    
    
}



@end
