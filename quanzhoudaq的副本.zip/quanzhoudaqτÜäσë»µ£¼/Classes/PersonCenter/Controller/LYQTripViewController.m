//
//  LYQTripViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQTripViewController.h"
#import "JCKJPassenerPlaceCell.h"
#import "JCKJPassengerPlaceExpCell.h"

#import "LYQCancleBarButton.h"
#import "JCKJKYKP_PlaceViewController.h"

@interface LYQTripViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lineView_X;

@property (nonatomic ,strong) UIButton *seleButton;
@property (weak, nonatomic) IBOutlet UIButton *sk_button;
@property (weak, nonatomic) IBOutlet UIButton *cz_button;

@end

@implementation LYQTripViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"我的行程";
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    self.navigationItem.rightBarButtonItem = [LYQCancleBarButton addItemPlaceButton:self action:@selector(kaifapiao) Title:@"开发票"];
    
    
  
}
/**开发票*/
-(void)kaifapiao{
    
    JCKJKYKP_PlaceViewController *kpVC = [[JCKJKYKP_PlaceViewController alloc] init];
    [self.navigationController pushViewController:kpVC animated:YES];
    
}

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 3;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    JCKJPassenerPlaceCell *cell = [JCKJPassenerPlaceCell passengerPlaceCellWithTableView:tableView];
    JCKJPassengerPlaceExpCell *exPcell = [JCKJPassengerPlaceExpCell passengerPlaceExpCellWithTableView:tableView];
    
    if (indexPath.row == 0) {
        return exPcell;
    }
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        return 151.0f;
    }
    return 108.0f;

}



@end
