//
//  LYQTheWalletViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQTheWalletViewController.h"

#import "LYQRechargeViewController.h"

#import "JCKJUserModel.h"
#import "JCKJUserTool.h"

@interface LYQTheWalletViewController ()
@property (weak, nonatomic) IBOutlet UIButton *tx_Button;
@property (weak, nonatomic) IBOutlet UIButton *cz_Button;
@property (weak, nonatomic) IBOutlet UIButton *price;

@end

@implementation LYQTheWalletViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    [self.tx_Button cornerWithRadiusSize:4];
    [self.cz_Button cornerWithRadiusSize:4];
 
    JCKJUserModel *model = [JCKJUserTool getUser];
    
    [self.price setTitle:model.freeze_money forState:UIControlStateNormal];
    
    
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)txButtonClick:(id)sender {
    LYQRechargeViewController *rechargeVC = [[LYQRechargeViewController alloc] init];
    rechargeVC.is_CZ = NO;
    [self.navigationController pushViewController:rechargeVC animated:YES];
    
}
- (IBAction)czButtonClick:(id)sender {
    
    LYQRechargeViewController *rechargeVC = [[LYQRechargeViewController alloc] init];
    rechargeVC.is_CZ = YES;

    [self.navigationController pushViewController:rechargeVC animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
