//
//  LYQTheownerCertificationViewController.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYQTheownerCertificationViewController : UIViewController

@end
