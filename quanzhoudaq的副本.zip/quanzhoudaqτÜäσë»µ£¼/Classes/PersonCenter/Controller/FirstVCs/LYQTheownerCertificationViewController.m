
//
//  LYQTheownerCertificationViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQTheownerCertificationViewController.h"
#import "LYQJZAndXSZView.h"


@interface LYQTheownerCertificationViewController ()
@property (weak, nonatomic) IBOutlet UIButton *jz_Button;
@property (weak, nonatomic) IBOutlet UIButton *xsz_Button;
@property (weak, nonatomic) IBOutlet UIButton *tjsh_Button;
@property (weak, nonatomic) IBOutlet UIButton *jzfy_button;

@property (nonatomic ,strong) LYQJZAndXSZView *jaAndxszView;

@end

@implementation LYQTheownerCertificationViewController


-(LYQJZAndXSZView *)jaAndxszView{
    if (_jaAndxszView == nil) {
        _jaAndxszView = [LYQJZAndXSZView xmg_viewFromXib];
    }
    
    return _jaAndxszView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    LYQ_WEAK_SELF(self);
    
    self.jaAndxszView.choseImage = ^(UIImage *seleImage){
        
        if (weakself.jaAndxszView.type == viewType_JZ) {
            [weakself.jz_Button setBackgroundImage:seleImage forState:UIControlStateNormal];
            weakself.jz_Button.selected = YES;
        }else if(weakself.jaAndxszView.type == viewType_XSZ){
            [weakself.xsz_Button setBackgroundImage:seleImage forState:UIControlStateNormal];
            weakself.xsz_Button.selected = YES;
        }else{
            [weakself.jzfy_button setBackgroundImage:seleImage forState:UIControlStateNormal];
            weakself.jzfy_button.selected = YES;
            
        }
        
        
        
        [weakself changeTJButtonstatus];
       
    };
    
}

-(void)changeTJButtonstatus{
    
    
    if (self.jz_Button.selected && self.xsz_Button.selected) {
        self.tjsh_Button.userInteractionEnabled = YES;
        [self.tjsh_Button setBackgroundColor:LYQ_COLOR_WITH_HEX(0x232323)];
    }else{
        self.tjsh_Button.userInteractionEnabled = NO;
        [self.tjsh_Button setBackgroundColor:LYQ_COLOR_WITH_HEX(0x565553)];

    }
    
    
    
}

- (IBAction)jzButtonClick:(UIButton *)sender {
    
    self.jaAndxszView.type = viewType_JZ;
    
    [self.jaAndxszView show];
    
    
}
- (IBAction)xszButtonClick:(UIButton *)sender {
    
    self.jaAndxszView.type = viewType_XSZ;
    
    [self.jaAndxszView show];
    
}
- (IBAction)jzfyButtonClick:(UIButton *)sender {
    
    self.jaAndxszView.type = viewType_JZFY;
    
    [self.jaAndxszView show];
}



- (IBAction)tjsh_ButtonClick:(UIButton *)sender {
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
