//
//  LYQTextFiledMangerTool.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/21.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQTextFiledMangerTool.h"

@interface LYQTextFiledMangerTool()<UITextFieldDelegate>

@property (nonatomic ,strong) NSMutableArray *textFileds;

@end

@implementation LYQTextFiledMangerTool

-(void)getAllMangerTextFileds{
    
    self.textFileds = [self.delegate textFiledMangerWithTextFiledArray:self];
    
    for (UITextField *textF in self.textFileds) {
        
        [textF addTarget:self action:@selector(textFieldTextChange:) forControlEvents:UIControlEventEditingChanged];
        
    }
    
}
-(void)textFieldTextChange:(UITextField *)textF{
    
    BOOL isNext = YES;
    for (UITextField *textF in self.textFileds) {
        isNext = textF.text.length > 0 && isNext;
        if (isNext == NO) {
            self.isNext = NO;
            [self.delegate textFiledMangerNoClickAble:self];
            return;
        }
        
    }
    if (isNext) {
        self.isNext = YES;
        [self.delegate textFiledMangerCanBeClick:self];

    }
    
    
}


-(void)startMangerTextFs{
    
    [self getAllMangerTextFileds];
    
    
}



@end
