//
//  JCKJPersonCenterRequestTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@class JCKJUserModel;
@interface JCKJPersonCenterRequestTool : NSObject


/**获取司机信息的接口*/
+(void)get_detailsSuccess:(void(^)(JCKJUserModel *model))success failure:(void(^)(NSError *error))failure;

@end
