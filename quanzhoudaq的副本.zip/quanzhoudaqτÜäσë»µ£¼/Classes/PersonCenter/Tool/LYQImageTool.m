//
//  LYQImageTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/31.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQImageTool.h"

#import <Photos/Photos.h>

@interface LYQImageTool ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@end


@implementation LYQImageTool

static UIImagePickerController *_imagePickerController;
static  void(^_successBlock)(UIImage *image);
static LYQImageTool *_imageTool;

+(void)imageToolWithType:(choseImageType)type Success:(void (^)(UIImage *image))success{
    
    
    if (_imageTool == nil) {
        _imageTool = [[self alloc] init];
    }

    if (_imagePickerController == nil) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.delegate = _imageTool;
        _imagePickerController.allowsEditing = YES;
    }

    
    _successBlock = success;

    
    // 相册
    if (type == choseImageType_XC) {
        
        if (![self isChosePicture]) return;

        _imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [LYQ_KeyWindow.rootViewController presentViewController:_imagePickerController animated:YES completion:nil];
        
        
    }else{
        // 相机
        if (![self isChoseVideo]) return;
        
        _imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        [LYQ_KeyWindow.rootViewController presentViewController:_imagePickerController animated:YES completion:nil];
    }
    
    
}


// 是否口选择照片
+(BOOL)isChosePicture{
    
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    if (status == PHAuthorizationStatusRestricted ||
        status == PHAuthorizationStatusDenied) {
        
        
        LYQ_SHOW_INFO(@"没有相册权限");
        
        return NO;
        

        
    }
    return YES;
}

// 是否可以选择相机
+(BOOL)isChoseVideo{
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (authStatus ==AVAuthorizationStatusRestricted ||//此应用程序没有被授权访问的照片数据。可能是家长控制权限
        authStatus ==AVAuthorizationStatusDenied)  //用户已经明确否认了这一照片数据的应用程序访问
    {
        
        LYQ_SHOW_INFO(@"没有相机权限");

        
        return NO;
    }
    
    return YES;
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage *image  = info[UIImagePickerControllerOriginalImage];
    
    if (_successBlock) {
        _successBlock(image);
    }
    
    
}


@end
