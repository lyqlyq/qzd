//
//  JCKJPersonCenterRequestTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPersonCenterRequestTool.h"
#import "LYQRequestTool.h"
#import "JCKJUserModel.h"
#import "JCKJUserTool.h"


@implementation JCKJPersonCenterRequestTool

/**获取司机信息的接口*/
+(void)get_detailsSuccess:(void(^)(JCKJUserModel *model))success failure:(void(^)(NSError *error))failure;
{
    
    JCKJUserModel *model =  [JCKJUserTool getUser];
    
    if (model) {
        if (success) {
            success(model);
        }
    }else{
        [LYQRequestTool POSTURL:@"get-details" params:nil success:^(id responseObject) {
            
            JCKJUserModel *model = [JCKJUserModel mj_objectWithKeyValues:responseObject];
            [JCKJUserTool save:model];
            if (success) {
                success(model);
            }
            
        } failure:^(NSError *error) {
            
            
            
        } showMessage:nil isShowMessage:YES];
    }
    
   
    
    
}

@end
