//
//  LYQTextFiledMangerTool.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/21.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


@class LYQTextFiledMangerTool;
@protocol LYQTextFiledMangerToolDelegate

@required


-(NSMutableArray <UITextField *> *)textFiledMangerWithTextFiledArray:(LYQTextFiledMangerTool *)manger;

@optional

/**不可以点击*/
-(void)textFiledMangerNoClickAble:(LYQTextFiledMangerTool *)manger;
/**可以点击*/
-(void)textFiledMangerCanBeClick:(LYQTextFiledMangerTool *)manger;


@required

@end

@interface LYQTextFiledMangerTool : NSObject

@property (nonatomic ,weak) id <LYQTextFiledMangerToolDelegate> delegate;

/**可以跳转了*/
@property (nonatomic ,assign) BOOL isNext;

/**开始管理*/
-(void)startMangerTextFs;


@end
