//
//  AppDelegate.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "AppDelegate.h"
#import "LYQChoseWindowTool.h"
#import "LYQTherePartyTool.h"
#import "LYQNavController.h"

#ifdef NSFoundationVersionNumber_iOS_9_x_Max
#import <UserNotifications/UserNotifications.h>
#endif

#import <WXApi.h>

#import "LYQAlertView.h"



//#import "LYQPassengerDetailsController.h"
#import "LYQTimeTool.h"

#import "LYQCheckUserOpenLocationTool.h"




@interface AppDelegate ()<WXApiDelegate>

@property (nonatomic ,strong) LYQCheckUserOpenLocationTool *userLocationTool;

@property (nonatomic ,strong) LYQAlertView *alertView;

@end

@implementation AppDelegate

-(LYQCheckUserOpenLocationTool *)userLocationTool{
    
    if (_userLocationTool == nil) {
        _userLocationTool = [[LYQCheckUserOpenLocationTool alloc] init];
    }
    return _userLocationTool;
    
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
  
    [LYQChoseWindowTool choseWindowWithWindow:self.window];
    //请求定位服务 
    [self.userLocationTool checkLocationServicesAuthorizationStatus];

    [LYQTherePartyTool startKeyboardMgr];
    
    [LYQTherePartyTool setUpAMapServicesKey];
    
    [LYQTherePartyTool setUpJPush:launchOptions delegate:self];
    
    [LYQTherePartyTool setBageZeroNumber];
    
    
    
    [WXApi registerApp:@"wxa963062d72a92503"];
    
    
    return YES;
}


- (void)application:(UIApplication *)application
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    
    [LYQTherePartyTool registerDeviceToken:deviceToken];
    

}

/*
 * app在前台的时候会收到推送消息
 */
- (void)jpushNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(NSInteger))completionHandler {
    
    
    // Required
    NSDictionary * userInfo = notification.request.content.userInfo;
    
    
    if([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        [LYQTherePartyTool handleRemoteNotification:userInfo];
    }
    completionHandler(UNNotificationPresentationOptionAlert|UNNotificationPresentationOptionSound|UNNotificationPresentationOptionBadge); // 需要执行这个方法，选择是否提醒用户，有Badge、Sound、Alert三种类型可以选择设置
    
    //self.alertView.model = ;
    
    
    [self showWithDic:userInfo];
   

}

-(void)showWithDic:(NSDictionary *)userInfo{
    
}


// iOS 10 Support
- (void)jpushNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)())completionHandler {
    // Required
    NSDictionary * userInfo = response.notification.request.content.userInfo;
    if([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        [LYQTherePartyTool handleRemoteNotification:userInfo];
    }

    
    [self showWithDic:userInfo];
    
    
    
    completionHandler();  // 系统要求执行这个方法
}


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    
    
   // show(@"IOS - 9");
    LYQ_SHOW_INFO(@"Required, iOS 7 Support");
    
  
    // Required, iOS 7 Support
    [LYQTherePartyTool handleRemoteNotification:userInfo];
    completionHandler(UIBackgroundFetchResultNewData);
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    LYQ_SHOW_INFO(@"Required, iOS 6 Support");

    // Required,For systems with less than or equal to iOS6
    [LYQTherePartyTool handleRemoteNotification:userInfo];
}



-(BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
    
    return  [WXApi handleOpenURL:url delegate:(id<WXApiDelegate>)self];
    
}
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    
     return  [WXApi handleOpenURL:url delegate:(id<WXApiDelegate>)self];
}
- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation{
    
     return  [WXApi handleOpenURL:url delegate:(id<WXApiDelegate>)self];
}

-(void)applicationDidBecomeActive:(UIApplication *)application{
    
  //  LYQ_SHOW_INFO(@"active");
    
}

-(void) onResp:(BaseResp*)resp
{
    
    //启动微信支付的response
    if([resp isKindOfClass:[PayResp class]]){
        //支付返回结果，实际支付结果需要去微信服务器端查询
        switch (resp.errCode) {
            case 0:
                LYQ_SHOW_INFO(@"支付成功");
                [[NSNotificationCenter defaultCenter]  postNotificationName:POST_NAME_WECHATPAY_SUCCESS object:nil];
                
                break;
            case -1:
     
                LYQ_SHOW_INFO(@"支付失败");

                break;
            case -2:
            
                LYQ_SHOW_INFO(@"取消支付");
                break;
            default:
                LYQ_SHOW_INFO(@"支付失败");

                break;
        }
    }
}



@end
