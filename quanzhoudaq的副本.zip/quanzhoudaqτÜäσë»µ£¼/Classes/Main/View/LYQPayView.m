//
//  LYQPayView.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/17.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQPayView.h"
#import "LYQPayParam.h"

#import "LYQTherePartyTool.h"
#import "JCKJMoneyButton.h"
#import "LYQRequestTool.h"

@interface LYQPayView ()

@property (weak, nonatomic) IBOutlet UIButton *weChatStatusButton;
@property (weak, nonatomic) IBOutlet UIButton *aiPayStatusButton;
@property (weak, nonatomic) IBOutlet UIButton *mySelfStatusButton;
@property (weak, nonatomic) IBOutlet UIView *weChatView;
@property (weak, nonatomic) IBOutlet UIView *aiPayView;
@property (weak, nonatomic) IBOutlet UIView *mySelfView;
@property (weak, nonatomic) IBOutlet UIView *bottomView;

@property (nonatomic ,strong) UIButton *selePayButton;

@property (weak, nonatomic) IBOutlet JCKJMoneyButton *priceButton;

#define bottom_H 309

@end

@implementation LYQPayView


+(instancetype)payViewWithPayParam:(LYQPayParam *)param{
    
    LYQPayView *payView = [LYQPayView xmg_viewFromXib];
    payView.frame =  CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
    payView.payParam = param;
    payView.bottomView.transform = CGAffineTransformMakeTranslation(0, bottom_H);

    return payView;
}


-(void)setPayParam:(LYQPayParam *)payParam{
    _payParam = payParam;
    
    [self.priceButton setTitle:[NSString stringWithFormat:@"%@",payParam.place_money] forState:UIControlStateNormal];
    
}


-(void)awakeFromNib{
    [super awakeFromNib];
    self.autoresizingMask = UIViewAutoresizingNone;
    self.selePayButton  =   self.weChatStatusButton;
    self.priceButton.money = 10;
    self.priceButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    
}
- (IBAction)weChatButtonClick:(UIButton *)sender {
       [self changeButtonStatus:self.weChatStatusButton];
}
- (IBAction)aiPayButtonClick:(UIButton *)sender {
     [self changeButtonStatus:self.aiPayStatusButton];
}
- (IBAction)mySelfButtonClick:(UIButton *)sender {
     [self changeButtonStatus:self.mySelfStatusButton];
}


-(void)changeButtonStatus:(UIButton *)seleButton{
    self.selePayButton.selected = NO;
    seleButton.selected = YES;
    self.selePayButton = seleButton;
}

-(void)show{
    
    
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.transform = CGAffineTransformIdentity;
        self.backgroundColor = LYQ_RGB_COLOR_A_Mian;
    }];
    
    [LYQ_KeyWindow addSubview:self];
}
-(void)dissmissWithCompletion:(void(^)())completion{
    
    self.bottomView.transform = CGAffineTransformIdentity;
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.xmg_y = LYQ_SCREEN_H;
    }completion:^(BOOL finished) {
        [self  removeFromSuperview];
        if (completion) {
            completion();
        }
    } ];
    
}


-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self dissmissWithCompletion:nil];
}

- (IBAction)surePayClick:(UIButton *)sender {
    
    [self dissmissWithCompletion:^{

        
        LYQ_WEAK_SELF(self);
        
        // 微信支付
        if (self.selePayButton == self.weChatStatusButton) {
   
            [LYQRequestTool POSTURL:@"wechat" params:weakself.payParam.mj_keyValues success:^(id responseObject) {
                
                [LYQTherePartyTool wChatPay:responseObject];
                
            } failure:^(NSError *error) {
                
            } showMessage:nil isShowMessage:YES];
          
            

        }
        // 支付宝支付
        if (self.selePayButton == self.aiPayStatusButton) {
            
            [LYQRequestTool POSTURL:@"alipay" params:self.payParam.mj_keyValues success:^(id responseObject) {
                
            } failure:^(NSError *error) {
                
            } showMessage:nil isShowMessage:YES];
            
            
            
        }
        // 全州达支付
        if (self.selePayButton == self.weChatStatusButton) {

        }
        
        
    }];
    
}

- (IBAction)weChatTap:(id)sender {
    
}


@end
