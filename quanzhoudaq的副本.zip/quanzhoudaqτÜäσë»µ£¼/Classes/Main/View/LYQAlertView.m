//
//  LYQAlertView.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/19.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQAlertView.h"


@interface LYQAlertView ()
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIButton *cancleButton;
@property (weak, nonatomic) IBOutlet UIButton *sureButton;
/**知道了*/
@property (weak, nonatomic) IBOutlet UIButton *konwButton;
@property (weak, nonatomic) IBOutlet UIView *allView;
@property (weak, nonatomic) IBOutlet UIImageView *titleImage;
@property (weak, nonatomic) IBOutlet UITextField *codeTextF;
@property (weak, nonatomic) IBOutlet UILabel *errorLabel;

@end


@implementation LYQAlertView


+(instancetype)alertViewWithType:(alertViewType)type{
    
    return [self alertViewWithType:type title:nil];
    
}

+(instancetype)alertViewWithType:(alertViewType)type model:(LYQAlertModel *)model{
    
    LYQAlertView *alertView = [LYQAlertView xmg_viewFromXib];
 //  alertView.model = model;
    alertView.type = type;
    alertView.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
//    alertView.allView.transform = CGAffineTransformMakeTranslation(0, - CGRectGetMaxY(alertView.allView.frame));
    alertView.allView.transform = CGAffineTransformScale(CGAffineTransformIdentity,
                                            CGFLOAT_MIN, CGFLOAT_MIN);
    
    return alertView;
}

+(instancetype)alertViewWithType:(alertViewType)type title:(NSString *)title{
    LYQAlertView *alertView = [LYQAlertView xmg_viewFromXib];
    alertView.type = type;
    alertView.contentText = title;
    alertView.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
   // alertView.allView.transform = CGAffineTransformMakeTranslation(0, - CGRectGetMaxY(alertView.allView.frame));
    
    alertView.allView.transform = CGAffineTransformScale(CGAffineTransformIdentity,
                                                         CGFLOAT_MIN, CGFLOAT_MIN);
    
    return alertView;

}


-(void)setContentText:(NSString *)contentText{
    
    if (contentText == nil) return;
    _contentText = contentText;
    self.contentLabel.text = contentText;

}

-(void)setAttributedText:(NSAttributedString *)attributedText{
    
    _attributedText = attributedText;
    self.contentLabel.attributedText = attributedText;

}


-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.konwButton.hidden = YES;
    self.autoresizingMask = UIViewAutoresizingNone;
}

//-(void)setModel:(LYQAlertModel *)model{
//    if (model == nil)  return;
//    _model = model;
//
//    self.contentLabel.text = model.content;
//}

-(void)setType:(alertViewType)type{
    
    _type = type;
    self.konwButton.hidden = YES;

    if (type == alertViewType_CK) {
        [self.sureButton setTitle:@"查看" forState:UIControlStateNormal];
    }
    if (type == alertViewType_I_KNOW) {
        self.konwButton.hidden = NO;
    }
    if (type == alertViewType_Call) {
        
        self.titleImage.image = LYQ_IMAGENAME(@"phone");
        [self.sureButton setTitle:@"拨打" forState:UIControlStateNormal];

    }
    if (type == alertViewType_SJ_CKDD) {
        [self.sureButton setTitle:@"查看订单" forState:UIControlStateNormal];
    }
    if (type == alertViewType_SJ_QRSD) {
        [self.sureButton setTitle:@"确认送达" forState:UIControlStateNormal];

    }
    if (type == alertViewType_SJ_CODE) {
        self.contentText = @"请输入收货人验证码";
        self.codeTextF.hidden = NO;
        [self.sureButton setTitle:@"确认" forState:UIControlStateNormal];

        
    }
    
    
    
    
}

-(void)show{
    
    [LYQ_KeyWindow addSubview:self];
    
//    [UIView animateWithDuration:0.3 animations:^{
//        self.allView.transform = CGAffineTransformIdentity;
//        self.backgroundColor = LYQ_RGB_COLOR_A_Mian;
//    }];
    
    [self showAimain];
    
    
    
}

-(void)showAimain{
    
    [UIView animateWithDuration:0.3
                     animations:^{
                         // 第二步： 以动画的形式将view慢慢放大至原始大小的1.2倍
                         self.allView.transform =
                         CGAffineTransformScale(CGAffineTransformIdentity, 1.2, 1.2);
                         self.backgroundColor = LYQ_RGB_COLOR_A_Mian;

                     }
                     completion:^(BOOL finished) {
                         [UIView animateWithDuration:0.2
                                          animations:^{
                                              // 第三步： 以动画的形式将view恢复至原始大小
                                              self.allView.transform = CGAffineTransformIdentity;
                                          }];
                     }];

    
}


-(void)dissmiss{
    
//    [UIView animateWithDuration:0.3 animations:^{
//        self.allView.transform = CGAffineTransformMakeTranslation(0, - CGRectGetMaxY(self.allView.frame));
//        self.backgroundColor = LYQ_RGB_COLOR_A(0, 0, 0, 0);
//    } completion:^(BOOL finished) {
//        [self removeFromSuperview];
//    }];
    
    [self closeAnimated];
    
    
}

- (void)closeAnimated{

        [UIView animateWithDuration:0.2
                         animations:^{
                             // 第一步： 以动画的形式将view慢慢放大至原始大小的1.2倍
                             self.allView.transform =
                             CGAffineTransformScale(CGAffineTransformIdentity, 1.2, 1.2);
                         }
                         completion:^(BOOL finished) {
                             [UIView animateWithDuration:0.3
                                              animations:^{
                                                  // 第二步： 以动画的形式将view缩小至原来的1/1000分之1倍
                                                  self.allView.transform = CGAffineTransformScale(
                                                                                                  CGAffineTransformIdentity, 0.001, 0.001);
                                                  self.backgroundColor = LYQ_RGB_COLOR_A(0, 0, 0, 0);

                                              }
                                              completion:^(BOOL finished) {
                                                  // 第三步： 移除
                                                  [self removeFromSuperview];
                                              }];
                         }];
    
}



-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self dissmiss];
}
- (IBAction)konwClick:(id)sender {
    [self dissmiss];
    
    if (self.knowClick) {
        self.knowClick();
    }
}


- (IBAction)sureClick:(id)sender {
    [self dissmiss];
    
    if (self.sureClick) {
        self.sureClick();
    }
    
    

}
- (IBAction)cancleClick:(id)sender {
    [self dissmiss];
    
}

@end
