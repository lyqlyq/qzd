//
//  LYQAlertView.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/19.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


@class LYQAlertModel;
typedef enum : NSUInteger {
    alertViewType_CK,
    alertViewType_SURE,
    alertViewType_I_KNOW,
    alertViewType_Call,
    alertViewType_SJ_CKDD,
    alertViewType_SJ_QRSD, // 确认送达
    alertViewType_SJ_CODE  //  确认送达发送验证码成功界面
} alertViewType;

@interface LYQAlertView : UIView

@property (nonatomic ,copy) void (^knowClick)();
@property (nonatomic ,copy) void (^sureClick)();

//@property (nonatomic ,strong) LYQAlertModel *model;

@property (nonatomic ,copy) NSString *contentText;

@property (nonatomic ,copy) NSAttributedString *attributedText;
@property (nonatomic ,copy) NSString *dt_id;



@property (nonatomic ,assign) alertViewType type;

//+(instancetype)alertViewWithType:(alertViewType)type model:(LYQAlertModel *)model;

+(instancetype)alertViewWithType:(alertViewType)type;
+(instancetype)alertViewWithType:(alertViewType)type title:(NSString *)title;



-(void)show;
-(void)dissmiss;

@end
