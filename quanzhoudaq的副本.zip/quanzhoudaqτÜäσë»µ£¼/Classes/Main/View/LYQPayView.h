//
//  LYQPayView.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/17.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LYQPayParam;
@interface LYQPayView : UIView

@property (nonatomic ,strong) LYQPayParam *payParam;


+(instancetype)payViewWithPayParam:(LYQPayParam *)param;

-(void)show;

@end
