//
//  JCKJMoneyButton.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJMoneyButton.h"

@implementation JCKJMoneyButton

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setUp];
    }
    return self;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self setUp];

}

-(void)setUp{
    
    self.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self setTitleEdgeInsets:UIEdgeInsetsMake(0, 5, 0, 0)];
    [self setImageEdgeInsets:UIEdgeInsetsMake(5, 0, 0, 0)];
    
    [self setTitleColor:jckj_COLOR_ligthRed forState:UIControlStateNormal];
    self.titleLabel.font = LYQ_SYS_FONT(12);
    NSString *moneyText = [NSString stringWithFormat:@"%.0f",self.money];
    NSString *text = [NSString stringWithFormat:@"%@ 元",moneyText];
    NSMutableAttributedString *attrText = [[NSMutableAttributedString alloc] initWithString:text];
    [attrText setAttributes:@{NSFontAttributeName:LYQ_SYS_FONT(20)} range:NSMakeRange(0, moneyText.length)];
 
    [attrText addAttribute:NSForegroundColorAttributeName value:jckj_COLOR_ligthRed range:NSMakeRange(0, text.length)];
    [self setAttributedTitle:attrText forState:UIControlStateNormal];
    

    self.isRed = YES;
}

-(void)setIsRed:(BOOL)isRed{
    _isRed = isRed;
    if (isRed) {
        
        UIImage *imageO = [LYQ_IMAGENAME(@"money_red") imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
            [self setImage:imageO forState:UIControlStateNormal];
    }
}



-(void)setIsBlack:(BOOL)isBlack{
    _isBlack = isBlack;
    if (isBlack) {
        
            UIImage *imageO = [LYQ_IMAGENAME(@"money") imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
          [self setImage:imageO forState:UIControlStateNormal];
    }
}


+(instancetype)moneyButton{
    
    JCKJMoneyButton *button = [[JCKJMoneyButton alloc] init];

    return button;
}


@end
