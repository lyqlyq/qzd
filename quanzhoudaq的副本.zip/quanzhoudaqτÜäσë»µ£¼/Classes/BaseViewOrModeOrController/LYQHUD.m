//
//  LYQHUD.m
//  quanzhouda
//
//  Created by pro on 2017/11/24.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQHUD.h"

@interface LYQHUD ()
@property (weak, nonatomic) IBOutlet UIView *hudeVIew;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *indeAmina;
@property (weak, nonatomic) IBOutlet UILabel *infoLabel;

@end


@implementation LYQHUD



-(void)awakeFromNib{
    
    [super awakeFromNib];
    self.hudeVIew.layer.cornerRadius = 4;
    self.hudeVIew.layer.masksToBounds = YES;
    self.hudeVIew.backgroundColor = LYQ_RGB_COLOR_A(0,0,0,0.5);
    self.backgroundColor = [UIColor clearColor];
    self.infoLabel.textColor = [UIColor whiteColor];
    
}

static LYQHUD * _netHUD;

+(void)showDefaluInfo{
    
    if (_netHUD == nil) {
        _netHUD = [LYQHUD xmg_viewFromXib];
        _netHUD.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);

    }
    _netHUD.infoLabel.text = @"加载中...";
    [[UIApplication sharedApplication].keyWindow addSubview:_netHUD];
}

+(void)showMessage:(NSString *)message{
    if (_netHUD == nil) {
        _netHUD = [LYQHUD xmg_viewFromXib];
        _netHUD.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
    }
    
    if (message.length > 0 ) {
        _netHUD.infoLabel.text = message;

    }else{
        _netHUD.infoLabel.text = @"加载中...";
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [[UIApplication sharedApplication].keyWindow addSubview:_netHUD];
    });
}

+(void)dissmiss{
    
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [_netHUD removeFromSuperview];
    });
   
    
}

@end
