//
//  LYQHudView.h
//  quanzhouda
//
//  Created by pro on 2017/11/20.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYQHudView : UIView


// 提示
+(void)showInfo:(NSString *)info;

+(void)showPhoneError;

+(void)showPassWordError;

+(void)showCodeError;

@end
