//
//  LYQBaseViewController.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQBaseViewController.h"

@interface LYQBaseViewController ()

@end

@implementation LYQBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
