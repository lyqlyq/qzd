//
//  LYQBaseViewController.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYQBaseViewController : UIViewController

@end
