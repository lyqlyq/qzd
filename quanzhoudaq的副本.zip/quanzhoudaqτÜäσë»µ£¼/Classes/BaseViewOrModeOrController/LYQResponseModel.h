//
//  LYQResponseModel.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQResponseModel : NSObject

/**code->200（成功） */
@property (nonatomic ,assign) NSInteger code;

/**数据*/
@property (nonatomic ,strong) NSDictionary *success;

@end
