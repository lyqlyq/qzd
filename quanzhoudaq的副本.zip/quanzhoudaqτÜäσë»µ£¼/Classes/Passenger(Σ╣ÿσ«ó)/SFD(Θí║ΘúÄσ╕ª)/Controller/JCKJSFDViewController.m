//
//  JCKJSFDViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/26.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJSFDViewController.h"
#import "LYQChoseTimeView.h"
#import "LYQChoseZhongLiangView.h"
#import "LYQRemarksAndThankView.h"
#import "LYQPayView.h"
#import "JCKJPassengerPushPlaceView.h"
#import "JCKJDriverPushPlaceView.h"


@interface JCKJSFDViewController ()



@end

@implementation JCKJSFDViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
- (IBAction)userCount:(UIButton *)sender {
    
    LYQChoseZhongLiangView *chose = [LYQChoseZhongLiangView xmg_viewFromXib];
    [chose showUserCount];
    LYQ_WEAK_SELF(chose)
    chose.choseZhongBlock = ^(NSString *choseStr) {
        [weakchose dissmissWithCompletion:^{
        }];
        
        [sender setTitle:choseStr forState:UIControlStateNormal];
    };
    
}

- (IBAction)time:(UIButton *)sender {
    
    LYQChoseTimeView *choseView = [LYQChoseTimeView showTitle:@"出发时间"];
    choseView.sureBtnClick = ^(NSString *choseTimeUserContStr, NSString *date) {
        
        [sender setTitle:choseTimeUserContStr forState:UIControlStateNormal];
        
        [LYQChoseTimeView dissmiss:^{
            
        }];
    };
}
- (IBAction)scd:(UIButton *)sender {
    
    LYQChoseZhongLiangView *chose = [LYQChoseZhongLiangView xmg_viewFromXib];
    [chose showPassengerChoseAddressWithAddressArray:nil];
    LYQ_WEAK_SELF(chose)
    chose.choseZhongBlock = ^(NSString *choseStr) {
        [weakchose dissmissWithCompletion:^{
        }];
        
        [sender setTitle:choseStr forState:UIControlStateNormal];
    };
    
}
- (IBAction)beizhu:(id)sender {
    
    [LYQRemarksAndThankView  showRemarksViewWithSeleButtonsBlock:^(NSMutableArray *seleButtons) {
        LYQLog(@"%@",seleButtons);
    }];
    
}

- (IBAction)payView:(UIButton *)sender {
    
    LYQPayView *pv = [LYQPayView payViewWithPayParam:nil];
    [pv show];
    
}
- (IBAction)push:(id)sender {
    
    JCKJPassengerPushPlaceView *pushView = [JCKJPassengerPushPlaceView pushPlaceView];
    
    [pushView show];
}
- (IBAction)czPush:(UIButton *)sender {
    
    JCKJDriverPushPlaceView *pushView = [JCKJDriverPushPlaceView pushPlaceView];
    
    [pushView show];
    
}

@end
