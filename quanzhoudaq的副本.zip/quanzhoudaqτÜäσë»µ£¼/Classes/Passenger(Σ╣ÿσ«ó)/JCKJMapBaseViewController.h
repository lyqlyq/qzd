//
//  JCKJMapBaseViewController.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/20.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MAMapKit/MAMapKit.h>
#import <AMapSearchKit/AMapSearchKit.h>
#import <AMapNaviKit/AMapNaviKit.h>

@class JCKJPriceModel;

@class LYQAddressModel;
@class JCKJExpressOrderModel;
@interface JCKJMapBaseViewController : UIViewController <MAMapViewDelegate,AMapSearchDelegate>

@property (nonatomic ,strong) AMapReGeocodeSearchRequest *regeo;
@property (nonatomic, strong) AMapSearchAPI *search;
@property (nonatomic ,strong) MAMapView *mapView;
@property (nonatomic ,strong) AMapNaviPoint *startPoint;
@property (nonatomic ,strong) AMapNaviPoint *endPoint;


/**开始定位是的回调方法*/
-(void)startSearch;
/**定位成功后的回调*/
-(void)searchDoneWithAddressModel:(LYQAddressModel *)model isRemondArray:(NSMutableArray *)AddressremondArray;

-(void)showAddressViewisRecommend:(BOOL)isRecommend;


-(void)choseStartAddressModel:(LYQAddressModel *)startModels;
-(void)choseEndAddressModel:(LYQAddressModel *)endModels;

-(void)showPriceSuccess:(JCKJPriceModel *)priceModel;
/**重新算路*/
-(void)recalculatetheRoad;

-(void)dissmissSearchView;

/**开始路径规化*/
-(void)startPathPlanning:(JCKJExpressOrderModel *)orderModel;




@end
