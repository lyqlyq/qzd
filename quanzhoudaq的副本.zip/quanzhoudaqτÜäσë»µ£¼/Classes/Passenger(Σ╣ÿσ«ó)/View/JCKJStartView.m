//
//  JCKJStartView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/21.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJStartView.h"

@interface JCKJStartView ()

/**几星*/
@property (nonatomic ,assign) NSInteger start_Number;

@property (nonatomic ,strong) NSMutableArray *starButtonArrays;

@property (nonatomic ,assign) CGFloat start_W;
@property (nonatomic ,assign) CGFloat start_H;
@property (nonatomic ,assign) CGFloat marge;



@end

@implementation JCKJStartView


-(NSMutableArray *)starButtonArrays{
    
    if (_starButtonArrays == nil) {
        _starButtonArrays = [NSMutableArray array];
    }
    return _starButtonArrays;
    
}
+(instancetype)satrtViewWithStartNumber:(NSInteger)satrtNumber{
    
    JCKJStartView *startView = [[JCKJStartView alloc] init];
    startView.start_H = 31;
    startView.start_W = 31;
    startView.marge = 14;
    startView.start_Number = satrtNumber;
    return startView;
}
+(instancetype)satrtViewWithStartNumber:(NSInteger)satrtNumber start_W:(CGFloat)startW start_H:(CGFloat)start_H marge:(CGFloat)marge{
    
    JCKJStartView *startView = [[JCKJStartView alloc] init];
    startView.start_W = startW;
    startView.start_H = start_H;
    startView.marge = marge;
    startView.start_Number = satrtNumber;
    
    return startView;
    
}

-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        [self setUp];
    }
    
    return self;
    
}
-(void)setUp{
    
    for (NSInteger i = 0 ; i < 5; i ++) {
        UIButton *startButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [startButton setImage:LYQ_IMAGENAME(@"star2") forState:UIControlStateSelected];
        [startButton setImage:LYQ_IMAGENAME(@"star3") forState:UIControlStateNormal];
        startButton.tag = i + 1;
        [startButton addTarget:self action:@selector(satrButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.starButtonArrays addObject:startButton];
        [self addSubview:startButton];
    }
    
    
}
-(void)layoutSubviews{
    [super layoutSubviews];
    
    
    CGFloat starBtn_X = 0;
    CGFloat starBtn_Y = 0;

    
    for (NSInteger i = 0 ; i < self.starButtonArrays.count ; i ++) {
        UIButton *starBtn = self.starButtonArrays[i];
         starBtn_X = i * (self.start_W + self.marge);
        starBtn.frame = CGRectMake(starBtn_X, starBtn_Y, self.start_W, self.start_H);
        
        if (starBtn.tag <= self.start_Number) {
            starBtn.selected = YES;
        }else{
            starBtn.selected = NO;

        }
        
    }
    
}



-(void)setStart_Number:(NSInteger)start_Number{
    _start_Number = start_Number;
    [self.starButtonArrays enumerateObjectsUsingBlock:^(UIButton *button, NSUInteger idx, BOOL * _Nonnull stop) {
        if (start_Number >= button.tag ) {
            button.selected = YES;
        }else{
            button.selected = NO;
        }
    }];
}


-(void)satrButtonClick:(UIButton *)seleButton{
    
    [self.starButtonArrays enumerateObjectsUsingBlock:^(UIButton *button, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if (seleButton.tag >= button.tag ) {
            button.selected = YES;
        }else{
            button.selected = NO;
        }
    }];
}

@end
