//
//  JCKJBorderButton.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJBorderButton.h"

@implementation JCKJBorderButton

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self setUp];

    
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [self setUp];
    }
    return self;
}

-(void)setUp{
    
    
    [self setTitleColor:LYQ_COLOR_WITH_HEX(0x3F3E3E) forState:UIControlStateNormal];
    self.titleLabel.font = LYQ_SYS_FONT(15);
    
    self.layer.cornerRadius = 4.0f;
    self.layer.masksToBounds = YES;
    
    self.layer.borderColor = LYQ_COLOR_WITH_HEX(0x979595).CGColor;
    self.layer.borderWidth = 1.0f;
    
}

-(void)setModel:(JCKJAddressModel *)model{
    _model = model;
    [self setTitle:model.cityName forState:UIControlStateNormal];
}

@end
