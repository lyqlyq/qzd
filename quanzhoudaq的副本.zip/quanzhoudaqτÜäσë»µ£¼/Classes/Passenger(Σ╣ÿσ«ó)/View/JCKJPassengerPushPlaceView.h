//
//  JCKJPassengerPushPlaceView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


/**发布顺风车*/
@interface JCKJPassengerPushPlaceView : UIView

+(instancetype)pushPlaceView;

-(void)show;

-(void)dissmiss;

@end
