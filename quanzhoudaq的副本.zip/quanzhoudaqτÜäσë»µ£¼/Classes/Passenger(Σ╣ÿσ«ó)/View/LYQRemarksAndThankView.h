//
//  LYQRemarksAndThankView.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/27.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef enum : NSUInteger {
    remarkType,
    thankType,
    daiwuRemarkType,
} showType;

typedef void(^surcRemarkClick)(NSMutableArray *seleButtons);


@interface LYQRemarksAndThankView : UIView

@property (nonatomic ,copy) surcRemarkClick remarkSeleBlock;

+(void)showRemarksViewWithSeleButtonsBlock:(surcRemarkClick)seleBolck;

@end
