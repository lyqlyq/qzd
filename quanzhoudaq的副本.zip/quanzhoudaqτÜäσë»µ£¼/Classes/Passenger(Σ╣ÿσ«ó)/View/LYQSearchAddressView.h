//
//  LYQSearchAddressView.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/26.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LYQSearchAddressView;
@class LYQAddressModel;
@protocol LYQSearchAddressViewDelegate <NSObject>


-(void)searchAddressViewDissmiss;

-(void)searchAddressView:(LYQSearchAddressView *)searchView didSelectAddressModel:(LYQAddressModel *)model;


@end

@interface LYQSearchAddressView : UIView

@property (nonatomic ,weak) id <LYQSearchAddressViewDelegate> delegate;

@property (nonatomic ,strong) UIButton *seleButton;

/**是否推荐*/
@property (nonatomic ,assign) BOOL isRecommend;

@property (nonatomic ,strong) NSMutableArray *addressArray;

@property (nonatomic ,strong) NSString *city;

@end
