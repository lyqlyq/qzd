//
//  JCKJBorderButton.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "JCKJAddressModel.h"

@interface JCKJBorderButton : UIButton

@property (nonatomic ,strong) JCKJAddressModel *model;

@end
