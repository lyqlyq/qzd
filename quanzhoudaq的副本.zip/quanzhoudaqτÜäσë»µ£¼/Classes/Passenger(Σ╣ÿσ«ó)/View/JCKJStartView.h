//
//  JCKJStartView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/21.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCKJStartView : UIView


+(instancetype)satrtViewWithStartNumber:(NSInteger)satrtNumber;

+(instancetype)satrtViewWithStartNumber:(NSInteger)satrtNumber start_W:(CGFloat)startW start_H:(CGFloat)start_H marge:(CGFloat)marge;
@end
