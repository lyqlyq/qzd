//
//  LYQRemarksAndThankView.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/27.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQRemarksAndThankView.h"



typedef void(^surcClick)(NSMutableArray *seleButtons);


@interface LYQRemarksAndThankView ()



@property (weak, nonatomic) IBOutlet UIView *allView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *btn1;
@property (weak, nonatomic) IBOutlet UIButton *btn2;
@property (weak, nonatomic) IBOutlet UIButton *btn3;
@property (weak, nonatomic) IBOutlet UIButton *btn4;
@property (weak, nonatomic) IBOutlet UIButton *btn5;


@property (nonatomic ,strong) NSMutableArray *remarkArraysText;

@property (nonatomic ,copy) surcClick clickBlock;


@property (nonatomic ,assign) BOOL isChoseMany;


@property (nonatomic ,strong) NSMutableArray *seleButtonArrays;

#define bottomView_H 255


@end

@implementation LYQRemarksAndThankView


static LYQRemarksAndThankView * _remarkAndThankView = nil;


-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self initWithButton:self.btn1];
    [self initWithButton:self.btn2];
    [self initWithButton:self.btn3];
    [self initWithButton:self.btn4];
    [self initWithButton:self.btn5];
    
    
    
   // self.autoresizingMask = UIViewAutoresizingNone;
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];

}

-(NSMutableArray *)seleButtonArrays{
    if (_seleButtonArrays == nil) {
        _seleButtonArrays = [NSMutableArray array];
    }
    return _seleButtonArrays;
}
+(void)showRemarksViewWithSeleButtonsBlock:(surcRemarkClick)seleBolck{
    
    if (_remarkAndThankView == nil) {
        _remarkAndThankView = [LYQRemarksAndThankView xmg_viewFromXib];
        _remarkAndThankView.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
    }
    _remarkAndThankView.clickBlock = seleBolck;
    _remarkAndThankView.allView.transform = CGAffineTransformMakeTranslation(0, bottomView_H);
    
    [UIView animateWithDuration:0.3 animations:^{
        _remarkAndThankView.allView.transform = CGAffineTransformIdentity;
        _remarkAndThankView.backgroundColor = LYQ_RGB_COLOR_A_Mian;
        
    }];
    
    
    
    [LYQ_KeyWindow addSubview:_remarkAndThankView];

    
    
}

-(void)initWithButton:(UIButton *)btn{
    btn.layer.borderWidth = 1.0f;
    btn.layer.borderColor = LYQ_COLOR_WITH_HEX(0x979595).CGColor;
}

+(void)dissmiss{
    

    [UIView animateWithDuration:0.3 animations:^{
        _remarkAndThankView.allView.transform = CGAffineTransformMakeTranslation(0, bottomView_H);
        _remarkAndThankView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    }completion:^(BOOL finished) {
        [_remarkAndThankView removeFromSuperview];
    }];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [LYQRemarksAndThankView dissmiss];
}



- (IBAction)sureClick:(id)sender {
    [LYQRemarksAndThankView dissmiss];
    
    if (_remarkAndThankView.clickBlock) {
        _remarkAndThankView.clickBlock(self.seleButtonArrays);
    }

    
}
- (IBAction)cancleClick:(id)sender {
    [LYQRemarksAndThankView dissmiss];
}

- (IBAction)remarkButtonClick:(UIButton *)remarkButton {
    remarkButton.selected = !remarkButton.selected;
    
    if (remarkButton.selected) {
        [remarkButton setBackgroundColor:jckj_COLOR_ligthRed];
        remarkButton.layer.borderWidth = 0.0f;
        
        if (![self seleArrayContentWithButton:remarkButton]) {
            [self.seleButtonArrays addObject:remarkButton];
        }
    }else{
        [remarkButton setBackgroundColor:[UIColor whiteColor]];
        remarkButton.layer.borderWidth = 1.0f;
        
        if ([self seleArrayContentWithButton:remarkButton]) {
            [self.seleButtonArrays removeObject:remarkButton];
        }
        
        
    }
}
/**检查是否有选中的Button*/
-(BOOL)seleArrayContentWithButton:(UIButton *)sender{
    
   __block BOOL isconent = NO;
    
    [self.seleButtonArrays enumerateObjectsUsingBlock:^(UIButton *conentButton, NSUInteger idx, BOOL * _Nonnull stop) {
        if (conentButton == sender) {
            isconent = YES;
            *stop = YES;
        }
    }];
    
    return isconent;
}




@end
