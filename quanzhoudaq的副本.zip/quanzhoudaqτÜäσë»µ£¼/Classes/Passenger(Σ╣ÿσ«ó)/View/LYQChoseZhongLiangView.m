//
//  LYQChoseZhongLiangView.m
//  quanzhouda
//
//  Created by pro on 2017/12/8.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQChoseZhongLiangView.h"

@interface LYQChoseZhongLiangView ()<UIPickerViewDelegate,UIPickerViewDataSource>
@property (weak, nonatomic) IBOutlet UIPickerView *pickVIew;
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet UIView *allVIew;

@property (nonatomic ,strong) NSMutableArray *datas;

@end

#define bottom_H 255

@implementation LYQChoseZhongLiangView


-(void)awakeFromNib{
    [super awakeFromNib];
    self.pickVIew.delegate = self;
    self.pickVIew.dataSource = self;
    
}

/**选择座位数*/
-(void)show_ZWX{
    NSMutableArray *userArray = [NSMutableArray array];
    for (NSInteger i = 1 ; i < 7; i ++) {
        [userArray addObject:[NSString stringWithFormat:@"%ld座",i]];
    }
    self.datas = userArray;
    self.bottomView.transform = CGAffineTransformMakeTranslation(0, bottom_H);
    self.titlelable.text = @"座位数";
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.transform = CGAffineTransformIdentity;
        self.allVIew.backgroundColor = LYQ_RGB_COLOR_A_Mian;
    }];
    
    self.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
    [LYQ_KeyWindow addSubview:self];
    
}

/**选择人数*/
-(void)showUserCount{
    
    NSMutableArray *userArray = [NSMutableArray array];
    for (NSInteger i = 1 ; i < 7; i ++) {
        [userArray addObject:[NSString stringWithFormat:@"%ld人",i]];
    }
    self.datas = userArray;
    self.bottomView.transform = CGAffineTransformMakeTranslation(0, bottom_H);
    self.titlelable.text = @"乘车人数";
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.transform = CGAffineTransformIdentity;
        self.allVIew.backgroundColor = LYQ_RGB_COLOR_A_Mian;
    }];
    
    self.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
    [LYQ_KeyWindow addSubview:self];
}


/**选择 乘客上车地点*/
-(void)showPassengerChoseAddressWithAddressArray:(NSMutableArray *)addressArrays{
    
    
    NSMutableArray *userArray = [NSMutableArray array];
    
    [userArray addObject:@"茶店子客运中心"];
    [userArray addObject:@"成都新希望高新皇冠假日酒店对面"];
    [userArray addObject:@"抚琴西北街鑫城府旁"];
    
    self.datas = userArray;
    self.bottomView.transform = CGAffineTransformMakeTranslation(0, bottom_H);
    self.titlelable.text = @"选择上车点";
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.transform = CGAffineTransformIdentity;
        self.allVIew.backgroundColor = LYQ_RGB_COLOR_A_Mian;
    }];
    
    self.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H);
    [LYQ_KeyWindow addSubview:self];
    
}

-(void)dissmissWithCompletion:(void(^)())completion{
    
    [UIView animateWithDuration:0.3 animations:^{
        self.bottomView.transform =  CGAffineTransformMakeTranslation(0,  bottom_H);
        self.allVIew.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.0];
    }completion:^(BOOL finished) {
        [self removeFromSuperview];
        if (completion) {
            completion();
        }
        
    }];
    
    
}
// 多少列
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
  
    return 1;
}
//  多少行
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    
    return self.datas.count;
    
}
//  第component列第row行显示什么文字
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    return self.datas[row];
    
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
}
-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 50.0f;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel* pickerLabel = (UILabel*)view;
    if (!pickerLabel){
        pickerLabel = [[UILabel alloc] init];
        pickerLabel.adjustsFontSizeToFitWidth = YES;
        pickerLabel.xmg_height = 50;
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        [pickerLabel setFont:LYQ_SYS_FONT(16)];
    }
    // Fill the label text here
    pickerLabel.text=[self pickerView:pickerView titleForRow:row forComponent:component];
    return pickerLabel;
}




-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self dissmissWithCompletion:nil];
}


- (IBAction)sureClick:(UIButton *)sender {
    
    NSInteger row =  [self.pickVIew selectedRowInComponent:0];
    NSString * seleZhong =  self.datas[row];
    if (self.choseZhongBlock) {
        self.choseZhongBlock(seleZhong);
    }
    
    
}
- (IBAction)cancleClick:(UIButton *)sender {
    [self dissmissWithCompletion:nil];
}

@end
