
//
//  LYQSearchAddressView.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/26.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQSearchAddressView.h"
#import <AMapLocationKit/AMapLocationKit.h>
#import <AMapSearchKit/AMapSearchKit.h>

#import "LYQAddressModel.h"
#import "LYQAddressCell.h"
#import "LYQAddressSaveTool.h"

@interface LYQSearchAddressView ()<UITableViewDelegate,UITableViewDataSource,AMapSearchDelegate>


@property (weak, nonatomic) IBOutlet UITextField *AddressTextF;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic ,strong) AMapSearchAPI *search;

@property (nonatomic ,strong) AMapInputTipsSearchRequest *tipsRequest;

@property (nonatomic ,strong) AMapLocationManager *locationManager;

@property (nonatomic ,strong) NSMutableArray *addressModels;

@property (nonatomic ,strong) UILabel *historyLabel;


@end


@implementation LYQSearchAddressView


-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.autoresizingMask = UIViewAutoresizingNone;
 
    self.search = [[AMapSearchAPI alloc] init];
    self.search.delegate = self;
    self.tipsRequest = [[AMapInputTipsSearchRequest alloc] init];
    self.tipsRequest.cityLimit = YES;

    self.tipsRequest.city = @"成都";
    
  
    self.tableView.separatorColor = [UIColor clearColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.AddressTextF addTarget:self action:@selector(AddressTextFChange:) forControlEvents:UIControlEventEditingChanged];
    
    
    UILabel *La  = [[ UILabel alloc] init];
    La.frame = CGRectMake(0, 0, LYQ_SCREEN_H, 40);
    La.textAlignment = NSTextAlignmentCenter;
    La.text = @"历史搜索记录";
    La.font = LYQ_SYS_FONT(14);
    La.textColor = LYQ_COLOR_WITH_HEX(0xaaaaaa);
    self.tableView.tableFooterView  = La;;
    _historyLabel = La;
    
    
    
}


-(void)setIsRecommend:(BOOL)isRecommend{
    
    _isRecommend = isRecommend;
    if (isRecommend) {
        self.historyLabel.hidden = YES;
        self.addressModels = self.addressArray;
    }else{
        self.historyLabel.hidden = NO;

        self.addressModels = [LYQAddressSaveTool getAddressModels];
    }
    
    [self.tableView reloadData];
}


-(void)AddressTextFChange:(UITextField *)textF{
    self.tipsRequest.keywords = self.AddressTextF.text;
    [self.search AMapInputTipsSearch: self.tipsRequest];
    
}

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.addressModels.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LYQAddressCell *cell = [LYQAddressCell addressCellWithTab:tableView];
    cell.model = self.addressModels[indexPath.row];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LYQAddressModel *model = self.addressModels[indexPath.row];
      if (!self.isRecommend) {
          [LYQAddressSaveTool saveAddress:model];
    }

    if ([self.delegate respondsToSelector:@selector(searchAddressView:didSelectAddressModel:)]) {
        [self.delegate searchAddressView:self didSelectAddressModel:model];        
    }
    
}




#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 76.0f;
}

-(void)onInputTipsSearchDone:(AMapInputTipsSearchRequest *)request response:(AMapInputTipsSearchResponse *)response{
    
    
    self.addressModels = [LYQAddressModel mj_objectArrayWithKeyValuesArray:response.tips context:nil];
    
    [self.addressModels enumerateObjectsUsingBlock:^(LYQAddressModel *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        if (obj.location == nil) {
            [self.addressModels removeObject:obj];
        }
        
    }];
    
    
    if (self.addressModels.count > 0) {
        self.historyLabel.hidden = YES;
    }else{
        self.addressModels  = [LYQAddressSaveTool getAddressModels];
        self.historyLabel.hidden = NO;
    }
    [self.tableView reloadData];


    
}

-(void)setCity:(NSString *)city{
    _city = city;
    self.tipsRequest.city = city;
    
}
- (IBAction)cancleClick:(UIButton *)sender {
 
    if ([self.delegate respondsToSelector:@selector(searchAddressViewDissmiss)]) {
        [self.delegate searchAddressViewDissmiss];
    }

}



@end
