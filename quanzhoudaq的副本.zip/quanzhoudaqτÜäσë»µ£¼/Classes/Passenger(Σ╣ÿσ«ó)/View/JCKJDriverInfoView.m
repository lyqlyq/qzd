//
//  JCKJDriverInfoView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/26.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDriverInfoView.h"
#import "JCKJStartView.h"
#import "JCKJDriverInfoModel.h"
#import <UIButton+SGImagePosition.h>

#import <UIImageView+WebCache.h>

@interface JCKJDriverInfoView()

@property (nonatomic ,strong) UIImageView *image_Header;

@property (nonatomic ,strong) UILabel *nickNameLabel;

@property (nonatomic ,strong) UIImageView *sexImageV;

@property (nonatomic ,strong) JCKJStartView *startView;

@property (nonatomic ,strong) UIButton  *call_button;

@property (nonatomic ,strong) UILabel *carModelLabel;

@end

@implementation JCKJDriverInfoView


+(instancetype)driverInfoView{
    
    JCKJDriverInfoView *driverView = [[JCKJDriverInfoView alloc] init];
    driverView.backgroundColor = [UIColor whiteColor];
    return driverView;
}

-(instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.image_Header = [[UIImageView alloc] init];
        self.nickNameLabel= [[UILabel alloc] init];
        self.startView = [JCKJStartView satrtViewWithStartNumber:5 start_W:14 start_H:14 marge:4];
        self.startView.userInteractionEnabled = NO;
        self.call_button = [UIButton buttonWithType:UIButtonTypeCustom];
        self.carModelLabel = [[UILabel alloc] init];
        self.sexImageV = [[UIImageView alloc] init];
        
        self.nickNameLabel.font = LYQ_SYS_FONT(14);
        self.nickNameLabel.textColor = jckj_label_Text_Color;
        
        self.sexImageV.image = LYQ_IMAGENAME(@"woman");
        self.carModelLabel.font = LYQ_SYS_FONT(13);
       
        [self.call_button setTitle:@"联系电话" forState:UIControlStateNormal];
        [self.call_button setImage:LYQ_IMAGENAME(@"phone_red") forState:UIControlStateNormal];
        [self.call_button setTitleColor:jckj_COLOR_ligthRed forState:UIControlStateNormal];
        self.call_button.titleLabel.font = LYQ_SYS_FONT(14);
        
        [self.call_button setImageEdgeInsets:UIEdgeInsetsMake(0, 100, 0, 0)];
      
        [self.call_button addTarget:self action:@selector(call) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:self.image_Header];
        [self addSubview:self.nickNameLabel];
        [self addSubview:self.sexImageV];
        [self addSubview:self.startView];
        [self addSubview:self.call_button];
        [self addSubview:self.carModelLabel];
        
        self.carModelLabel.text = @"川AT65W0 白色 大众速腾";
        self.nickNameLabel.text = @"张女士";
        
        
    }
    return self;
}


-(void)setModel:(JCKJDriverInfoModel *)model{
    _model = model;
    
    self.carModelLabel.text = [NSString stringWithFormat:@"%@ %@ %@",model.carunm,model.color,model.brand];
    
    self.nickNameLabel.text = model.name;

    [self.image_Header sd_setImageWithURL:[NSURL URLWithString:model.head] placeholderImage:LYQ_IMAGENAME_Header];
    
    
    
}

-(void)call{
    
    LYQCall_phone(self.model.phone);
    
}

-(void)layoutSubviews{
    [super layoutSubviews];
    
    CGFloat imageHeader_X  = 15 ;
    CGFloat imageHeader_Y  = 20 ;
    CGFloat imageHeader_W  = 52 ;
    CGFloat imageHeader_H  = 52 ;

    
    self.image_Header.frame = CGRectMake(imageHeader_X, imageHeader_Y, imageHeader_W, imageHeader_H);
    
    CGFloat nickNameLabel_X = CGRectGetMaxX(self.image_Header.frame) + 15 ;
    CGFloat nickNameLabel_Y = 20 ;
    CGFloat nickNameLabel_W = 50 ;
    CGFloat nickNameLabel_H = 14 ;
    
    
    self.nickNameLabel.frame = CGRectMake(nickNameLabel_X, nickNameLabel_Y, nickNameLabel_W, nickNameLabel_H);
    
    
    
    CGFloat sexImageV_X = CGRectGetMaxX(self.nickNameLabel.frame) + 10;
    CGFloat sexImageV_Y = 21;
    CGFloat sexImageV_W = 12;
    CGFloat sexImageV_H = 12;
    
    
    self.sexImageV.frame = CGRectMake(sexImageV_X, sexImageV_Y, sexImageV_W, sexImageV_H);
    
 
    CGFloat startView_X = nickNameLabel_X;
    CGFloat startView_Y = CGRectGetMaxY(self.nickNameLabel.frame) + 15;
    CGFloat startView_W = 100;
    CGFloat startView_H = 14;

    
    self.startView.frame = CGRectMake(startView_X, startView_Y, startView_W, startView_H);
    
    CGFloat carModelLabel_X = nickNameLabel_X;
    CGFloat carModelLabel_Y = CGRectGetMaxY(self.startView.frame) + 15;
    CGFloat carModelLabel_W = 200;
    CGFloat carModelLabel_H = 15;

    self.carModelLabel.frame = CGRectMake(carModelLabel_X, carModelLabel_Y, carModelLabel_W, carModelLabel_H);
    
    
    CGFloat callButton_Y = 46;
    CGFloat callButton_W = 120;
    CGFloat callButton_X = self.xmg_width - 15 - callButton_W;
    CGFloat callButton_H = 20;
    
    self.call_button.frame = CGRectMake(callButton_X, callButton_Y, callButton_W, callButton_H);

}


@end
