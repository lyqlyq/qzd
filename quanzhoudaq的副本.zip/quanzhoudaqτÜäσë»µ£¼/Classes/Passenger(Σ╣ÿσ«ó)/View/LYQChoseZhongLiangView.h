//
//  LYQChoseZhongLiangView.h
//  quanzhouda
//
//  Created by pro on 2017/12/8.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^zhongBlock)(NSString * choseStr);
@interface LYQChoseZhongLiangView : UIView

@property (nonatomic ,copy) zhongBlock choseZhongBlock;
@property (weak, nonatomic) IBOutlet UILabel *titlelable;


/**选择座位数*/
-(void)show_ZWX;

/**选择 人数*/
-(void)showUserCount;

/**选择 乘客上车地点*/
-(void)showPassengerChoseAddressWithAddressArray:(NSMutableArray *)addressArrays;

-(void)dissmissWithCompletion:(void(^)())completion;
@end
