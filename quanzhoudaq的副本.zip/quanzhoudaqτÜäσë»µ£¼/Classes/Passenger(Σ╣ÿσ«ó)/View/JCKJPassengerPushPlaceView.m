//
//  JCKJPassengerPushPlaceView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPassengerPushPlaceView.h"

#import "NSString+JCKJAttString.h"


@interface JCKJPassengerPushPlaceView ()
@property (weak, nonatomic) IBOutlet UIView *botttomView;
@property (weak, nonatomic) IBOutlet UILabel *sfcLable;

@property (weak, nonatomic) IBOutlet UILabel *xcfyLabel;
@property (weak, nonatomic) IBOutlet UIButton *sfcButton;

@property (weak, nonatomic) IBOutlet UILabel *yxLabel;
@property (weak, nonatomic) IBOutlet UIButton *yxButton;
@property (weak, nonatomic) IBOutlet UILabel *yxxcfyLabel;


@property (nonatomic ,strong) UIButton *seleButton;
@property (weak, nonatomic) IBOutlet UIButton *sfAllBtn;
@property (weak, nonatomic) IBOutlet UIButton *yxAllBtn;

@end


#define bottomView_H 150

@implementation JCKJPassengerPushPlaceView

-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.botttomView.transform = CGAffineTransformMakeTranslation(0,bottomView_H);
    
    NSString *allTextMoney = @"23 元";
    NSString *attText = @"23";
    
    NSMutableAttributedString *seleText = [NSString getAllText:allTextMoney attText:attText attCorlo:nil attFont:LYQ_SYS_FONT(20) allTextColor:jckj_COLOR_ligthRed];
 
    NSMutableAttributedString *noText = [NSString getAllText:allTextMoney attText:attText attCorlo:nil attFont:LYQ_SYS_FONT(20) allTextColor:LYQ_COLOR_WITH_HEX(0x979595)];
    
    [self.sfcButton setAttributedTitle:seleText forState:UIControlStateSelected];
    [self.sfcButton setAttributedTitle:noText forState:UIControlStateNormal];
    
    
    [self.yxButton setAttributedTitle:seleText forState:UIControlStateSelected];
    [self.yxButton setAttributedTitle:noText forState:UIControlStateNormal];
    
 

    

}

+(instancetype)pushPlaceView{
    JCKJPassengerPushPlaceView *ppplaceView = [JCKJPassengerPushPlaceView xmg_viewFromXib];
    return ppplaceView;
}


-(void)show{
    
    self.frame =LYQ_KeyWindow.bounds;
    
    [LYQ_KeyWindow addSubview:self];
    
    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundColor = LYQ_RGB_COLOR_A_Mian;
        self.botttomView.transform = CGAffineTransformIdentity;
    }];
    
}

-(void)dissmiss{
    
    [UIView animateWithDuration:0.3 animations:^{
        self.botttomView.transform = CGAffineTransformMakeTranslation(0, bottomView_H);
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    }completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self dissmiss];
}
- (IBAction)sfcButton:(UIButton *)sender {
    self.sfAllBtn.selected = YES;
    self.yxAllBtn.selected = NO;
    
    [self changeStateButton];
}


- (IBAction)yxButton:(UIButton *)sender {
    self.sfAllBtn.selected = NO;
    self.yxAllBtn.selected = YES;
    [self changeStateButton];

}

-(void)changeStateButton{
    
    if (self.sfAllBtn.selected) {
        self.sfcLable.textColor = jckj_label_Text_Color;
        self.xcfyLabel.textColor = LYQ_COLOR_WITH_HEX(0x979595);
        self.sfcButton.selected = YES;
    }else{
        self.sfcLable.textColor = LYQ_COLOR_WITH_HEX(0x979595);
        self.xcfyLabel.textColor = LYQ_COLOR_WITH_HEX(0xD7D2D2);
        self.sfcButton.selected = NO;

    }
    
    if (self.yxAllBtn.selected) {
        self.yxLabel.textColor = jckj_label_Text_Color;
        self.yxxcfyLabel.textColor = LYQ_COLOR_WITH_HEX(0x979595);
        self.yxButton.selected = YES;
    }else{
        self.yxLabel.textColor = LYQ_COLOR_WITH_HEX(0x979595);
       self.yxxcfyLabel.textColor = LYQ_COLOR_WITH_HEX(0xD7D2D2);
        self.yxButton.selected = NO;
    }
}

@end
