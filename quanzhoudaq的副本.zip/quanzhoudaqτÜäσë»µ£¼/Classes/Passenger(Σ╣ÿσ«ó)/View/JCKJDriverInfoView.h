//
//  JCKJDriverInfoView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/26.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


@class JCKJDriverInfoModel;

@interface JCKJDriverInfoView : UIView

@property (nonatomic ,strong) JCKJDriverInfoModel *model;

+(instancetype)driverInfoView;
@end
