//
//  JCKJPassengerPlaceCell.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/29.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPassengerPlaceCell.h"

@interface JCKJPassengerPlaceCell()
@property (weak, nonatomic) IBOutlet UIButton *dh_Button;
@property (weak, nonatomic) IBOutlet UIButton *qrsc_Button;

@end

@implementation JCKJPassengerPlaceCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    [self.dh_Button cornerWithRadiusSize:4];
    [self.qrsc_Button cornerWithRadiusSize:4];
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
+(instancetype)passengerPlaceCellWithTableView:(UITableView *)tableView{
    
    JCKJPassengerPlaceCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class])];
    
    if (cell == nil) {
        cell = [JCKJPassengerPlaceCell xmg_viewFromXib];
    }
    
    return cell;
    
    
}
@end
