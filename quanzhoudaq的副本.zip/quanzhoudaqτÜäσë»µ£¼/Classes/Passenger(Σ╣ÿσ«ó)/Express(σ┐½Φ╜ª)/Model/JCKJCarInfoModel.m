

//
//  JCKJCarInfoModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJCarInfoModel.h"

@implementation JCKJCarInfoModel


-(CGFloat)latitude{
    
    if (_latitude > 0) {
        return _latitude;
    }
    
    NSArray *lolaArray =  [_coordinate componentsSeparatedByString:@","];
    return [[lolaArray lastObject] doubleValue];
    
    
}

-(CGFloat)longitude{
    
    if (_longitude > 0) {
        return _longitude;
    }
    
    NSArray *lolaArray =  [_coordinate componentsSeparatedByString:@","];
    return [[lolaArray firstObject] doubleValue];
}

@end
