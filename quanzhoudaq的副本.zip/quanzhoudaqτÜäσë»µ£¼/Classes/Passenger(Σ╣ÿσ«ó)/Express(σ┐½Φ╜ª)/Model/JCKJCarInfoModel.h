//
//  JCKJCarInfoModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/3.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJCarInfoModel : NSObject

@property (nonatomic ,copy) NSString *area;
@property (nonatomic ,copy) NSString *coordinate;
@property (nonatomic ,copy) NSString *created_at;
@property (nonatomic ,copy) NSString *defaultarea;
@property (nonatomic ,copy) NSString *direction;
@property (nonatomic ,copy) NSString *id;
@property (nonatomic ,copy) NSString *isdel;
@property (nonatomic ,copy) NSString *liningtime;
@property (nonatomic ,copy) NSString *logintime;
@property (nonatomic ,copy) NSString *refreshtime;
@property (nonatomic ,copy) NSString *speed;
@property (nonatomic ,copy) NSString *status;
@property (nonatomic ,copy) NSString *updated_at;
@property (nonatomic ,copy) NSString *userid;

@property (nonatomic ,assign) CGFloat latitude;
@property (nonatomic ,assign) CGFloat longitude;



@end
