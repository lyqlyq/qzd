//
//  JCKJDriverCarInfoModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJDriverCarInfoModel : NSObject

@property (nonatomic ,copy) NSString *coordinate;
@property (nonatomic ,copy) NSString *direction;
@property (nonatomic ,copy) NSString *speed;


@end
