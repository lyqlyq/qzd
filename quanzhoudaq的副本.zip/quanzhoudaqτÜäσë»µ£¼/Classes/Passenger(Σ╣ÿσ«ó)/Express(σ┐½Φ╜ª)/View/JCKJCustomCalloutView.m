//
//  JCKJCustomCalloutView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/22.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJCustomCalloutView.h"

@interface JCKJCustomCalloutView ()
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@property (nonatomic ,strong) NSTimer *timer;

@property (nonatomic ,assign) NSInteger send;
@property (nonatomic ,assign) NSInteger mind;



@end

@implementation JCKJCustomCalloutView

+(instancetype)customCalloutView{
    
    JCKJCustomCalloutView *cuView = [JCKJCustomCalloutView xmg_viewFromXib];
    [cuView cornerWithRadiusSize:4];
    return cuView;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    self.send = 0;
    self.mind = 0;
    self.timer = [NSTimer timerWithTimeInterval:1 target:self selector:@selector(test) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    [self.timer fire];
    
    
}
-(void)test{
    
    self.send ++;
    if (self.send == 60) {
        self.send = 0;
        self.mind ++;
    }
    self.timeLabel.text = [NSString stringWithFormat:@"%02ld:%02ld",self.mind,self.send];
    
}

-(void)stopTimer{
    [self.timer invalidate];
    self.timer = nil;
}

-(void)dealloc{
    [self.timer invalidate];
    self.timer = nil;
}

@end
