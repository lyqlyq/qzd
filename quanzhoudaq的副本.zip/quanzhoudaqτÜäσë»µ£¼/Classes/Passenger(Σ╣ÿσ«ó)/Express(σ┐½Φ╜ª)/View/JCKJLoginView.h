//
//  JCKJLoginView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/24.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    forGetPassWordType,
    codeType,
    loginType,
} loginViewType;


typedef enum : NSUInteger {
    amianType_center,
    amianType_left
} amian_type;

@interface JCKJLoginView : UIView


@property (nonatomic ,assign) loginViewType type;
@property (nonatomic ,assign) amian_type amianType;
+(instancetype)loginViewWityType:(loginViewType)type;

-(void)show;

@end
