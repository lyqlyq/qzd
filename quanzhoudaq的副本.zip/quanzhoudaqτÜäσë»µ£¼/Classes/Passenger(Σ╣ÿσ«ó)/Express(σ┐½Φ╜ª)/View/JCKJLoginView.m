//
//  JCKJLoginView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/24.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJLoginView.h"
#import "NSString+LYQCheckStr.h"
#import "LYQRequestTool.h"
#import "LYQLoginAndRegistBaseParam.h"
#import "LYQLoginRequestTool.h"

#import <SGEasyButton.h>
#import <IQKeyboardManager.h>

@interface JCKJLoginView ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIView *allView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIView *codeView;
@property (weak, nonatomic) IBOutlet UIView *passwordView;
@property (nonatomic ,strong) LYQLoginAndRegistBaseParam *param;

@property (weak, nonatomic) IBOutlet UIButton *timeButton;


/**电话号码*/
@property (weak, nonatomic) IBOutlet UITextField *phoneText;

/**下一步*/
@property (weak, nonatomic) IBOutlet UIButton *nextButton;

@property (weak, nonatomic) IBOutlet UITextField *codeOneTextF;

@property (weak, nonatomic) IBOutlet UITextField *codeTwoTextF;
@property (weak, nonatomic) IBOutlet UITextField *codeThereTextF;
@property (weak, nonatomic) IBOutlet UITextField *codeForuTextF;
@property (weak, nonatomic) IBOutlet UILabel *codeTitlePhone;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextF;
@property (weak, nonatomic) IBOutlet UIButton *compButton;
@property (weak, nonatomic) IBOutlet UILabel *passWordTitleLabel;

@end

#define getCode 201

@implementation JCKJLoginView

-(LYQLoginAndRegistBaseParam *)param{
    if (_param == nil) {
        _param = [LYQLoginAndRegistBaseParam param];
    }
    return _param;
}

-(void)awakeFromNib{
    [super awakeFromNib];

    
    self.phoneText.delegate = self;
    self.nextButton.userInteractionEnabled = NO;
    self.compButton.userInteractionEnabled = NO;
    self.phoneText.tintColor = [UIColor blueColor];
    
    self.codeOneTextF.layer.borderWidth = 1;
    self.codeOneTextF.layer.borderColor = LYQ_COLOR_WITH_HEX(0x979595).CGColor;
    self.codeTwoTextF.layer.borderWidth = 1;
    self.codeTwoTextF.layer.borderColor = LYQ_COLOR_WITH_HEX(0x979595).CGColor;
    self.codeThereTextF.layer.borderWidth = 1;
    self.codeThereTextF.layer.borderColor = LYQ_COLOR_WITH_HEX(0x979595).CGColor;
    self.codeForuTextF.layer.borderWidth = 1;
    self.codeForuTextF.layer.borderColor = LYQ_COLOR_WITH_HEX(0x979595).CGColor;
    
    self.codeOneTextF.delegate = self;
    self.codeTwoTextF.delegate = self;
    self.codeThereTextF.delegate = self;
    self.codeForuTextF.delegate = self;
    
    self.codeOneTextF.tintColor = [UIColor blueColor];
    self.codeTwoTextF.tintColor = [UIColor blueColor];
    self.codeThereTextF.tintColor = [UIColor blueColor];
    self.codeForuTextF.tintColor = [UIColor blueColor];
    
    self.passwordTextF.tintColor = [UIColor blueColor];
    

    
    self.passWordTitleLabel.userInteractionEnabled = NO;
    self.passwordTextF.delegate = self;
    
    [self.passwordTextF addTarget:self action:@selector(textFieldTextChange) forControlEvents:UIControlEventEditingChanged];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(passWordTitleLabelClick)];
    
    
    
    [self.passWordTitleLabel addGestureRecognizer:tap];
    
    
    UITapGestureRecognizer *t = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(allviewClick)];
    
    self.allView.userInteractionEnabled = YES;
    [self.allView addGestureRecognizer:t];


    
}
-(void)allviewClick{
    
}
-(void)textFieldTextChange{
    
    if (self.passwordTextF.text.length >= 6) {
        [self buttton:self.compButton withUserInteractionEnabled:YES];
    }else{
        [self buttton:self.compButton withUserInteractionEnabled:NO];
        
    }

    
}

-(void)buttton:(UIButton *)button withUserInteractionEnabled:(BOOL)enable{
    
    if (enable == YES) {
        [button setTitleColor:LYQ_COLOR_WITH_HEX(0xE8724E) forState:UIControlStateNormal];
    }else{
        [button setTitleColor:LYQ_COLOR_WITH_HEX(0x979595) forState:UIControlStateNormal];
    }
    button.userInteractionEnabled = enable;
    
}

+(instancetype)loginViewWityType:(loginViewType)type{
    JCKJLoginView *loginView = [JCKJLoginView xmg_viewFromXib];
    loginView.type = type;
    return loginView;
}

-(void)startTextMgr{
    
}

-(void)setType:(loginViewType)type{
    _type = type;
    
    if (type == loginType) {
        
        self.titleLabel.text = @"登录/注册";
        
        self.passwordView.hidden = YES;
        self.codeView.hidden = YES;
    }
    
    if (type == codeType) {
        self.passwordView.hidden = YES;
        self.codeView.hidden = NO;
        self.titleLabel.text = @"短信验证码";
    }
    
    if (type == forGetPassWordType) {
        self.passwordView.hidden  =NO;
        self.codeView.hidden = YES;
        self.titleLabel.text = @"密码";

    }
    
    
    
}


-(void)show{
    
    [LYQ_KeyWindow addSubview:self];
    [self showAimain];
    
}

-(void)showAimain{
    
    [UIView animateWithDuration:0.3
                     animations:^{
                         // 第二步： 以动画的形式将view慢慢放大至原始大小的1.2倍
                         self.allView.transform =
                         CGAffineTransformScale(CGAffineTransformIdentity, 1.2, 1.2);
                         self.backgroundColor = LYQ_RGB_COLOR_A_Mian;
                         
                     }
                     completion:^(BOOL finished) {
                         [UIView animateWithDuration:0.2
                                          animations:^{
                                              // 第三步： 以动画的形式将view恢复至原始大小
                                              self.allView.transform = CGAffineTransformIdentity;
                                          }];
                     }];
    
    
}


-(void)dissmiss{
    
  
    
    [self closeAnimated];
    
    
}

- (void)closeAnimated{
    
    [UIView animateWithDuration:0.2
                     animations:^{
                         // 第一步： 以动画的形式将view慢慢放大至原始大小的1.2倍
                         self.allView.transform =
                         CGAffineTransformScale(CGAffineTransformIdentity, 1.2, 1.2);
                     }
                     completion:^(BOOL finished) {
                         [UIView animateWithDuration:0.3
                                          animations:^{
                                              // 第二步： 以动画的形式将view缩小至原来的1/1000分之1倍
                                              self.allView.transform = CGAffineTransformScale(
                                                                                              CGAffineTransformIdentity, 0.001, 0.001);
                                              self.backgroundColor = LYQ_RGB_COLOR_A(0, 0, 0, 0);
                                              
                                          }
                                          completion:^(BOOL finished) {
                                              // 第三步： 移除
                                              [self removeFromSuperview];
                                          }];
                     }];
    
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    
    NSInteger maxLength = 100;//设置限制字数
    
 
    if (self.type == loginType) {
        maxLength = 11;
    }
    if (self.type == codeType) {
        maxLength = 1;
      
    }
    if (self.type == forGetPassWordType) {
        maxLength = 16;
       
    }
    
    
    
   
    NSString * toBeString = [textField.text stringByReplacingCharactersInRange:range withString:string];
  
    if (toBeString.length >= maxLength && range.length!=1){
        textField.text = [toBeString substringToIndex:maxLength];
       
        if (self.type == loginType) {
               [self buttton:self.nextButton withUserInteractionEnabled:YES];
        }
        
        if (self.type == codeType) {
            if (textField == self.codeOneTextF) {
                [self.codeTwoTextF becomeFirstResponder];
            }
            if (textField == self.codeTwoTextF) {
                [self.codeThereTextF becomeFirstResponder];
            }
            if (textField == self.codeThereTextF) {
                [self.codeForuTextF becomeFirstResponder];
            }
            if (textField == self.codeForuTextF) {
                [self.codeForuTextF endEditing:YES];
                [self yzCode];
                
            }
            
        }
        
        return NO;
    }else{
        
        if (self.type == loginType) {
           [self buttton:self.nextButton withUserInteractionEnabled:NO];
            
        }
        return YES;
        
    }
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self dissmiss];
}
- (IBAction)cancle:(id)sender {
    
    [self dissmiss];
    
}
- (IBAction)nextButtonClick:(UIButton *)sender {
    
    if (![NSString checkMobileNumber:self.phoneText.text]) {
        LYQ_SHOW_INFO(@"手机号码错误");
        return;
    }

    self.param.phone = self.phoneText.text;
    [LYQLoginRequestTool POSTSearchPhone:self.param success:^(LYQLoginAndRegistBaseModel *model) {

        if (model.msg == getCode) {

            [self showLeftWithType:codeType];

        }else{
            self.passWordTitleLabel.text = @"忘记密码";
            self.passWordTitleLabel.userInteractionEnabled = YES;
            [self showLeftWithType:forGetPassWordType];
        }


    } failure:^(NSError *error) {

    }];
 
}

-(void)showLeftWithType:(loginViewType)type{
    CGRect allViewFrame = self.allView.frame;
    self.type = type;
    [UIView animateWithDuration:0.2 animations:^{
        self.allView.xmg_x = - LYQ_SCREEN_W;
    }completion:^(BOOL finished) {
        self.allView.xmg_x = LYQ_SCREEN_W;
        [UIView animateWithDuration:0.2 animations:^{
            self.allView.frame = allViewFrame;
        }completion:^(BOOL finished) {
            
            if (self.type == codeType) {
                self.codeTitlePhone.text = [NSString stringWithFormat:@"验证码已发送%@",self.param.phone];
                [self getCoded];
            }
            
            if (self.type == loginType) {
                [self.passwordTextF becomeFirstResponder];
            }
            
        }];
        
    }];
}

-(void)yzCode{
    
    self.param.code = [NSString stringWithFormat:@"%@%@%@%@",self.codeOneTextF.text,self.codeTwoTextF.text,self.codeThereTextF.text,self.codeForuTextF.text];

    [LYQLoginRequestTool POSTYZCodeParam:self.param success:^(LYQLoginAndRegistBaseModel *model) {

        if (model.msg == getCode) {
            [self showLeftWithType:forGetPassWordType];
        }else{


        }

    } failure:^(NSError *error) {

    }];
}

/**获取验证码*/
-(void)getCoded{
    
    self.param.phone = self.phoneText.text;
    [LYQLoginRequestTool POSTCodeParam:self.param success:^(LYQLoginAndRegistBaseModel *model) {

        [self.timeButton SG_countdownWithSec:60 completion:^{
            self.timeButton.selected = YES;
            self.timeButton.userInteractionEnabled = YES;
        }];

        [self.codeOneTextF becomeFirstResponder];


    } failure:^(NSError *error) {

    }];
}

- (IBAction)timeClick:(UIButton *)sender {
    sender.userInteractionEnabled = NO;
    sender.selected = NO;
    
    [self getCoded];
    
}
/**完成*/
- (IBAction)compCLick:(UIButton *)sender {
    
    self.param.password = self.passwordTextF.text;


    if ([self.passWordTitleLabel.text isEqualToString:@"忘记密码"]) {
        
        [LYQLoginRequestTool POSTLoginParam:self.param success:^(LYQLoginAndRegistBaseModel *model) {
            
            if (model.token.length > 0) {
                [[NSUserDefaults standardUserDefaults] setObject:model.token forKey:lyq_Token];
            }else{
                LYQ_SHOW_INFO(@"token为空");
            }
            [self dissmiss];

        } failure:^(NSError *error) {
            
        }];
        
        
    }else{
        
        [LYQLoginRequestTool POSTFastreGisterParam:self.param success:^(LYQLoginAndRegistBaseModel *model) {
            
            if (model.token.length > 0) {
                [[NSUserDefaults standardUserDefaults] setObject:model.token forKey:lyq_Token];
            }else{
                LYQ_SHOW_INFO(@"token为空");
            }
            
            
            [self dissmiss];
            
        } failure:^(NSError *error) {
            
        }];
    }
    
    
}

/**忘记密码*/
-(void)passWordTitleLabelClick{
    self.passWordTitleLabel.text = @"新密码";
    self.passWordTitleLabel.userInteractionEnabled = NO;
    [self showLeftWithType:forGetPassWordType];
    
}

@end
