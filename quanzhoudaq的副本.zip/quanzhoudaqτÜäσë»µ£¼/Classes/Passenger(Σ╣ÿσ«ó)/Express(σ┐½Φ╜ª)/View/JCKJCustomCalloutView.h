//
//  JCKJCustomCalloutView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/22.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCKJCustomCalloutView : UIView

+(instancetype)customCalloutView;

-(void)stopTimer;

@end
