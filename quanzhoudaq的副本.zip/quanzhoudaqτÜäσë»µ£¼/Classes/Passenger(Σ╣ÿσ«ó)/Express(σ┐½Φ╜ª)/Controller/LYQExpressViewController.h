//
//  LYQExpressViewController.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/6.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJMapBaseViewController.h"
#import "LYQAddressModel.h"
@class JCKJDriverCarInfoModel;
@interface LYQExpressViewController : JCKJMapBaseViewController


@property (nonatomic ,strong) LYQAddressModel *startModel;
@property (nonatomic ,strong) LYQAddressModel *endModel;

@property (nonatomic ,assign) CGRect mapViewRect;

@property (nonatomic ,copy) void(^fujiaoClickBlock)();

@property (nonatomic ,copy) void(^getCarsModelsSuccessBlock)(NSMutableArray <JCKJDriverCarInfoModel *> *carModels);


@end
