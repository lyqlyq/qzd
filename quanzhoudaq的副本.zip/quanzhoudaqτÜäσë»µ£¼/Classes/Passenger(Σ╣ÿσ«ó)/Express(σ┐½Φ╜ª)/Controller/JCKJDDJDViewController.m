//
//  JCKJDDJDViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/21.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJDDJDViewController.h"
#import "JCKJCanclePlaceDoneController.h"
#import "LYQCancleBarButton.h"
#import "LYQAlertView.h"
#import "LYQPromptTool.h"

#import "LYQAddressModel.h"
#import "LYQLocaModel.h"

#import "CommonUtility.h"
#import "MANaviRoute.h"

#import "JCKJCustomCalloutView.h"
#import "JCKJDriverInfoView.h"

#import "JCKJExpressRequestTool.h"
#import "JCKJExpressParam.h"

#import "JCKJExpressOrderModel.h"
#import "JCKJCarInfoModel.h"

@interface JCKJDDJDViewController ()

{
//    CLLocationCoordinate2D coordin[1000000];
    CLLocationCoordinate2D coordinSTART[2];

}



@property (nonatomic ,strong) MACustomCalloutView *customCallView;
@property (nonatomic ,strong) JCKJCustomCalloutView *jckjView;

@property (nonatomic ,strong) JCKJDriverInfoView *infoView;

@property (nonatomic ,strong) NSTimer *timer1;
@property (nonatomic ,strong) NSTimer *timer2;


/**车主是否接单*/
@property (nonatomic ,assign) BOOL isJieDan;

@property (nonatomic ,strong) MAPointAnnotation *startAnnotation;

/**路径规划信息*/
@property (strong, nonatomic) AMapRoute *route;

/**用于显示当前路线方案*/
@property (strong, nonatomic) MANaviRoute * naviRoute;

@property (nonatomic ,strong) MAAnimatedAnnotation *driverA;

@property (nonatomic ,strong) AMapSearchAPI *searchA;

@property (nonatomic ,strong) NSMutableArray *points;


@end

@implementation JCKJDDJDViewController


-(AMapSearchAPI *)searchA{
    if (_searchA == nil) {
        _searchA = [[AMapSearchAPI alloc] init];
        _searchA.delegate = self;
    }
    return _searchA;
}

-(MACustomCalloutView *)customCallView{
    
    if (_customCallView == nil) {
        
        self.jckjView = [JCKJCustomCalloutView customCalloutView];
        self.jckjView.frame = CGRectMake(0, -10, 161, 35);
        _customCallView =[[MACustomCalloutView alloc] initWithCustomView:self.jckjView];

    }
    
    return _customCallView;
    
    
}


static const NSString *startTitle = @"开始点";
static const NSString *qidiantitle = @"起点";
static const NSString *endTitle = @"终点";
static const NSString *sjTitle = @"司机位置";




- (void)viewDidLoad {
    [super viewDidLoad];
  
    self.title = @"等待接单";
    
    self.navigationItem.rightBarButtonItem = [LYQCancleBarButton addCanclePlaceButton:self action:@selector(qxxcClick)];
    
    self.navigationItem.hidesBackButton = YES;
    
    self.mapView.frame = CGRectMake(0, 0, LYQ_SCREEN_W, LYQ_SCREEN_H - LYQ_NAV_H);
   
    
    MACoordinateSpan span =  self.mapView.region.span;
    
    MACoordinateRegion region = MACoordinateRegionMake(CLLocationCoordinate2DMake(self.startPoint.latitude, self.startPoint.longitude), span);
    
    self.mapView.region = region;
    
    
    
    [self.view addSubview:self.mapView];
    
    
    
    
    self.infoView = [JCKJDriverInfoView driverInfoView];
   
     self.infoView.frame = CGRectMake(5, self.view.xmg_height - 104 - 5, LYQ_SCREEN_W - 10, 104);
    
    self.infoView.transform = CGAffineTransformMakeTranslation(0, 200);
    
    [self.view addSubview:self.infoView];
    
    
    [self addDefaultAnnotations];
    
    
    self.timer1 = [NSTimer timerWithTimeInterval:3
                                         target:self selector:@selector(getCarInfo) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer1 forMode:NSRunLoopCommonModes];
 
    self.timer2 = [NSTimer timerWithTimeInterval:2
                                          target:self selector:@selector(getCarLocation) userInfo:nil repeats:YES];

    [[NSRunLoop currentRunLoop] addTimer:self.timer2 forMode:NSRunLoopCommonModes];

}


/**获取司机位置信息*/
-(void)getCarLocation{
    
    
    
    JCKJExpressParam *param = [JCKJExpressParam param];
    param.ordernum = self.orderModel.orderunm;

    [JCKJExpressRequestTool POST_getDriverInfo:param success:^(JCKJCarInfoModel *carModel) {

        
        
    } failure:^(NSError *error) {
        
    }];
    
    
}

-(void)getCarInfo{
    
    LYQLog(@"----------------");

    JCKJExpressParam *param = [JCKJExpressParam param];
    param.ordernum = self.orderModel.orderunm;

    [JCKJExpressRequestTool POST_getDriver_JD:param success:^(JCKJExpressOrderModel *expModel) {

        // 判断是否接单
        if ([expModel.status isEqualToString:order_state_sjjd]) {

            [self.jckjView stopTimer];
            self.isJieDan = YES;
            //请求司机位置信息
            [JCKJExpressRequestTool POST_getDriverInfo:param success:^(JCKJCarInfoModel *carModel) {

                        // 删除倒计时大头针
                    //    [self.mapView removeAnnotation:self.startAnnotation];
                        // 添加司机位置和起点的大头针
                       [self addStartWithDriverPoint:carModel];
                        //司机到乘客起点的路径规划
                       [self searchRoutePlanningDrive:carModel];

                // 请求司机的详细信息
                [JCKJExpressRequestTool POST_get_JD_DriverInfo:param success:^(JCKJDriverInfoModel *driverInfoModel) {

                    self.infoView.model = driverInfoModel;

                    [UIView animateWithDuration:0.4 animations:^{
                        self.infoView.transform = CGAffineTransformIdentity;
                    }];

                    [self.timer1 invalidate];
                    self.timer1 = nil;

                } failure:^(NSError *error) {

                }];


            } failure:^(NSError *error) {

            }];

        }else{

        }
        
    } failure:^(NSError *error) {

    }];

    
}

- (void)addDefaultAnnotations {
   self.startAnnotation = [[MAPointAnnotation alloc] init];
    self.startAnnotation.coordinate =CLLocationCoordinate2DMake([self.startModel.location.latitude doubleValue], [self.startModel.location.longitude doubleValue]);
    self.startAnnotation.title = (NSString *)startTitle;
    [self.mapView addAnnotation:self.startAnnotation];
 
}
-(void)searchRoutePlanningDrive:(JCKJCarInfoModel *)model{
    AMapDrivingRouteSearchRequest *navi = [[AMapDrivingRouteSearchRequest alloc] init];
    navi.requireExtension = YES;
    navi.strategy = 5;
    navi.origin = [AMapGeoPoint locationWithLatitude:model.latitude
                                           longitude:model.longitude];
    navi.destination = [AMapGeoPoint locationWithLatitude:self.startPoint.latitude
                                                longitude:self.startPoint.longitude];

    
    [self.searchA AMapDrivingRouteSearch:navi];

    
}

//路径规划搜索完成回调.
- (void)onRouteSearchDone:(AMapRouteSearchBaseRequest *)request response:(AMapRouteSearchResponse *)response{
    if (response.route == nil){
        return;
    }
    
    self.route = response.route;
    [self presentCurrentRouteCourse];
    
    [self.timer1 invalidate];
    self.timer1 = nil;
    
    [self.timer2 fire];
    
}

-(void)presentCurrentRouteCourse{

    [self.naviRoute removeFromMapView];  //清空地图上已有的路线
    AMapGeoPoint *startPoint = [AMapGeoPoint locationWithLatitude:self.startPoint.latitude longitude:self.startPoint.longitude]; //起点
    AMapGeoPoint *endPoint = [AMapGeoPoint locationWithLatitude:self.endPoint.latitude longitude:self.endPoint.longitude];
    MANaviAnnotationType type = MANaviAnnotationTypeDrive; //驾车类型
    
    self.naviRoute = [MANaviRoute naviRouteForPath:self.route.paths[0] withNaviType:type showTraffic:NO startPoint:startPoint endPoint:endPoint];
    [self.naviRoute addToMapView:self.mapView];  //显示到地图上
    UIEdgeInsets edgePaddingRect = UIEdgeInsetsMake(60, 60, 60, 60);
    [self.mapView setVisibleMapRect:[CommonUtility mapRectForOverlays:self.naviRoute.routePolylines]
                        edgePadding:edgePaddingRect
                           animated:YES];
    
//
    AMapPath *path = self.route.paths[0];
    self.points = [NSMutableArray array];
//

    for (AMapStep *step in path.steps) {
        
        NSArray *point = [step.polyline componentsSeparatedByString:@";"];
        for (NSString *pLoAndLa in point) {
          NSArray * pLoAndLaArray = [pLoAndLa componentsSeparatedByString:@","];
            double lon = [[pLoAndLaArray firstObject] doubleValue];
            double lat = [[pLoAndLaArray lastObject] doubleValue];
            AMapGeoPoint *geoPoint = [AMapGeoPoint locationWithLatitude:lat longitude:lon];
            [self.points addObject:geoPoint];
        }

    }
}







//地图上覆盖物的渲染，可以设置路径线路的宽度，颜色等
- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id<MAOverlay>)overlay {
    NSLog(@"%@",overlay.class);
    //showTraffic为NO时，不需要带实时路况，路径为单一颜色，比如驾车线路目前为blueColor
    if ([overlay isKindOfClass:[MANaviPolyline class]]) {
        MANaviPolyline *naviPolyline = (MANaviPolyline *)overlay;
        MAPolylineRenderer *polylineRenderer = [[MAPolylineRenderer alloc] initWithPolyline:naviPolyline.polyline];
        polylineRenderer.lineWidth = 8;
        polylineRenderer.strokeColor = jckj_COLOR_driverMain;
        polylineRenderer.lineCapType = kMALineCapRound;
        return polylineRenderer;
    }
   
    return nil;
}


-(void)addStartWithDriverPoint:(JCKJCarInfoModel *)carModel{
    
//    MAPointAnnotation *startA = [[MAPointAnnotation alloc] init];
//    startA.coordinate =CLLocationCoordinate2DMake([self.startModel.location.latitude doubleValue], [self.startModel.location.longitude doubleValue]);
//    startA.title = (NSString *)qidiantitle;
//    [self.mapView addAnnotation:startA];
    
    self.customCallView.hidden = YES;    
    self.driverA = [[MAAnimatedAnnotation alloc] init];
    self.driverA.coordinate = CLLocationCoordinate2DMake(carModel.latitude, carModel.longitude);
    self.driverA.title = (NSString *)sjTitle;
    
    [self.mapView addAnnotation:self.driverA];
    

    
}

/**取消行程*/
-(void)qxxcClick{
    
    LYQAlertView *aler = [LYQAlertView alertViewWithType:alertViewType_SURE];
    
    if (self.isJieDan) {
        aler.contentText = [LYQPromptTool prompt_cancleWithState:3];

    }else{
        aler.contentText = [LYQPromptTool prompt_cancleWithState:1];

    }
    
    [aler show];
    
    aler.sureClick = ^{

        
        
        JCKJExpressParam *param = [JCKJExpressParam param];
        param.ordernum = self.orderModel.orderunm;
        [JCKJExpressRequestTool POST_cancelfastorder:param success:^{
            if (self.isJieDan) {
            JCKJCanclePlaceDoneController *cancelVC = [[JCKJCanclePlaceDoneController alloc] init];
              [self.navigationController pushViewController:cancelVC animated:YES];
            }else{
                [self.navigationController popViewControllerAnimated:YES];
                [self.timer1 invalidate];
                self.timer1 = nil;
                [self.timer2 invalidate];
                self.timer2 = nil;
            }
            
            
        } failure:^(NSError *error) {
            
        }];
        
        
    };
    
}

- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation {
    
    
    if ([annotation isKindOfClass:[MAUserLocation class]]) {
        
       MAAnnotationView *a =  [[MAAnnotationView alloc] init];
        return a;
    }

    if ([annotation isKindOfClass:[MAPointAnnotation class]]) {
        

        //标注的view的初始化和复用
        static NSString *routePlanningCellIdentifier = @"RoutePlanningCellIdentifier";
        MAAnnotationView *poiAnnotationView = (MAAnnotationView*)[self.mapView dequeueReusableAnnotationViewWithIdentifier:routePlanningCellIdentifier];

        
        if (poiAnnotationView == nil) {
            poiAnnotationView = [[MAAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:routePlanningCellIdentifier];
        }
   
        
        if ([[annotation title] isEqualToString:(NSString *)startTitle]) {
            poiAnnotationView.image = [UIImage imageNamed:@"TheStartingPoint"];  //开始点
            poiAnnotationView.selected = YES;
            poiAnnotationView.customCalloutView = self.customCallView;
            poiAnnotationView.canShowCallout = YES;
        }
        if ([[annotation title] isEqualToString:(NSString *)qidiantitle]) {
            poiAnnotationView.image = [UIImage imageNamed:@"qidian"];  //起点
        }
        if ([[annotation title] isEqualToString:(NSString *)endTitle]) {
            poiAnnotationView.image = [UIImage imageNamed:@"LocateThefinish"];  //终点
        }
        if ([[annotation title] isEqualToString:(NSString *)sjTitle]) {
            poiAnnotationView.image = [UIImage imageNamed:@"car"];  //终点
        }
        
         return poiAnnotationView;

    }
    
    return nil;
}

/**大头针加载完成了的回调方法*/
-(void)mapView:(MAMapView *)mapView didAddAnnotationViews:(NSArray *)views{
    
    for (MAAnnotationView *v  in views) {
        if ([[v.annotation title] isEqualToString:(NSString *)startTitle]) {
            [self.mapView selectAnnotation:v.annotation animated:YES];
        }
    }
    
}


-(void)startSearch{
    
}

-(void)dealloc{
    [self.timer1 invalidate];
    self.timer1 = nil;
    
    [self.timer2 invalidate];
    self.timer2 = nil;
    
}

@end
