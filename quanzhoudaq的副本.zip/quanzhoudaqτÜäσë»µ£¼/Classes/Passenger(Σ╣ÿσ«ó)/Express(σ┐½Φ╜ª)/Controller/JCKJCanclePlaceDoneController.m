//
//  JCKJCanclePlaceDoneController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/21.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJCanclePlaceDoneController.h"

#import "JCKJStartView.h"


@interface JCKJCanclePlaceDoneController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UIView *contentVIew;
@property (weak, nonatomic) IBOutlet UITableView *tableView;



@end

@implementation JCKJCanclePlaceDoneController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"已完成取消";
    
    
    
    
    
}

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 10;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cell_Id = @"cell_Id";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cell_Id];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cell_Id];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row];
    
    
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44.0f;
}


@end
