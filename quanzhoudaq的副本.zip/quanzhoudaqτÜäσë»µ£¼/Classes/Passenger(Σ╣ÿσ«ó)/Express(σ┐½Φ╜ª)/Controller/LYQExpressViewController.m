//
//  LYQExpressViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/6.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQExpressViewController.h"
#import "LYQLocaModel.h"
#import "JCKJExpressRequestTool.h"
#import "JCKJExpressParam.h"
#import "JCKJDriverCarInfoModel.h"

#import "JCKJBaseRequestTool.h"
#import "NSString+JCKJAttString.h"
#import "JCKJPriceModel.h"

//coordinate
@interface LYQExpressViewController ()<MAMapViewDelegate>

@property (weak, nonatomic) IBOutlet UIButton *startAddress;
@property (weak, nonatomic) IBOutlet UIButton *endAddress;

@property (weak, nonatomic) IBOutlet UIButton *price;
@property (nonatomic ,strong) UIImageView *centerImageView;
@property (weak, nonatomic) IBOutlet UIView *bottomView;

@property (nonatomic ,strong) NSMutableArray *annotionArrays;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rightConst_X;

@property (nonatomic ,assign) MACoordinateRegion orginRegion;


@end

@implementation LYQExpressViewController


-(NSMutableArray *)annotionArrays{
    if (_annotionArrays == nil) {
        _annotionArrays = [NSMutableArray array];
    }
    return _annotionArrays ;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.mapView.frame = self.mapViewRect;
    self.centerImageView = [[UIImageView alloc] initWithImage:LYQ_IMAGENAME(@"RecommendedPositioning")];
    self.centerImageView.xmg_centerX = LYQ_SCREEN_W * 0.5;
    self.centerImageView.xmg_y = self.mapViewRect.size.height * 0.5 - self.centerImageView.xmg_height;
    [self.mapView addSubview:self.centerImageView];
    [self.view insertSubview:self.mapView atIndex:0];
    self.bottomView.transform = CGAffineTransformMakeTranslation(0, 110);
    
    
    [self.bottomView cornerWithRadiusSize:3];

    
}




-(void)startSearch{
    [self.startAddress setTitle:@"正在获取上车地点..." forState:UIControlStateNormal];
}


-(void)searchDoneWithAddressModel:(LYQAddressModel *)model isRemondArray:(NSMutableArray *)AddressremondArray{
    [self.startAddress setTitle:model.name forState:UIControlStateNormal];
    
    NSString *coordinate = [NSString stringWithFormat:@"%@,%@",model.location.longitude,model.location.latitude];
    
    [self searchDriverInfoWithCoordinate:coordinate];
    
    self.startModel = model;
}

-(void)choseStartAddressModel:(LYQAddressModel *)startModels{
    [self.startAddress setTitle:startModels.name forState:UIControlStateNormal];
    
    
    NSString *coordinate = [NSString stringWithFormat:@"%@,%@",startModels.location.longitude,startModels.location.latitude];
    
    [self searchDriverInfoWithCoordinate:coordinate];
    
    self.startModel = startModels;
}

-(void)choseEndAddressModel:(LYQAddressModel *)endModels{
    [self.endAddress setTitle:endModels.name forState:UIControlStateNormal];
    self.endModel = endModels;
}


/**收缩附近的司机*/
-(void)searchDriverInfoWithCoordinate:(NSString *)coordinate{
    
//    JCKJExpressParam *param = [[JCKJExpressParam alloc] init];
//    param.coordinate = @"103.9521387908815,30.73680203984034";
//
//    [JCKJExpressRequestTool POST_DirverCarsInfoParams:param success:^(NSMutableArray *carInfoModels) {
//
//        [self addAnnotationWithCarInfoModels:carInfoModels];
//
//    } failure:^(NSError *error) {
//
//    }];
    
    
}


-(void)addAnnotationWithCarInfoModels:(NSMutableArray *)infoModels{
    
//    [self.mapView removeAnnotation:self.annotionArrays];
//    LYQLog(@"%@",self.mapView.annotations);
//
//    [self.annotionArrays removeAllObjects];

//    for (JCKJDriverCarInfoModel *car in infoModels) {
//
//        MAPointAnnotation *carAnnotaion = [[MAPointAnnotation alloc] init];
//        NSArray *laloArray = [car.coordinate componentsSeparatedByString:@","];
//        NSString *la = [laloArray firstObject];
//        NSString *lo = [laloArray lastObject];
//        carAnnotaion.coordinate = CLLocationCoordinate2DMake(la.doubleValue ,lo.doubleValue);
//        carAnnotaion.title = @"车";
//
//        [self.mapView addAnnotation:carAnnotaion];
//      //  [self.annotionArrays addObject:carAnnotaion];
//        LYQLog(@"%@",self.mapView.annotations);
//    }
    
}
- (void)mapInitComplete:(MAMapView *)mapView{
    self.orginRegion = mapView.region;
}

- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation {
    
    if ([annotation isKindOfClass:[MAUserLocation class]]) {
        return nil;
    }
    
    if ([annotation isKindOfClass:[MAPointAnnotation class]]) {
        //标注的view的初始化和复用
        static NSString *routePlanningCellIdentifier = @"RoutePlanningCellIdentifier";
        MAAnnotationView *poiAnnotationView = (MAAnnotationView*)[self.mapView dequeueReusableAnnotationViewWithIdentifier:routePlanningCellIdentifier];
        
        
        
        
        if (poiAnnotationView == nil) {
            poiAnnotationView = [[MAAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:routePlanningCellIdentifier];
        }
        poiAnnotationView.selected = YES;
        poiAnnotationView.canShowCallout = YES;
        
        if ([[annotation title] isEqualToString:@"车"]) {
            poiAnnotationView.image = [UIImage imageNamed:@"TheStartingPoint"];  //起点
            
        }
        
        return poiAnnotationView;
        
    }
    
    return nil;
}




/**重新算路*/
-(void)recalculatetheRoad{
    [UIView animateWithDuration:0.5 animations:^{
        self.bottomView.transform = CGAffineTransformMakeTranslation(0, 110);
    }];
    
}


-(void)showPriceSuccess:(JCKJPriceModel *)priceModel{
    
    [UIView animateWithDuration:0.5 animations:^{
        self.bottomView.transform = CGAffineTransformIdentity;
    }];
    
    [self.price setAttributedTitle:[NSString getMoneyAtt_redText:priceModel.price] forState:UIControlStateNormal];
    
}

- (IBAction)startClick:(UIButton *)sender {
    [self showAddressViewisRecommend:YES];
}
- (IBAction)endClick:(UIButton *)sender {
    
    [self showAddressViewisRecommend:NO];
    
}


/*呼叫**/
- (IBAction)fjClick:(UIButton *)sender {
    
    if (self.fujiaoClickBlock) {
        self.fujiaoClickBlock();
    }
}
- (IBAction)diweiClick:(UIButton *)sender {
    
    [self.mapView setRegion:self.orginRegion animated:YES];
    
    
}



@end
