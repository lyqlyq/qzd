//
//  JCKJDDJDViewController.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/21.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJMapBaseViewController.h"


@class JCKJExpressOrderModel;
@interface JCKJDDJDViewController : JCKJMapBaseViewController


@property (nonatomic ,strong) LYQAddressModel *startModel;
@property (nonatomic ,strong) LYQAddressModel *endModel;
@property (nonatomic ,strong) JCKJExpressOrderModel *orderModel;

@end
