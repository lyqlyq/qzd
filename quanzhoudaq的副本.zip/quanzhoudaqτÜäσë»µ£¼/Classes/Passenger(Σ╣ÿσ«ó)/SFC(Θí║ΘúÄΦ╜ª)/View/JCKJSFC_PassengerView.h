//
//  JCKJSFC_PassengerView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//
#import <UIKit/UIKit.h>



typedef void(^startAddressClickBlock)();
typedef void(^endAddressClickBlock)();
typedef void(^passengerPlaceDetialClickBlock)();

@interface JCKJSFC_PassengerView : UIView

@property (nonatomic ,copy) startAddressClickBlock startBlock;
@property (nonatomic ,copy) endAddressClickBlock endBlock;
@property (nonatomic ,copy) passengerPlaceDetialClickBlock placeDeilatBlock;



@property (nonatomic ,copy) NSString *start_addressText;

@property (nonatomic ,copy) NSString *end_addressText;



@end
