//
//  JCKJSFC_DriverView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^startChoseAddressBlock)(UILabel *clickLabel);
typedef void(^endChoseAddressBlock)(UILabel *clickLabel);
typedef void(^drivePlaceOrderDetialBlock)();



@interface JCKJSFC_DriverView : UIView

@property (nonatomic ,copy) startChoseAddressBlock startAddressClickBlock;
@property (nonatomic ,copy) endChoseAddressBlock endAddressClickBlock;
@property (nonatomic ,copy) drivePlaceOrderDetialBlock placeClickBlock;


@property (nonatomic ,copy) NSString *start_AddressText;



@end
