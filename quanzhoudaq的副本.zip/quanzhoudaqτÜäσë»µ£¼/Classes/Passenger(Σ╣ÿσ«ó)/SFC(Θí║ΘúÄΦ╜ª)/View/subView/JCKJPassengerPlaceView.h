//
//  JCKJPassengerPlaceView.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JCKJPassengerPlaceView : UIView

@property (nonatomic ,assign) BOOL isHidenDetialImageView;

@property (nonatomic ,assign) BOOL isDriverColor;

@property (nonatomic ,copy) NSString *stateText;

@end
