//
//  JCKJPassengerPlaceView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPassengerPlaceView.h"

@interface JCKJPassengerPlaceView()
@property (weak, nonatomic) IBOutlet UIImageView *detialImageView;
@property (weak, nonatomic) IBOutlet UILabel *stateLabel;

@end 

@implementation JCKJPassengerPlaceView

-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.autoresizingMask = UIViewAutoresizingNone;
}

-(void)setIsHidenDetialImageView:(BOOL)isHidenDetialImageView{
    _isHidenDetialImageView = isHidenDetialImageView;
    self.detialImageView.hidden = isHidenDetialImageView;
    
}

-(void)setIsDriverColor:(BOOL)isDriverColor{
    _isDriverColor = isDriverColor;
    if (isDriverColor) {
        self.stateLabel.textColor = jckj_COLOR_driverMain;
    }else{
        self.stateLabel.textColor = jckj_COLOR_ligthRed;
    }
    
}

-(void)setStateText:(NSString *)stateText{
    _stateText = stateText;
    
    self.stateLabel.text = stateText;
}

@end
