//
//  JCKJSFC_DriverView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJSFC_DriverView.h"
#import "LYQChoseTimeView.h"
#import "LYQChoseZhongLiangView.h"

#import "JCKJPassengerPlaceView.h"

@interface JCKJSFC_DriverView()
@property (weak, nonatomic) IBOutlet UIButton *choseCountButton;

@property (weak, nonatomic) IBOutlet UIButton *choseTimeButton;
@property (weak, nonatomic) IBOutlet UILabel *choseStartAddress;

@property (weak, nonatomic) IBOutlet UILabel *choseEndAddress;

@property (weak, nonatomic) IBOutlet UIView *placeContentView;




@end

@implementation JCKJSFC_DriverView

-(void)awakeFromNib{
    [super awakeFromNib];
    
    
    self.choseEndAddress.userInteractionEnabled = YES;
    self.choseStartAddress.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *statrTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(choseStart)];
    UITapGestureRecognizer *endTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(choseEnd)];
    
    [self.choseEndAddress addGestureRecognizer:endTap];
    [self.choseStartAddress addGestureRecognizer:statrTap];
    
    JCKJPassengerPlaceView *placeView = [JCKJPassengerPlaceView xmg_viewFromXib];
    placeView.isDriverColor = YES;
    placeView.stateText = @"2单";
    placeView.frame = CGRectMake(0, 28, LYQ_SCREEN_W, 73);
    
    UITapGestureRecognizer *palceTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapPlaceClick)];
    placeView.userInteractionEnabled = YES;
    [placeView addGestureRecognizer:palceTap];
    
    
    [self.placeContentView addSubview:placeView];
    
    
    self.autoresizingMask = UIViewAutoresizingNone;

    
}

-(void)tapPlaceClick{
    
    if (self.placeClickBlock) {
        self.placeClickBlock();
    }
    
}

-(void)choseStart{
    if (self.startAddressClickBlock) {
        self.startAddressClickBlock(self.choseStartAddress);
    }
}
-(void)choseEnd{
    if (self.endAddressClickBlock) {
        self.endAddressClickBlock(self.choseEndAddress);
    }
}
- (IBAction)choseTime:(UIButton *)sender {
    
    [LYQChoseTimeView showTitle:@"出发时间"].sureBtnClick = ^(NSString *choseTimeUserContStr, NSString *date) {
        
        [LYQChoseTimeView dissmiss:^{
            [self zuoweiClick:self.choseCountButton];
        }];
        
        [self.choseTimeButton setTitle:choseTimeUserContStr forState:UIControlStateNormal];
    };
    
}
- (IBAction)zuoweiClick:(UIButton *)sender {
    
    LYQChoseZhongLiangView *zwxView = [LYQChoseZhongLiangView xmg_viewFromXib];
    
    [zwxView show_ZWX];
    
    
    LYQ_WEAK_SELF(zwxView);
    
    weakzwxView.choseZhongBlock = ^(NSString *choseStr) {
        
        [weakzwxView dissmissWithCompletion:^{
            
        }];
        
        [self.choseCountButton setTitle:choseStr forState:UIControlStateNormal];
     
    };
    
}

-(void)setStart_AddressText:(NSString *)start_AddressText{
    _start_AddressText = start_AddressText;
    
    self.choseStartAddress.text = start_AddressText;
}

@end
