//
//  JCKJSFC_PassengerView.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJSFC_PassengerView.h"
#import "JCKJPassengerPlaceView.h"

#import "LYQChoseTimeView.h"
#import "LYQChoseZhongLiangView.h"
#import "LYQRemarksAndThankView.h"
#import "JCKJLocationManager.h"

@interface JCKJSFC_PassengerView ()
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIButton *timeButton;
@property (weak, nonatomic) IBOutlet UIButton *remarkButton;

@property (weak, nonatomic) IBOutlet UIButton *userCountButton;
@property (weak, nonatomic) IBOutlet UILabel *statrAddressLabel;

@property (weak, nonatomic) IBOutlet UILabel *endAddressLabel;

@property (nonatomic ,strong) JCKJLocationManager *locationMgr;



@end

@implementation JCKJSFC_PassengerView

-(JCKJLocationManager *)locationMgr{
    if (_locationMgr == nil) {
        _locationMgr = [[JCKJLocationManager alloc] init];
    }
    return _locationMgr;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    
    
    self.autoresizingMask = UIViewAutoresizingNone;
    
    
    JCKJPassengerPlaceView *placeView = [JCKJPassengerPlaceView xmg_viewFromXib];
    placeView.frame = CGRectMake(0, 0, LYQ_SCREEN_W, 73);

    
    self.statrAddressLabel.userInteractionEnabled = YES;
    self.endAddressLabel.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *startTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(satrtClick)];
    
    
    UITapGestureRecognizer *endTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(endClick)];
    
    
    [self.statrAddressLabel addGestureRecognizer:startTap];
    [self.endAddressLabel addGestureRecognizer:endTap];
    
    placeView.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(placeViewClick)];
    
    [placeView addGestureRecognizer:tap];
    [self.contentView addSubview:placeView];
    
    [self.locationMgr startUserLocationAddressSuccess:^(NSString *cityName) {
        self.start_addressText = cityName;
    }];
    
    
}

/**查看订单详情*/
-(void)placeViewClick{
    
    if (self.placeDeilatBlock) {
        self.placeDeilatBlock();
    }
}

/**开始地址点击*/
-(void)satrtClick{
    
    if (self.startBlock) {
        self.startBlock();
    }
    
}
/**结束地址点击*/
-(void)endClick{
    if (self.endBlock) {
        self.endBlock();
    }
}

/**选择时间*/
- (IBAction)choseTimeButtonClick:(UIButton *)sender {
    LYQChoseTimeView *timeView = [LYQChoseTimeView showTitle:@"出发时间"];
    timeView.sureBtnClick = ^(NSString *choseTimeUserContStr, NSString *date) {
        [LYQChoseTimeView  dissmiss:^{
            [self choseUserCountButtonClick:self.userCountButton];
        }];
        [sender setTitle:choseTimeUserContStr forState:UIControlStateNormal];
    };
    
}
/**选择人数*/
- (IBAction)choseUserCountButtonClick:(UIButton *)sender {
    LYQChoseZhongLiangView * userView = [LYQChoseZhongLiangView xmg_viewFromXib];
    [userView showUserCount];
    LYQ_WEAK_SELF(userView);
    userView.choseZhongBlock = ^(NSString *choseStr) {
        [weakuserView dissmissWithCompletion:^{
            [self choseRemarkButtonClick:self.remarkButton];
        }];
        [sender setTitle:choseStr forState:UIControlStateNormal];
    };
    
}
/**选择行程备注*/
- (IBAction)choseRemarkButtonClick:(UIButton *)sender {
    
    
 __block NSString *title = [NSString new];
    
    
    [LYQRemarksAndThankView showRemarksViewWithSeleButtonsBlock:^(NSMutableArray *seleButtons) {
        
        [seleButtons enumerateObjectsUsingBlock:^(UIButton *seleButton, NSUInteger idx, BOOL * _Nonnull stop) {
            title = [title stringByAppendingString:seleButton.titleLabel.text];
        }];
        
        if (title.length > 0) {
            
            [sender setTitle:title forState:UIControlStateNormal];
        }
        
    }];
    
    
}

-(void)setStart_addressText:(NSString *)start_addressText{
    _start_addressText = start_addressText;
    
    self.statrAddressLabel.text = start_addressText;
}

-(void)setEnd_addressText:(NSString *)end_addressText{
    _end_addressText = end_addressText;
    
    self.endAddressLabel.text = end_addressText;
}

@end
