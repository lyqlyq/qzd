//
//  JCKJChoseAddressController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJChoseAddressController.h"
#import "JCKJBorderButton.h"
#import "JCKJAddressModel.h"

#import "LYQChoseZhongLiangView.h"

#define cityButton_W 88
#define cityButton_H 35
#define rank   3  // 每列行数


@interface JCKJChoseAddressController ()
@property (weak, nonatomic) IBOutlet UIView *addressView;
@property (weak, nonatomic) IBOutlet JCKJBorderButton *topButton;

@end

@implementation JCKJChoseAddressController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选择地址";
    
    [self setUpCityButtonsWithArrays:[JCKJAddressModel getAllCityArrays]];
 
    if (self.isSatrtClick) {
        [self topAddressClikc:self.topButton];
    }
    
}

-(void)setUpCityButtonsWithArrays:(NSMutableArray <JCKJAddressModel *> *)models{
    
     // 间距
       CGFloat rankMargin = (LYQ_SCREEN_W - rank * cityButton_W - 20) / (rank - 1);
    
    CGFloat  rowMargin = 25;
    
      CGFloat defa_x = 10;
   
    
    for (NSInteger i = 0 ; i < models.count ; i ++) {
        CGFloat cityButton_X = (i % rank) * (cityButton_W + rankMargin) + defa_x;
        CGFloat cityButton_Y = (i / rank) * (cityButton_H +rowMargin);

        JCKJBorderButton *borderButton = [[JCKJBorderButton alloc] init];

        borderButton.frame = CGRectMake(cityButton_X, cityButton_Y, cityButton_W, cityButton_H);
        borderButton.model = models[i];
        
        [borderButton addTarget:self action:@selector(borddrButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.addressView addSubview:borderButton];
        
    }
    
    
}

-(void)borddrButtonClick:(JCKJBorderButton *)borButton{
    
    
    if (self.sureAddressBlock) {
        self.sureAddressBlock(borButton.model.cityName);
    }
    
    [self.navigationController popViewControllerAnimated:YES];
    
    
}

- (IBAction)topAddressClikc:(JCKJBorderButton *)sender {
    
    LYQChoseZhongLiangView *choseAddress = [LYQChoseZhongLiangView xmg_viewFromXib];
    
    [choseAddress showPassengerChoseAddressWithAddressArray:nil];
    LYQ_WEAK_SELF(choseAddress)
    weakchoseAddress.choseZhongBlock = ^(NSString *choseStr) {
        [weakchoseAddress dissmissWithCompletion:^{
            if (self.sureAddressBlock) {
                self.sureAddressBlock(choseStr);
            }
            [self.navigationController popViewControllerAnimated:YES];
            
        }];
    };
    
    
}

@end
