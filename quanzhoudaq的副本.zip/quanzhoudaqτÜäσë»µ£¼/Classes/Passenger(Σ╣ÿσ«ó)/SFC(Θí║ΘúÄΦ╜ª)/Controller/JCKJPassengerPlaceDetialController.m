//
//  JCKJPassengerPlaceDetialController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJPassengerPlaceDetialController.h"
#import "LYQCancleBarButton.h"
#import "LYQAlertView.h"
#import "LYQPromptTool.h"

#import "JCKJPassengerPlaceView.h"

#import "JCKJDriverInfoPlaceCell.h"

@interface JCKJPassengerPlaceDetialController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UIView *placeView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation JCKJPassengerPlaceDetialController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"我的行程";
    
    self.navigationItem.rightBarButtonItem = [LYQCancleBarButton addCanclePlaceButton:self action:@selector(cancelPlace)];
    
    JCKJPassengerPlaceView *place = [JCKJPassengerPlaceView xmg_viewFromXib];
    place.frame = self.placeView.bounds;
    place.isHidenDetialImageView = YES;
    [self.placeView addSubview:place];
    
}

-(void)cancelPlace{
    
    
    LYQAlertView *alerView = [LYQAlertView alertViewWithType:alertViewType_SURE];
    
    alerView.contentText = [LYQPromptTool prompt_cancleWithState:1];
    
    [alerView show];
    
    alerView.sureClick = ^{
        
    };
    
}

#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    JCKJDriverInfoPlaceCell *cell = [JCKJDriverInfoPlaceCell driverInfoPlaceCellWithTableView:tableView];
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 190.0f;
}


@end
