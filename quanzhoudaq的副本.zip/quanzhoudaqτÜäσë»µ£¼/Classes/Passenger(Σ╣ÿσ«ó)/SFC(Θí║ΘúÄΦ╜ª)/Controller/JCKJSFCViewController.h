//
//  JCKJSFCViewController.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/26.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^startAddressClickBlock)();
typedef void(^endAddressClickBlock)();
typedef void(^passengerPlaceDetialClickBlock)();

typedef void(^driverStartAddressClick)(UILabel *clickLabel);
typedef void(^driverEndAddressClick)(UILabel *clickLabel);
typedef void(^driverPlaceOrderDetialClick)();
typedef void (^driverHeaderClickBlock)();


@interface JCKJSFCViewController : UIViewController

@property (nonatomic ,copy) startAddressClickBlock startAddressClickBlock;
@property (nonatomic ,copy) endAddressClickBlock endAddressClickBlock;
@property (nonatomic ,copy) passengerPlaceDetialClickBlock passengerPlaceDetialBlock;

@property (nonatomic ,copy) driverStartAddressClick driverStartAddressClickBlock;
@property (nonatomic ,copy) driverEndAddressClick driverEndAddressClickBlock;
@property (nonatomic ,copy) driverPlaceOrderDetialClick driverPlaceClickBlock;
@property (nonatomic ,copy) driverHeaderClickBlock driverHeaderClickBlock;




/**乘客开始地点*/
@property (nonatomic ,copy) NSString *passenger_startAddressText;

/**乘客结束地点*/
@property (nonatomic ,copy) NSString *passenger_endAddressText;

@property (nonatomic ,copy) NSString *driver_startAddressText;


@end
