//
//  JCKJSFCViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/26.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJSFCViewController.h"


#import "JCKJSFC_PassengerView.h"
#import "JCKJSFC_DriverView.h"

@interface JCKJSFCViewController ()<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *srcView;

@property (nonatomic ,strong) JCKJSFC_PassengerView *passengerView;

@property (nonatomic ,strong) JCKJSFC_DriverView *driverView;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *lineConst_X;

@property (nonatomic ,strong) UIButton *seleButton;
@property (weak, nonatomic) IBOutlet UIButton *passengerButton;
@property (weak, nonatomic) IBOutlet UIButton *driverButton;
@property (weak, nonatomic) IBOutlet UIButton *driverHeader;

@end

@implementation JCKJSFCViewController

-(JCKJSFC_PassengerView *)passengerView{
    if (_passengerView == nil) {
        _passengerView = [JCKJSFC_PassengerView xmg_viewFromXib];
    }
    return _passengerView;
}

-(JCKJSFC_DriverView *)driverView{
    if (_driverView == nil) {
        _driverView = [JCKJSFC_DriverView xmg_viewFromXib];
    }
    return _driverView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.driverHeader.hidden = YES;
    
    self.passengerView.frame = CGRectMake(0, 0, LYQ_SCREEN_W, self.srcView.xmg_height);
    self.driverView.frame = CGRectMake(LYQ_SCREEN_W, 0, LYQ_SCREEN_W, self.srcView.xmg_height);
    
    
    [self.srcView addSubview:self.passengerView];
    [self.srcView addSubview:self.driverView];
    
    self.srcView.contentSize = CGSizeMake(LYQ_SCREEN_W * 2, 0);
    self.srcView.bounces  = YES;
    self.srcView.pagingEnabled = YES;
    self.srcView.delegate  = self;
    self.srcView.showsVerticalScrollIndicator = NO;
    self.srcView.showsHorizontalScrollIndicator = NO;
    
    self.seleButton = self.passengerButton;
    
    
    LYQ_WEAK_SELF(self);
    
    /**乘客开始地址的点击*/
    weakself.passengerView.startBlock = ^{
        
        if (weakself.startAddressClickBlock) {
            weakself.startAddressClickBlock();
        }
        
    };
    
    /**乘客结束地址点击*/
    weakself.passengerView.endBlock = ^{
        if (weakself.endAddressClickBlock) {
            weakself.endAddressClickBlock();
        }
    };
    
    weakself.passengerView.placeDeilatBlock = ^{
        if (weakself.passengerPlaceDetialBlock) {
            weakself.passengerPlaceDetialBlock();
        }
    };
    
    /**司机点击开始地址*/
    weakself.driverView.startAddressClickBlock = ^(UILabel *clickLabel) {
        if (weakself.driverStartAddressClickBlock) {
            weakself.driverStartAddressClickBlock(clickLabel);
        }
    };
    
    
    /**司机点击结束地址*/
    weakself.driverView.endAddressClickBlock = ^(UILabel *clickLabel) {
        if (weakself.driverEndAddressClickBlock) {
            weakself.driverEndAddressClickBlock(clickLabel);
        }
    };
    
    /**司机点击行程*/
    weakself.driverView.placeClickBlock = ^{
        if (weakself.driverPlaceClickBlock) {
            weakself.driverPlaceClickBlock();
        }
    };
    
    
    
    
}

/**司机头像点击*/
- (IBAction)driverHeaderClick:(UIButton *)sender {
    
    if (self.driverHeaderClickBlock) {
        self.driverHeaderClickBlock();
    }
    
    
}

- (IBAction)passengerClick:(UIButton *)sender {
    self.driverHeader.hidden = YES;
    self.seleButton.selected = NO;
    sender.selected = YES;
    self.seleButton = sender;

    self.lineView.backgroundColor = jckj_COLOR_ligthRed;

    
    [UIView animateWithDuration:0.4 animations:^{
        [self.srcView setContentOffset:CGPointMake(0, 0) animated:YES];
        
        self.lineConst_X.constant = 10;
        
        [self.view layoutIfNeeded];
        
    }];
    
}
- (IBAction)driverClick:(UIButton *)sender {
    self.driverHeader.hidden = NO;

    self.seleButton.selected = NO;
    sender.selected = YES;
    self.seleButton = sender;
    
    self.lineView.backgroundColor = jckj_COLOR_driverMain;
    
    [UIView animateWithDuration:0.4 animations:^{
        
        self.lineConst_X.constant = 60;
        
        [self.view layoutIfNeeded];
        
        [self.srcView setContentOffset:CGPointMake(LYQ_SCREEN_W, 0) animated:YES];
    }];
    
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
   
    CGFloat offset_x = scrollView.contentOffset.x;
    
    if (offset_x > 0) {
         [self driverClick:self.driverButton];
    }else{
        [self passengerClick:self.passengerButton];

    }
    
    
}

-(void)setPassenger_endAddressText:(NSString *)passenger_endAddressText{
    _passenger_endAddressText = passenger_endAddressText;
    self.passengerView.end_addressText = passenger_endAddressText;
   
}

-(void)setPassenger_startAddressText:(NSString *)passenger_startAddressText{
    _passenger_startAddressText = passenger_startAddressText;
    self.passengerView.start_addressText = passenger_startAddressText;
}
-(void)setDriver_startAddressText:(NSString *)driver_startAddressText{
    _driver_startAddressText = driver_startAddressText;
    self.driverView.start_AddressText = driver_startAddressText;
    
}


@end
