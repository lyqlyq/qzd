//
//  JCKJAddressModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JCKJAddressModel : NSObject

@property (nonatomic ,copy) NSString *cityName;


/**获取所有的city*/
+(NSMutableArray <JCKJAddressModel *>*)getAllCityArrays;

@end
