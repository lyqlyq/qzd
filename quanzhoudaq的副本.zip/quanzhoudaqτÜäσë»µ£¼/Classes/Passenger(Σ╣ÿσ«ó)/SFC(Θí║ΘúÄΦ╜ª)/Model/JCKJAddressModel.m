//
//  JCKJAddressModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJAddressModel.h"

@implementation JCKJAddressModel


/**获取所有的city*/
+(NSMutableArray <JCKJAddressModel *>*)getAllCityArrays{
   
    NSMutableArray *cityArrays = [NSMutableArray array];
    
    NSArray *cityNames = @[@"马尔康市",@"金川县",@"小金县",@"阿坝县",@"若尔盖县",@"红原县",@"壤塘县",@"汶川县",@"理县",@"茂县",@"松潘县",@"九寨沟县",@"黑水县"];
    
    for (NSInteger i = 0 ; i < cityNames.count ; i ++) {
        JCKJAddressModel *model = [[JCKJAddressModel alloc] init];
        model.cityName = cityNames[i];
        [cityArrays addObject:model];
    }
    return cityArrays;
}

@end
