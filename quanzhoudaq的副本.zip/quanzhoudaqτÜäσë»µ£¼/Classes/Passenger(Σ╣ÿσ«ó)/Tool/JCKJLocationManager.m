//
//  JCKJLocationManager.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/28.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJLocationManager.h"

#import <AMapLocationKit/AMapLocationKit.h>

@interface JCKJLocationManager()<AMapLocationManagerDelegate>

@property (nonatomic ,strong) AMapLocationManager *mager;

@end

@implementation JCKJLocationManager


-(AMapLocationManager *)mager{
    
    if (_mager == nil) {
        _mager = [[AMapLocationManager alloc] init];
        _mager.delegate = self;
        [_mager setDesiredAccuracy:kCLLocationAccuracyKilometer];
        _mager.locationTimeout =2;
        _mager.reGeocodeTimeout = 3;
    }
    return _mager;
    
}

-(void)startUserLocationAddressSuccess:(void(^)(NSString *cityName))success{
    
    [self.mager requestLocationWithReGeocode:YES completionBlock:^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error) {
        
        if (error)
        {
            LYQLog(@"locError:{%ld - %@};", (long)error.code, error.localizedDescription);
            
            if (error.code == AMapLocationErrorLocateFailed)
            {
                return;
            }
        }
        if (regeocode)
        {
            if (success) {
                success(regeocode.city);
            }
        }
    }];
    
    
}



@end
