//
//  JCKJMapTool.h
//  quanzhoudaq
//
//  Created by pro on 2018/4/9.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <MAMapKit/MAMapKit.h>
#import <AMapSearchKit/AMapSearchKit.h>
#import <AMapNaviKit/AMapNaviKit.h>



@interface JCKJMapTool : NSObject

/**获取地图*/
-(MAMapView *)getMapView;

/**获取路径规划类*/
-(AMapNaviDriveManager *)getSharedNavManger;


+(instancetype)mapTool;




@end
