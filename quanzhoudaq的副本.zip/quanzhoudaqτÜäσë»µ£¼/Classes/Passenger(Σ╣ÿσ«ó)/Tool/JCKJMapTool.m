//
//  JCKJMapTool.m
//  quanzhoudaq
//
//  Created by pro on 2018/4/9.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJMapTool.h"


@interface JCKJMapTool()

@end

@implementation JCKJMapTool


+(instancetype)mapTool{
   
    JCKJMapTool *tool = [[JCKJMapTool alloc] init];
    
    return tool;
}

/**获取地图*/
-(MAMapView *)getMapView{
    
    MAMapView *_mapView = [[MAMapView alloc] init];
    _mapView.autoresizingMask = UIViewAutoresizingNone;
    _mapView.customizeUserLocationAccuracyCircleRepresentation = YES;
    _mapView.showsCompass = NO;
    _mapView.showsIndoorMap = NO;
    _mapView.rotateEnabled = NO;
    _mapView.showsScale = NO;
    _mapView.distanceFilter=500;
    _mapView.zoomLevel = 16;
    _mapView.showsUserLocation = NO;
    _mapView.userTrackingMode = MAUserTrackingModeFollow;
    MAUserLocationRepresentation *r = [[MAUserLocationRepresentation alloc] init];
    r.showsAccuracyRing = NO;///精度圈是否显示，默认YES
    r.showsHeadingIndicator = NO;///是否显示方向指示(MAUserTrackingModeFollowWithHeading模式开启)。默认为YES
    r.fillColor = [UIColor redColor];///精度圈 填充颜色, 默认 kAccuracyCircleDefaultColor
    r.strokeColor = [UIColor blueColor];///精度圈 边线颜色, 默认 kAccuracyCircleDefaultColor
    r.lineWidth = 2;///精度圈 边线宽度，默认0
    r.enablePulseAnnimation = NO;///内部蓝色圆点是否使用律动效果, 默认YES
    r.locationDotBgColor = [UIColor greenColor];///定位点背景色，不设置默认白色
    r.locationDotFillColor = [UIColor grayColor];///定位点蓝色圆点颜色，不设置默认蓝色
    r.image = [UIImage imageNamed:@"ViaPoint"]; ///定位图标, 与蓝色原点互斥
    [_mapView updateUserLocationRepresentation:r];
    
    return _mapView;
    
}

-(AMapNaviDriveManager *)getSharedNavManger{
   AMapNaviDriveManager *navMgr =  [AMapNaviDriveManager sharedInstance];
    return navMgr;
}

-(AMapReGeocodeSearchRequest *)getRegeoWithDExtension:(BOOL)requireExtension{
     AMapReGeocodeSearchRequest *regeo = [[AMapReGeocodeSearchRequest alloc] init];
     regeo.requireExtension = requireExtension;
    return regeo;
}
-(AMapSearchAPI *)getSearch{
    
    AMapSearchAPI *search = [[AMapSearchAPI alloc] init];
    
    return search;
}




@end
