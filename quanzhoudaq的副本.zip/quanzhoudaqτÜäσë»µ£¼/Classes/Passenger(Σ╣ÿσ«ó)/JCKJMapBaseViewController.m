//
//  JCKJMapBaseViewController.m
//  quanzhoudaq
//
//  Created by pro on 2018/3/20.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "JCKJMapBaseViewController.h"

#import "LYQAddressModel.h"
#import "LYQLocaModel.h"
#import "LYQSearchAddressView.h"

#import "JCKJBaseRequestTool.h"
#import "JCKJExpressParam.h"
#import "JCKJExpressOrderModel.h"

#import "CommonUtility.h"
#import "MANaviRoute.h"

@interface JCKJMapBaseViewController ()<LYQSearchAddressViewDelegate,AMapNaviDriveManagerDelegate>

@property (nonatomic ,strong) LYQSearchAddressView * searchView;

@property (nonatomic ,strong) NSMutableArray *models;

/**起始点经纬度*/
@property (assign, nonatomic) CLLocationCoordinate2D startCoordinate;
/**终点经纬度*/
@property (assign, nonatomic) CLLocationCoordinate2D destinationCoordinate; //终点经纬度

@property (nonatomic ,strong)  AMapNaviDriveManager *nav_mgr;

/**开始点大头针*/
@property (strong, nonatomic) MAPointAnnotation *startAn;
/**结束点大头针*/
@property (strong, nonatomic) MAPointAnnotation *destinationAnnotation;

@end

@implementation JCKJMapBaseViewController

-(AMapNaviDriveManager *)nav_mgr{
    
    if (_nav_mgr == nil) {
        _nav_mgr = [AMapNaviDriveManager sharedInstance];
        _nav_mgr.delegate =self;
    }
    return _nav_mgr;
    
}

-(LYQSearchAddressView *)searchView{
    if (_searchView == nil) {
        _searchView = [LYQSearchAddressView xmg_viewFromXib];
        _searchView.delegate = self;
    }
    return _searchView;
}


- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.searchView.frame = CGRectMake(10, 10, LYQ_SCREEN_W - 20, LYQ_SCREEN_H - LYQ_NAV_H - 10);
    
    self.searchView.backgroundColor = [UIColor whiteColor];
    self.searchView.transform = CGAffineTransformMakeTranslation(0, LYQ_SCREEN_H);
    
    [self.view addSubview:self.searchView];


}

-(MAMapView *)mapView{
    if (_mapView == nil) {
        
        _mapView = [[MAMapView alloc] init];
        _mapView.autoresizingMask = UIViewAutoresizingNone;
        _mapView.customizeUserLocationAccuracyCircleRepresentation = YES;
        _mapView.showsCompass = NO;
        _mapView.showsIndoorMap = NO;
        _mapView.rotateEnabled = NO;
        _mapView.showsScale = NO;
        _mapView.distanceFilter=500;
        _mapView.zoomLevel = 16;
        _mapView.showsUserLocation = NO;
        _mapView.delegate = self;
        _mapView.userTrackingMode = MAUserTrackingModeFollow;
        
        MAUserLocationRepresentation *r = [[MAUserLocationRepresentation alloc] init];
        r.showsAccuracyRing = NO;///精度圈是否显示，默认YES
        r.showsHeadingIndicator = NO;///是否显示方向指示(MAUserTrackingModeFollowWithHeading模式开启)。默认为YES
        r.fillColor = [UIColor redColor];///精度圈 填充颜色, 默认 kAccuracyCircleDefaultColor
        r.strokeColor = [UIColor blueColor];///精度圈 边线颜色, 默认 kAccuracyCircleDefaultColor
        r.lineWidth = 2;///精度圈 边线宽度，默认0
        r.enablePulseAnnimation = NO;///内部蓝色圆点是否使用律动效果, 默认YES
        r.locationDotBgColor = [UIColor greenColor];///定位点背景色，不设置默认白色
        r.locationDotFillColor = [UIColor grayColor];///定位点蓝色圆点颜色，不设置默认蓝色
        r.image = [UIImage imageNamed:@"ViaPoint"]; ///定位图标, 与蓝色原点互斥
     
        [self.mapView updateUserLocationRepresentation:r];

    }
    return _mapView;
    
}

-(AMapReGeocodeSearchRequest *)regeo{
    if (_regeo == nil) {
        _regeo = [[AMapReGeocodeSearchRequest alloc] init];
        _regeo.requireExtension = YES;
    }
    return _regeo;
}

-(AMapSearchAPI *)search{
    if (_search == nil) {
        self.search = [[AMapSearchAPI alloc] init];
        self.search.delegate = self;
    }
    return _search;
}
- (void)mapView:(MAMapView *)mapView mapDidMoveByUser:(BOOL)wasUserAction {
    self.regeo.location = [AMapGeoPoint locationWithLatitude:self.mapView.region.center.latitude longitude:self.mapView.region.center.longitude];
    [self startSearch];
    
    [self.search AMapReGoecodeSearch:_regeo];
    
}
-(void)onReGeocodeSearchDone:(AMapReGeocodeSearchRequest *)request response:(AMapReGeocodeSearchResponse *)response{
    
    AMapAddressComponent *componet = response.regeocode.addressComponent;
    NSString *startAddress = componet.neighborhood;
 
    LYQAddressModel *startModel = [[LYQAddressModel alloc] init];
    
    if (startAddress.length == 0) {
        startAddress = [NSString stringWithFormat:@"%@%@%@",componet.district,componet.streetNumber.street,componet.streetNumber.number];
        startModel.name = startAddress;
    }else{
        startModel.name = startAddress;
    }
    LYQLocaModel *locaModel = [[LYQLocaModel alloc] init];
    locaModel.latitude = [NSString stringWithFormat:@"%f",componet.streetNumber.location.latitude];
    locaModel.longitude = [NSString stringWithFormat:@"%f",componet.streetNumber.location.longitude];
    startModel.location = locaModel;
    self.models = [LYQAddressModel mj_objectArrayWithKeyValuesArray:response.regeocode.pois];
    
    LYQAddressModel *addressModel = [self.models firstObject];
    if (addressModel != nil) {
        startModel.name = addressModel.name;
    }
    
    [self searchDoneWithAddressModel:startModel isRemondArray:self.models];
    
    
    self.startPoint = [AMapNaviPoint locationWithLatitude:componet.streetNumber.location.latitude longitude:componet.streetNumber.location.longitude];
    
    
    [self startCalculate];

    
}

/**开始算路*/
-(void)startCalculate{
    
    if (self.startPoint != nil && self.endPoint != nil) {
        
        [self recalculatetheRoad];
        
        [self.nav_mgr calculateDriveRouteWithStartPoints:@[self.startPoint] endPoints:@[self.endPoint] wayPoints:nil drivingStrategy:AMapNaviDrivingStrategySingleDefault];
    }
    
}


-(void)searchAddressViewDissmiss{
    
    [self dissmissSearchView];
    
}

-(void)searchAddressView:(LYQSearchAddressView *)searchView didSelectAddressModel:(LYQAddressModel *)model{
    
    if (searchView.isRecommend) {
        [self choseStartAddressModel:model];
    }else{
        [self choseEndAddressModel:model];
    }
    
    if (searchView.isRecommend) {
        self.startPoint = [AMapNaviPoint locationWithLatitude:[model.location.latitude doubleValue] longitude:[model.location.longitude doubleValue]];
    }else{
        
        self.endPoint = [AMapNaviPoint locationWithLatitude:[model.location.latitude doubleValue] longitude:[model.location.longitude doubleValue]];
    }
    
    
    
    
    [UIView animateWithDuration:0.4 animations:^{
        self.searchView.transform = CGAffineTransformMakeTranslation(0, LYQ_SCREEN_H);
    }];
    
    
    [self startCalculate];
    
}



-(void)showAddressViewisRecommend:(BOOL)isRecommend{
    
    if (isRecommend) {
        [UIView animateWithDuration:0.5 animations:^{
            self.searchView.addressArray = self.models;
            self.searchView.isRecommend = isRecommend;
            self.searchView.transform = CGAffineTransformIdentity;
        }];
    }else{
        [UIView animateWithDuration:0.5 animations:^{
            self.searchView.isRecommend = isRecommend;
            self.searchView.transform = CGAffineTransformIdentity;
        }];
    }
    
    
    
}

#pragma mark --------------算路成功的回调.---<##>---------------------

- (void)driveManagerOnCalculateRouteSuccess:(AMapNaviDriveManager *)driveManager
{
    NSInteger  routeLength = driveManager.naviRoute.routeLength;
    NSInteger  routeTime = driveManager.naviRoute.routeTime;
    
    JCKJExpressParam *param = [JCKJExpressParam param];
    
    param.satrtPoint = self.startPoint;
    param.endPoint = self.endPoint;
    
    [JCKJBaseRequestTool POST_CountpriceParams:param success:^(JCKJPriceModel *priceModel) {
        [self showPriceSuccess:priceModel];
    } failure:^(NSError *error) {
    }];
}

-(void)showPriceSuccess:(JCKJPriceModel *)priceModel{};
/**开始定位是的回调方法*/
-(void)startSearch{}
/**定位成功后的回调*/
-(void)searchDoneWithAddressModel:(LYQAddressModel *)model isRemondArray:(NSMutableArray *)AddressremondArray{}


-(void)choseStartAddressModel:(LYQAddressModel *)startModels{}
-(void)choseEndAddressModel:(LYQAddressModel *)endModels{}


-(void)dissmissSearchView{
    
    [UIView animateWithDuration:0.4 animations:^{
        self.searchView.transform = CGAffineTransformMakeTranslation(0, LYQ_SCREEN_H);
    }];
    
};

/**重新算路*/
-(void)recalculatetheRoad{}




@end
