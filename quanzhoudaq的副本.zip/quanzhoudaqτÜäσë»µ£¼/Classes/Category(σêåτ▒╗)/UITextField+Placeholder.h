//
//  UITextField+Placeholder.h
//  BuDeJie
//
//  Created by xiaomage on 16/3/16.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Placeholder)

@property UIColor *placeholderColor;
- (void)setXmg_Placeholder:(NSString *)placeholder;
@end
