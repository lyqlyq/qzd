//
//  LYQCancleBarButton.h
//  quanzhoudaq
//
//  Created by pro on 2018/3/5.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYQCancleBarButton : UIBarButtonItem

/**取消行程*/
+(UIBarButtonItem *)addCanclePlaceButton:(id)target action:(SEL)action;
/**查看订单*/
+(UIBarButtonItem *)addCKDDPlaceButton:(id)target action:(SEL)action;
/**收起订单*/
+(UIBarButtonItem *)addSQDDPlaceButton:(id)target action:(SEL)action;

+(UIBarButtonItem *)addItemWithImage:(UIImage *)image target:(id)target action:(SEL)action;

+(UIBarButtonItem *)addItemPlaceButton:(id)target action:(SEL)action Title:(NSString *)title;

@end
