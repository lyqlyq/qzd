//
//  LYQAPI_URL.h
//  quanzhoudaq
//
//  Created by pro on 2018/2/27.
//  Copyright © 2018年 pro. All rights reserved.
//

#ifndef LYQAPI_URL_h
#define LYQAPI_URL_h




#pragma mark -----------------登录与注册-----------4----------

#define search_phone_URL @"verifyphone"

/**验证验证码*/
#define yz_code_URL @"verifycode"

/**登录接口*/
#define login_URL @"login"

/**首页车辆信息展示*/
#define cars_info_URL @"get-car"

/**获取验证码*/
#define get_code_URL @"sendmsg"

/**快速注册接口*/
#define fast_register_URL @"fastregister"




#pragma mark -----------------乘客的接口-----------5--------

/**行程价格*/
#define countprice_URL @"countprice"

/**发布快车*/
#define publishfast_URL @"publishfast"

/**查看车主是否接单*/
#define fastorderinfo_URL @"fastorderinfo"

/**获取用户信息*/
#define getUserInfo_URL @"get-details"

/**获取接单司机的信息*/
#define getfastcarinfo_URL @"getfastcarinfo"

/***/
#define getfastdriverinfo_URL @"getfastdriverinfo"

/**取消快车*/
#define cancelfastorder_URL @"cancelfastorder"




#pragma mark -----------------司机接口---------12------------
/**司机的行程列表*/
#define driver_tripList_URL @"/driver/carowner/tripList"
/**司机到达上车地点*/
#define driver_Notice_URL  @"/driver/Receive/notice"
/**取消行程*/
#define driver_cancle_list_URL  @"/driver/carowner/cancel"
/**获取订单*/
#define driver_get_order_URL  @"/driver/carowner/orderList"
/**获取用户行程列表*/
#define driver_get_user_list_URL @"/driver/carowner/proximity"
/**司机接单操作*/
#define driver_take_order_URL  @"/driver/Carowner/orderTaking"
/**确认送达乘客*/
#define driver_service_user_URL @"/driver/Receive/reach"
/**顺风带-司机验证，验证码*/
#define driver_code_YZ_URL  @"/driver/Receive/proving"
/**司机开始出发*/
#define driver_start_place_URL  @"/driver/Receive/startPlac"
/**司机取消订单*/
#define driver_cancle_order_URL @"/driver/receive/driCancel"

/**司机接受请求*/
#define driver_agree_take_order_URL @"/driver/Carowner/operation"
/**司机拒绝请求*/
#define driver_refuse_take_order_URL @"/driver/Carowner/operation"

/**司机发布行程*/
#define driver_push_place_URL @"/driver/Carowner/addTrip"

#pragma mark -----------------首页消息接口-----3----------------
/**司机通知消息*/
#define home_driver_trip_URL @"/user/user/driTrip"

/**乘客通知消息*/
#define home_user_trip_URL @"/user/user/userTrip"

/**司机未处理的订单接口*/
#define carOwner_untreatedOrder_URL @"/driver/Receive/untreatedOrder"

#pragma mark -----------------微信支付--------1-------------

/**微信支付*/
#define weCaht_pay_URL  @"/user/wx_pay/wxpay"



#endif /* LYQAPI_URL_h */
