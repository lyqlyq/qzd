//
//  MANaviAnnotation.m
//  OfficialDemo3D
//
//  Created by yi chen on 1/7/15.
//  Copyright (c) 2015 songjian. All rights reserved.
//

#import "MANaviAnnotation.h"

@implementation MANaviAnnotation

@end
