//
//  LYQLoginRequestTool.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LYQLoginAndRegistBaseParam.h"
#import "LYQLoginAndRegistBaseModel.h"
/**登录 注册  验证码  修改密码 的接口*/
@interface LYQLoginRequestTool : NSObject

/**查询用户是否存在*/
+(void)POSTSearchPhone:(LYQLoginAndRegistBaseParam *)searchParam success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure;

/**登录*/
+(void)POSTLoginParam:(LYQLoginAndRegistBaseParam *)loginParam success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure;

/**注册*/
+(void)POSTRegisterParam:(LYQLoginAndRegistBaseParam *)registerParam success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure;

/**验证码*/
+(void)POSTCodeParam:(LYQLoginAndRegistBaseParam *)codeParam success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure;

/**修改密码*/
+(void)POSTChangePasswordParam:(LYQLoginAndRegistBaseParam *)passwordParam success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure;

/**验证 验证码接口*/
+(void)POSTYZCodeParam:(LYQLoginAndRegistBaseParam *)param success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure;

/**快速注册*/
+(void)POSTFastreGisterParam:(LYQLoginAndRegistBaseParam *)param success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure;

/**获取用户信息*/
+(void)POSTUserInfoSuccess:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure;



@end
