//
//  LYQLoginAndRegistBaseModel.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQLoginAndRegistBaseModel.h"

@implementation LYQLoginAndRegistBaseModel



@end
