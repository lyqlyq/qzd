//
//  LYQLoginAndRegistBaseModel.h
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface LYQLoginAndRegistBaseModel : NSObject

@property (nonatomic ,assign) NSInteger msg;
@property (nonatomic ,copy) NSString *token;




@end
