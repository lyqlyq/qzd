//
//  LYQLoginRequestTool.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQLoginRequestTool.h"
#import "LYQLoginAndRegistBaseModel.h"
#import "LYQRequestTool.h"


@implementation LYQLoginRequestTool

/**查询用户是否存在*/
+(void)POSTSearchPhone:(LYQLoginAndRegistBaseParam *)searchParam success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:search_phone_URL params:searchParam.mj_keyValues success:^(id responseObject) {
        
        LYQLoginAndRegistBaseModel *model = [LYQLoginAndRegistBaseModel mj_objectWithKeyValues:responseObject];
        if (success) {
            success(model);
        }
    } failure:^(NSError *error) {
        
    } showMessage:@"" isShowMessage:YES];
    
    
}

// proving
+(void)POSTLoginParam:(LYQLoginAndRegistBaseParam *)loginParam success:(void (^)(LYQLoginAndRegistBaseModel *))success failure:(void (^)(NSError *))failure{
    
    [LYQRequestTool POSTURL:login_URL params:loginParam.mj_keyValues success:^(id responseObject) {

        LYQLoginAndRegistBaseModel *model = [LYQLoginAndRegistBaseModel mj_objectWithKeyValues:responseObject];
        if (success) {
            success(model);
        }
    } failure:^(NSError *error) {
        
    } showMessage:@"登录中..." isShowMessage:YES];
    
    
    
}

+(void)POSTCodeParam:(LYQLoginAndRegistBaseParam *)codeParam success:(void (^)(LYQLoginAndRegistBaseModel *))success failure:(void (^)(NSError *))failure{
    
    [LYQRequestTool POSTURL:get_code_URL params:codeParam.mj_keyValues success:^(id responseObject) {
        LYQLoginAndRegistBaseModel *model = [LYQLoginAndRegistBaseModel mj_objectWithKeyValues:responseObject];
        if (success) {
            success(model);
        }
    } failure:^(NSError *error) {
        
    } showMessage:@"获取验证码..." isShowMessage:YES];
      
    
}

+(void)POSTRegisterParam:(LYQLoginAndRegistBaseParam *)registerParam success:(void (^)(LYQLoginAndRegistBaseModel *))success failure:(void (^)(NSError *))failure{
//    
//    [LYQRequestTool POSTURL:register_URL params:registerParam.mj_keyValues success:^(id responseObject) {
//        LYQLoginAndRegistBaseModel *model = [LYQLoginAndRegistBaseModel mj_objectWithKeyValues:responseObject];
//        if (success) {
//            success(model);
//        }
//    } failure:^(NSError *error) {
//        
//    } showMessage:@"注册中..." isShowMessage:YES];
    
    
}
+(void)POSTChangePasswordParam:(LYQLoginAndRegistBaseParam *)passwordParam success:(void (^)(LYQLoginAndRegistBaseModel *))success failure:(void (^)(NSError *))failure{
    
//    [LYQRequestTool POSTURL:change_pw_URL params:passwordParam.mj_keyValues success:^(id responseObject) {
//
//    } failure:^(NSError *error) {
//
//    } showMessage:@"修改中..." isShowMessage:YES];
    
}
+(void)POSTYZCodeParam:(LYQLoginAndRegistBaseParam *)param success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:yz_code_URL params:param.mj_keyValues success:^(id responseObject) {
        
        LYQLoginAndRegistBaseModel *model = [LYQLoginAndRegistBaseModel mj_objectWithKeyValues:responseObject];
        if (success) {
            success(model);
        }
        
    } failure:^(NSError *error) {
        
    } showMessage:@"" isShowMessage:YES];
}
/**快速注册*/
+(void)POSTFastreGisterParam:(LYQLoginAndRegistBaseParam *)param success:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure{
    
    
    [LYQRequestTool POSTURL:fast_register_URL params:param.mj_keyValues success:^(id responseObject) {
        
        LYQLoginAndRegistBaseModel *model = [LYQLoginAndRegistBaseModel mj_objectWithKeyValues:responseObject];
        if (success) {
            success(model);
        }
        
    } failure:^(NSError *error) {
        
    } showMessage:@"" isShowMessage:YES];
    
}
/**获取用户信息*/
+(void)POSTUserInfoSuccess:(void(^)(LYQLoginAndRegistBaseModel *model))success failure:(void(^)(NSError *error))failure{
    
    [LYQRequestTool POSTURL:getUserInfo_URL params:nil success:^(id responseObject) {
        
    } failure:^(NSError *error) {
        
    } showMessage:@"" isShowMessage:YES];
    
    
}



@end
