//
//  LYQHomeViewController.m
//  quanzhoudaq
//
//  Created by pro on 2017/12/19.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQHomeViewController.h"
#import "LYQExpressViewController.h"  // 快车
#import "LYQCancleBarButton.h"

#import "LYQCancleBarButton.h"

#import "JCKJDDJDViewController.h"


#import "JCKJLoginView.h"
#import "JCKJSFCViewController.h"
#import "JCKJChoseAddressController.h"
#import "JCKJPassengerPlaceDetialController.h"

#import "JCKJDriverOrderController.h"

#import "JCKJLocationManager.h"


#import "JCKJExpressParam.h"
#import "JCKJExpressRequestTool.h"

#import "LYQPersonalCenterView.h"
#import "LYQPersonModel.h"

#import "LYQLoginRequestTool.h"
#import "JCKJDriverController.h"


#import "JCKJPersonCenterRequestTool.h"


@interface LYQHomeViewController ()<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *srcView;

@property (weak, nonatomic) IBOutlet UIButton *ckButton;

@property (nonatomic ,strong) UIButton *seleButton;

@property (nonatomic ,strong) UIView *lineView;


@property (nonatomic ,strong) LYQExpressViewController *expressVC;
@property (nonatomic ,strong) JCKJSFCViewController *sfcVC;
@property (weak, nonatomic) IBOutlet UIButton *sfcButton;

@property (weak, nonatomic) IBOutlet UIView *titleView;

@property (nonatomic ,copy) JCKJLocationManager *locationMgr;

@property (nonatomic ,strong) LYQPersonalCenterView *centerView;

@end
// f3a2fc8edd208ccc76f69f130708e142
@implementation LYQHomeViewController

-(JCKJLocationManager *)locationMgr{
    if (_locationMgr == nil) {
        _locationMgr = [[JCKJLocationManager alloc] init];
    }
    return _locationMgr;
}

-(UIView *)lineView{
    
    if (_lineView == nil) {
        _lineView = [[UIView alloc] init];
        _lineView.backgroundColor = LYQ_COLOR_WITH_HEX(0xE8724E);
    }
    return _lineView;
    
}

-(LYQPersonalCenterView *)centerView{
    if (_centerView == nil) {
        _centerView = [LYQPersonalCenterView personalCenterView];
    }
    return _centerView;
}

-(LYQExpressViewController *)expressVC{
    
    if (_expressVC == nil) {
        _expressVC = [[LYQExpressViewController alloc] init];
    }
    return _expressVC;
    
}



-(JCKJSFCViewController *)sfcVC{
    if (_sfcVC == nil) {
        _sfcVC = [[JCKJSFCViewController alloc] init];
    }
    return _sfcVC;
}

/**屏蔽滑动手势*/
-(void)srcPan{};
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setUpNav];
    
    
    
    self.expressVC.mapViewRect = CGRectMake(0, 0, LYQ_SCREEN_W, self.srcView.xmg_height);
    self.expressVC.view.frame = CGRectMake(0, 0, LYQ_SCREEN_W, self.srcView.xmg_height);
    self.sfcVC.view.frame = CGRectMake(LYQ_SCREEN_W, 0, LYQ_SCREEN_W, self.srcView.xmg_height);

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(srcPan)];
    
//
    [self.srcView addGestureRecognizer:pan];
    // 快车
    [self.srcView addSubview:self.expressVC.view];
    // 顺风车
    [self.srcView addSubview:self.sfcVC.view];

    
    self.srcView.contentSize = CGSizeMake(2 * LYQ_SCREEN_W, 0);
    self.srcView.bounces = YES;
    self.srcView.pagingEnabled = YES;
    self.srcView.delegate = self;
    self.srcView.showsVerticalScrollIndicator = NO;
    self.srcView.showsHorizontalScrollIndicator = NO;
    self.seleButton = self.ckButton;

    
    LYQ_WEAK_SELF(self)
    self.expressVC.fujiaoClickBlock = ^{
        
        
       NSString *token =  [[NSUserDefaults standardUserDefaults] objectForKey:lyq_Token];
        
        if (token.length > 0) {
            JCKJExpressParam *param = [JCKJExpressParam param];
            param.satrtPoint = weakself.expressVC.startPoint;
            param.endPoint = weakself.expressVC.endPoint;
            
            [JCKJExpressRequestTool POST_PushFastCarParams:param success:^(JCKJExpressOrderModel *expModel) {
                
              JCKJDDJDViewController *ddjd = [[JCKJDDJDViewController alloc] init];
                 ddjd.startModel = weakself.expressVC.startModel;
                 ddjd.endModel = weakself.expressVC.endModel;
                ddjd.startPoint = weakself.expressVC.startPoint;
                ddjd.endPoint = weakself.expressVC.endPoint;
                ddjd.orderModel = expModel;
                [weakself.navigationController pushViewController:ddjd animated:YES];
                
            } failure:^(NSError *error) {
                
            }];
            
 
            
            
        }else{
            
            JCKJLoginView *loginV = [JCKJLoginView loginViewWityType:loginType];
            
            [loginV show];
        }
        
      
    };

    
    
    weakself.sfcVC.driverHeaderClickBlock = ^{
        JCKJDriverController *driverVC = [[JCKJDriverController alloc] init];
        [self.navigationController pushViewController:driverVC animated:YES];
    };
    
    /**乘客开始地址的选择*/
    weakself.sfcVC.startAddressClickBlock = ^{
        JCKJChoseAddressController *addressVC = [[JCKJChoseAddressController alloc] init];
        addressVC.startClick = YES;
        addressVC.sureAddressBlock = ^(NSString *addressText) {
            weakself.sfcVC.passenger_startAddressText = addressText;
        };
        [weakself.navigationController pushViewController:addressVC animated:YES];
    };
    
    /**乘客结束地址的选择*/
    weakself.sfcVC.endAddressClickBlock = ^{
        JCKJChoseAddressController *addressVC = [[JCKJChoseAddressController alloc] init];
        addressVC.startClick = NO;

        addressVC.sureAddressBlock = ^(NSString *addressText) {
            weakself.sfcVC.passenger_endAddressText = addressText;
        };
        [weakself.navigationController pushViewController:addressVC animated:YES];
    };
    
    
    /**查看订单详情*/
    
    weakself.sfcVC.passengerPlaceDetialBlock = ^{
        
        JCKJPassengerPlaceDetialController *placeDetialVC = [[JCKJPassengerPlaceDetialController alloc] init];
        
        [weakself.navigationController pushViewController:placeDetialVC animated:YES];
        
    };
    
    /**司机选择结束地址*/
    weakself.sfcVC.driverEndAddressClickBlock = ^(UILabel *clickLabel) {
        JCKJChoseAddressController *addressVC = [[JCKJChoseAddressController alloc] init];
        addressVC.startClick = NO;
        addressVC.sureAddressBlock = ^(NSString *addressText) {
            clickLabel.text = addressText;
        };
        
        [weakself.navigationController pushViewController:addressVC animated:YES];

    };
    /**司机选择开始地址*/
    weakself.sfcVC.driverStartAddressClickBlock = ^(UILabel *clickLabel) {
        JCKJChoseAddressController *addressVC = [[JCKJChoseAddressController alloc] init];
        addressVC.startClick = YES;
        addressVC.sureAddressBlock = ^(NSString *addressText) {
            clickLabel.text = addressText;
        };
        
        [weakself.navigationController pushViewController:addressVC animated:YES];
    };
    /**司机点击订单详情*/

    weakself.sfcVC.driverPlaceClickBlock = ^{
        
        JCKJDriverOrderController *driverOrderVC = [[JCKJDriverOrderController alloc] init];
        [weakself.navigationController pushViewController:driverOrderVC animated:YES];
        
    };
    
    self.lineView.frame = CGRectMake(0, self.sfcButton.xmg_height, 30, 1);
    self.lineView.xmg_centerX = self.ckButton.xmg_centerX;
    [self.titleView addSubview:self.lineView];
    [self addChildViewController:self.expressVC];
    
    [self.locationMgr startUserLocationAddressSuccess:^(NSString *cityName) {
        self.title = cityName;
        self.sfcVC.driver_startAddressText = cityName;
    }];
    
    
}




-(NSString*)getCurrentTimes{
    
    NSDate *date = [NSDate date];
    
    return [NSString stringWithFormat:@"%lf",[date timeIntervalSince1970]];
    
}

/**快车*/
- (IBAction)kcClick:(UIButton *)sender {
    [self clickButton:sender];
//    [self.srcView setContentOffset:CGPointMake(0, 0) animated:YES];

}
/**顺风车*/
- (IBAction)sfCClick:(UIButton *)sender {
    [self clickButton:sender];

    
}


-(void)clickButton:(UIButton *)sender{
    self.seleButton.selected = NO;
    sender.selected = YES;
    self.seleButton = sender;
    
    [UIView animateWithDuration:0.2 animations:^{

        self.lineView.xmg_centerX = self.seleButton.xmg_centerX;
        self.srcView.contentOffset = CGPointMake((self.seleButton.xmg_x / self.seleButton.xmg_width ) * LYQ_SCREEN_W, 0);
    }completion:^(BOOL finished) {
       
    }];
}


-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    
    self.expressVC.view.frame = CGRectMake(0, 0, LYQ_SCREEN_W, self.srcView.xmg_height);

}


-(void)setUpNav{
    
    
    self.navigationItem.leftBarButtonItem = [LYQCancleBarButton addItemWithImage:LYQ_IMAGENAME(@"PersonalCenter") target:self action:@selector(leftClick)];
    self.navigationItem.rightBarButtonItem = [LYQCancleBarButton addItemWithImage:LYQ_IMAGENAME(@"TheMessage") target:self action:@selector(rightClick)];
    
}



-(void)leftClick{
    
    
    [JCKJPersonCenterRequestTool get_detailsSuccess:^(JCKJUserModel *model) {
        
        self.centerView.model = model;
        
        [self.centerView show];

    } failure:^(NSError *error) {
        
    }];
    
    
    LYQ_WEAK_SELF(self)
    self.centerView.didSelectRowBlock = ^(LYQPersonModel *model) {
        UIViewController *vc =[[NSClassFromString(model.controller_name) alloc] init];;
        vc.title = model.title_name;
        [weakself.navigationController pushViewController:vc animated:YES];        
    };
}

-(void)rightClick{
    

//
//    LYQPayParam *param = [LYQPayParam param];
//
//    param.content = @"打车费用";
//    param.total = @"1";
//
//    LYQPayView *payView = [LYQPayView payViewWithPayParam:param];
//
//    [payView show];
//
}

@end
