//
//  LYQLoginAndRegistBaseParam.h
//  quanzhouda
//
//  Created by pro on 2017/11/30.
//  Copyright © 2017年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQLoginAndRegistBaseParam : NSObject

@property (nonatomic ,copy) NSString *phone;
@property (nonatomic ,copy) NSString *password;
@property (nonatomic ,copy) NSString *code;



+(instancetype)param;

@end
