//
//  LYQHomeMessageCellModel.m
//  quanzhoudaq
//
//  Created by pro on 2018/1/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQHomeMessageCellModel.h"

@implementation LYQHomeMessageCellModel

+(NSMutableArray *)getModels{
    
    NSMutableArray *models = [NSMutableArray array];
    NSArray *imageNames = @[@"TheSysteminforms",@"passengers_message",@"Theowner",@"CustomerService1"];
    NSArray *noteNames = @[@"系统通知",@"乘客行程通知",@"车主订单通知",@"配件小秘"];
    NSArray *infoNames = @[@"您好，您发布的配件需求···",@"你的顺风车行程已被接单",@"您有一个顺风带请求",@"您好，您发布的配件需求···"];
    NSArray *times = @[@"9:00",@"10:00",@"11:00",@"17:00"];
    
    for (NSInteger i = 0 ; i < imageNames.count; i ++) {
        LYQHomeMessageCellModel *model = [[LYQHomeMessageCellModel alloc] init];
        model.image_name = imageNames[i];
        model.note_name = noteNames[i];
        model.note_info = infoNames[i];
        model.note_time = times[i];
        [models addObject:model];
    }
    
    
    
    
    return models;
}

@end
