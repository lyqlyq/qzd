//
//  LYQLoginAndRegistBaseParam.m
//  quanzhouda
//
//  Created by pro on 2017/11/30.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQLoginAndRegistBaseParam.h"

@implementation LYQLoginAndRegistBaseParam


+(instancetype)param{
    
    LYQLoginAndRegistBaseParam *param = [[self alloc] init];
    
    
    return param;
}

@end
