//
//  LYQHomeMessageCellModel.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQHomeMessageCellModel : NSObject

@property (nonatomic ,copy) NSString *image_name;
@property (nonatomic ,copy) NSString *note_name;
@property (nonatomic ,copy) NSString *note_info;
@property (nonatomic ,copy) NSString *note_time;


+(NSMutableArray *)getModels;

@end
