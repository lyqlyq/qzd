//
//  LYQPayParam.h
//  quanzhoudaq
//
//  Created by pro on 2018/1/17.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQPayParam : NSObject



/**乘客行程id*/
@property (nonatomic ,copy) NSString *passenger_place_id;
/**价格*/
@property (nonatomic ,copy) NSString *place_money;
/**ip地址*/
@property (nonatomic ,copy) NSString *wxip;
/**商品名称*/
@property (nonatomic ,copy) NSString *body;
/**司机行程ID*/
@property (nonatomic ,copy) NSString *carOwner_place_id;


@property (nonatomic ,copy) NSString *content;
@property (nonatomic ,copy) NSString *total;



+(instancetype)param;

@end
