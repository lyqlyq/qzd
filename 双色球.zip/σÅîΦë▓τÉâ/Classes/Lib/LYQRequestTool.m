//
//  LYQRequestTool.m
//  quanzhouda
//
//  Created by pro on 2017/11/30.
//  Copyright © 2017年 pro. All rights reserved.
//

#import "LYQRequestTool.h"




@implementation LYQRequestTool

+(void)POSTURL:(NSString *)url params:(NSDictionary *)params success:(void(^)(id responseObject))success failure:(void(^)(NSError *error))failure showMessage:(NSString *)message isShowMessage:(BOOL)isShow{
    
 

 
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer.timeoutInterval = 5.f;
   
    [manager POST:@"http://caipiao.163.com/calcHistory/winningRecordsStatistics.html" parameters:params progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (responseObject) {
            
            if (success) {
                success(responseObject);
            }
            
            NSLog(@"%@",responseObject);
       
         
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (failure) {
            failure(error);
        }
        NSLog(@"%@",error);

       

    }];
    
}
        
   


@end
