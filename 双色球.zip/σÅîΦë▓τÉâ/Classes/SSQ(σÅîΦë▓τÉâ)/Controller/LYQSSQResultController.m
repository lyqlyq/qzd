//
//  LYQSSQResultController.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQSSQResultController.h"
#import "LYQRedCell.h"
@interface LYQSSQResultController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UILabel *timeLbale;
@property (weak, nonatomic) IBOutlet UILabel *weiChaLabel;

@property (weak, nonatomic) IBOutlet UILabel *infoLabel;

@end

@implementation LYQSSQResultController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选号结果";
    
    self.timeLbale.text = [self getDateStr];
    
    self.weiChaLabel.text = self.weiChastr;
    
   // self.infoLabel.text = @"没有 6 红产生";

//    [self.sexModels enumerateObjectsUsingBlock:^(LYQRedSexNumberModel *sexRedModel, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (sexRedModel.is_sex_red) {
//            NSInteger index =  [self.sexModels indexOfObject:sexRedModel];
//            
//            self.infoLabel.text = [NSString stringWithFormat:@"当前第 -%ld- 注产生了 6 红",index + 1];
//            
//        }
//    }];
    
}

-(NSString *)getDateStr{
    NSDate *date=[NSDate date];
    NSDateFormatter *format1=[[NSDateFormatter alloc] init];
    [format1 setDateFormat:@"当前日期:yyyy-MM-dd hh:mm:ss"];
    return [format1 stringFromDate:date];
}



#pragma mark -----------------UITableViewDataSource---------------------
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.sexModels.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LYQRedCell *cell = [LYQRedCell redCellWithTableView:tableView];
    cell.sexModel = self.sexModels[indexPath.row];
    cell.countLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row + 1];
    return cell;
}

#pragma mark -----------------UITableViewDetegate---------------------
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70.0f;
}




@end
