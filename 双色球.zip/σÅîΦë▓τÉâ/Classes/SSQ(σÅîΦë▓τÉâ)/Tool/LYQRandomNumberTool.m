//
//  LYQRandomNumberTool.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQRandomNumberTool.h"
#import "LYQPotentialModel.h"

@implementation LYQRandomNumberTool


+(NSInteger)getRandomPotenial{
    return [self getRandomNumber:1 to:11];
}


+(NSInteger)getRedNumberWithOneTO33{
    return [self getRandomNumber:1 to:33];
}
+(NSInteger)getRedNumberWithOneTO22{
    return [self getRandomNumber:0 to:22];

}

+(NSInteger)getRandomBlueText{
    return [self getRandomNumber:1 to:16];
}

+(NSInteger)getRandomNumber:(int)from to:(int)to
{
    
    return (NSInteger)(from + (arc4random() % (to - from + 1)));
}


+(NSInteger)getPotenialNumber:(LYQPotentialModel *)pModel{
    NSInteger index =  [self getRandomNumber:0 to:pModel.potentialArray.count - 1];
    NSString *desText = pModel.potentialArray[index];
    return  desText.integerValue;
    
}


@end
