//
//  LYQSSQParam.h
//  双色球
//
//  Created by pro on 2018/3/22.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQSSQParam : NSObject

@property (nonatomic ,copy) NSString *periods;
@property (nonatomic ,copy) NSString *gameEn;
@property (nonatomic ,copy) NSString *stakeNumber;
@property (nonatomic ,copy) NSString *cache;



@end
