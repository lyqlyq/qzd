//
//  LYQRedSexNumberModel.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQRedSexNumberModel.h"
#import "LYQRedOneNumberModel.h"
#import "LYQPotentialModel.h"
#import "LYQRandomNumberTool.h"
#import "LYQConditionModel.h"
#import "LYQKillNumberModel.h"


@interface LYQRedSexNumberModel ()


@end


@implementation LYQRedSexNumberModel

-(instancetype)init{
    if (self = [super init]) {
        self.blueText = [NSString stringWithFormat:@"%02ld",[LYQRandomNumberTool getRandomBlueText]];
    }
    return self;
}


/**根据位差，龙头 ，凤尾 ，生产号码*/
+(NSMutableArray<LYQRedSexNumberModel *> *)getRedSexNumberModesArrayWithPotentialModel:(LYQPotentialModel *)potentialModel conditionModel:(LYQConditionModel *)conditionModel{
    
    
    NSMutableArray *sexModelArray = [NSMutableArray array];
    
    for (NSInteger i = 0 ; i < conditionModel.numberTotial; i ++) {
        
        NSInteger addCount = conditionModel.faucetNumber;
        LYQRedSexNumberModel *sexModel = [[LYQRedSexNumberModel alloc] init];
        NSMutableArray *oneArray = [NSMutableArray array];
        LYQRedOneNumberModel *oneModel = [self getRedOneModelWithNumber:conditionModel.faucetNumber];
        [oneArray addObject:oneModel];
        
        for (NSInteger j = 0 ; j < conditionModel.remainedRedNumber; j ++) {
            LYQRedOneNumberModel *one = [[LYQRedOneNumberModel alloc] init];
            NSInteger jswc = [LYQRandomNumberTool getPotenialNumber:potentialModel];
            addCount += jswc;
            one.redNumber =  addCount;
            if (one.redNumber > 33) {
                one.isMaxOver_33 = YES;
                sexModel.isMaxOver_33 = YES;
            }
            [oneArray addObject:one];
        }
        
        if (conditionModel.pterisNumber > 0) {
            LYQRedOneNumberModel *onePModel = [self getRedOneModelWithNumber:conditionModel.pterisNumber];
            [oneArray addObject:onePModel];
        }
        
        if (!sexModel.isMaxOver_33) {
            sexModel.redOneNumberModelArrays = oneArray;
            [sexModelArray addObject:sexModel];
            [sexModel.redOneNumberModelArrays sortUsingComparator:^NSComparisonResult(LYQRedOneNumberModel  *obj1, LYQRedOneNumberModel *obj2) {
                return [[NSNumber numberWithInteger:obj1.redNumber] compare:[NSNumber numberWithInteger:obj2.redNumber]];
            }];
        }
        
        
    }
    
    
    [sexModelArray enumerateObjectsUsingBlock:^(LYQRedSexNumberModel *sexModel, NSUInteger idx, BOOL * _Nonnull stop) {
        
    }];
    
    
    return sexModelArray;
    
}

+(NSMutableArray<LYQRedSexNumberModel *> *)getRedSexNumberModesArrayWithPotentialModel:(LYQPotentialModel *)potentialModel conditionModel:(LYQConditionModel *)conditionModel WithRightSexModel:(LYQRedSexNumberModel *)model{
    
    NSMutableArray *sexModelsArray = [self getRedSexNumberModesArrayWithPotentialModel:potentialModel conditionModel:conditionModel];
    
    for (LYQRedSexNumberModel *sexModel in sexModelsArray) {
        [sexModel.redOneNumberModelArrays enumerateObjectsUsingBlock:^(LYQRedOneNumberModel * oneRedModel, NSUInteger idx, BOOL * _Nonnull stop) {
            [model.redOneNumberModelArrays enumerateObjectsUsingBlock:^(LYQRedOneNumberModel * rightRed , NSUInteger idx, BOOL * _Nonnull stop) {
                if (oneRedModel.redNumber == rightRed.redNumber) {
                    oneRedModel.isRight = YES;
                }
            }];
        }];
        
//
//        __block BOOL isRegit = YES;
//        [sexModel.redOneNumberModelArrays enumerateObjectsUsingBlock:^(LYQRedOneNumberModel * oneRedModel, NSUInteger idx, BOOL * _Nonnull stop) {
//            [model.redOneNumberModelArrays enumerateObjectsUsingBlock:^(LYQRedOneNumberModel * rightRed , NSUInteger idx, BOOL * _Nonnull stop) {
//                if (oneRedModel.redNumber == rightRed.redNumber) {
//                    oneRedModel.isRight = YES;
//                }else{
//                    oneRedModel.isRight = NO;
//                }
//                isRegit =  isRegit && oneRedModel.isRight;
//
//            }];
//
//            sexModel.is_sex_red = isRegit;
//
//        }];
        
    }

    
    return sexModelsArray;
    
}

+(NSMutableArray<LYQRedSexNumberModel *> *)getRedSexNumberModesArrayWithPotentialModel:(LYQPotentialModel *)potentialModel conditionModel:(LYQConditionModel *)conditionModel killNumberModel:(LYQKillNumberModel *)model{
    
     NSMutableArray *sexModelsArray = [self getRedSexNumberModesArrayWithPotentialModel:potentialModel conditionModel:conditionModel];
    
    for (LYQRedSexNumberModel *sexModel in sexModelsArray) {
        [sexModel.redOneNumberModelArrays enumerateObjectsUsingBlock:^(LYQRedOneNumberModel * oneRedModel, NSUInteger idx, BOOL * _Nonnull stop) {
            [model.killNumberArrays enumerateObjectsUsingBlock:^(NSString *killText, NSUInteger idx, BOOL * _Nonnull stop) {
                if (oneRedModel.redNumber == [killText integerValue]) {
                    oneRedModel.isKillNumber = YES;
                }
                
            }];
        }];
    }
    
    
    return sexModelsArray;
    
}


+(LYQRedOneNumberModel *)getRedOneModelWithNumber:(NSInteger)redNumber{
    LYQRedOneNumberModel *redModel = [[LYQRedOneNumberModel alloc] init];
    redModel.redNumber = redNumber;
    return redModel;

}

@end
