//
//  LYQAwardModel.h
//  双色球
//
//  Created by pro on 2018/3/22.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQAwardModel : NSObject

@property (nonatomic ,copy) NSString *awardNo;
@property (nonatomic ,copy) NSString *awardNum;
@property (nonatomic ,copy) NSString *lastTime;
@property (nonatomic ,copy) NSString *levelId;
@property (nonatomic ,copy) NSString *levelName;



@end
