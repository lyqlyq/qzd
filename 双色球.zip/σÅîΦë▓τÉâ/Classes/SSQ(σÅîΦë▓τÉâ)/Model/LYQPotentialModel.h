//
//  LYQPotentialModel.h
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>
/**位差*/
@interface LYQPotentialModel : NSObject

/**位差总数*/
@property (nonatomic ,assign) NSInteger potentialTotial;

@property (nonatomic ,assign) NSInteger poentialOne;
@property (nonatomic ,assign) NSInteger poentialTwo;
@property (nonatomic ,assign) NSInteger poentialThere;
@property (nonatomic ,assign) NSInteger poentialFour;
@property (nonatomic ,assign) NSInteger poentialFive;

@property (nonatomic ,copy) NSString *oneText;
@property (nonatomic ,copy) NSString *twoText;
@property (nonatomic ,copy) NSString *thereText;
@property (nonatomic ,copy) NSString *fourText;
@property (nonatomic ,copy) NSString *fiveText;

/**位差数组*/
@property (nonatomic ,strong) NSMutableArray *potentialArray;



/**随机位差模型*/
+(instancetype)potentialModelWithRandomNumber;


@end
