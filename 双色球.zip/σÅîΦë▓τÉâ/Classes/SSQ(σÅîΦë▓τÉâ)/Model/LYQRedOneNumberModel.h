//
//  LYQRedOneNumberModel.h
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQRedOneNumberModel : NSObject


/**红球号码*/
@property (nonatomic ,assign) NSInteger redNumber;

/**是否超过*/
@property (nonatomic ,assign) BOOL isMaxOver_33;

/**是否是开奖号码*/
@property (nonatomic ,assign) BOOL isRight;

/**是否是杀号*/
@property (nonatomic ,assign) BOOL isKillNumber;


@end
