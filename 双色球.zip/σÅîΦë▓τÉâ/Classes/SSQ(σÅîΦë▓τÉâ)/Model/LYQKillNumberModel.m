//
//  LYQKillNumberModel.m
//  双色球
//
//  Created by pro on 2018/3/16.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQKillNumberModel.h"

@implementation LYQKillNumberModel




-(NSString *)killNumOneText{
    
    return [NSString stringWithFormat:@"%ld",self.killNumOne];
    
}
-(NSString *)killNumTwoText{
    return [NSString stringWithFormat:@"%ld",self.killNumTwo];

}
-(NSString *)killNumThereText{
    return [NSString stringWithFormat:@"%ld",self.killNumThere];

}
-(NSString *)killNumFourText{
    return [NSString stringWithFormat:@"%ld",self.killNumFour];

}
-(NSString *)killNumFiveText{
    return [NSString stringWithFormat:@"%ld",self.killNumFive];

}
-(NSString *)killNumSexText{
    return [NSString stringWithFormat:@"%ld",self.killNumSex];

}

-(NSMutableArray *)killNumberArrays{
    
    NSMutableArray *killArray = [NSMutableArray array];
    
    [killArray  addObject:self.killNumOneText];
    [killArray  addObject:self.killNumTwoText];
    [killArray  addObject:self.killNumThereText];
    [killArray  addObject:self.killNumFourText];
    [killArray  addObject:self.killNumFiveText];
    [killArray  addObject:self.killNumSexText];


    
    return killArray;
    
    
}

@end
