
//
//  LYQSSQParam.m
//  双色球
//
//  Created by pro on 2018/3/22.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LYQSSQParam.h"

@implementation LYQSSQParam

-(instancetype)init{
    
    if (self = [super init]) {
        
        self.periods = @"0";
        self.gameEn = @"ssq";
        self.cache = [self getCurrentTimes];
    }
    return self;
    
}
-(NSString*)getCurrentTimes{
    
    NSDate *date = [NSDate date];
    
    return [NSString stringWithFormat:@"%lf",[date timeIntervalSince1970]];
    
}
@end
