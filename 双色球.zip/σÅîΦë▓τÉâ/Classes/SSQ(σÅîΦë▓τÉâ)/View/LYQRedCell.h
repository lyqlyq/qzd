//
//  LYQRedCell.h
//  双色球
//
//  Created by pro on 2018/3/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LYQRedSexNumberModel.h"

@interface LYQRedCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *countLabel;

@property (nonatomic ,strong) LYQRedSexNumberModel*sexModel;

+(instancetype)redCellWithTableView:(UITableView *)tableView;


@end
