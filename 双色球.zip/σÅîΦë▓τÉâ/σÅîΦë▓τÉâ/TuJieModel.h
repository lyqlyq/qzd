//
//  TuJieModel.h
//  双色球
//
//  Created by pro on 2018/2/8.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@class LYQRedBool;
@interface TuJieModel : NSObject

/**红球数组*/
@property (nonatomic ,strong) NSMutableArray <LYQRedBool *> *redBoolArray;

@property (nonatomic ,copy) NSString *blueText;

/**大于33 了*/
@property (nonatomic ,assign) BOOL isMAX_33;

@end
