
//
//  TuJieModel.m
//  双色球
//
//  Created by pro on 2018/2/8.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "TuJieModel.h"

@implementation TuJieModel

-(instancetype)init{
    
    if (self = [super init]) {
        self.blueText = [self getBlueText];
    }
    return self;
    
}

-(NSString *)getBlueText{
    
    
    NSString *blueText =  [NSString stringWithFormat:@"%02ld",[self getRandomNumber:1 to:17]];
    
    return blueText;
    
}

// 获取一个随机整数，范围在[from,to），包括from，不包括to
-(int)getRandomNumber:(int)from to:(int)to
{
    return (int)(from + (arc4random() % (to - from )));
    
}

@end
