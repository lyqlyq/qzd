//
//  LYQRedBool.h
//  双色球
//
//  Created by pro on 2018/3/13.
//  Copyright © 2018年 pro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYQRedBool : NSObject

/**红球号码*/
@property (nonatomic ,assign) NSInteger redNum;

/**当前是否出现*/
@property (nonatomic ,assign) BOOL isShow;

@end
