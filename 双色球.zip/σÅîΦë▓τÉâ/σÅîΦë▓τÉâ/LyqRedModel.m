//
//  LyqRedModel.m
//  双色球
//
//  Created by pro on 2018/2/7.
//  Copyright © 2018年 pro. All rights reserved.
//

#import "LyqRedModel.h"

@implementation LyqRedModel

-(instancetype)init{
    if (self = [super init]) {
        
        self.rednumArrays = [self getRedsArrays];
        self.blueText = [self getBlueText];
    }
    return self;
    
}

-(NSMutableArray *)getRedsArrays{
    
    NSMutableArray *arr = [NSMutableArray array];
    NSMutableArray *desArr = [NSMutableArray array];
    
    for (NSInteger i = 1; i < 34; i ++) {
        [arr addObject:@(i)];
    }
    
    for (NSInteger i = 1; i <7; i ++) {
        
        NSNumber *desNum = arr[[self getRandomNumber:0 to:arr.count]];
      
        [arr removeObject:desNum];
        
        [desArr addObject:desNum];
    }
    
    return desArr;
    
    
}

-(NSString *)getBlueText{
  
    
    NSString *blueText =  [NSString stringWithFormat:@"%02ld",[self getRandomNumber:1 to:17]];
    
    return blueText;
    
}

// 获取一个随机整数，范围在[from,to），包括from，不包括to
-(int)getRandomNumber:(int)from to:(int)to
{
    return (int)(from + (arc4random() % (to - from )));
    
}


@end
